import boto3, argparse, json, sys

parser = argparse.ArgumentParser()
parser.add_argument("--env", required=True)
parser.add_argument("--service", required=True)
args = parser.parse_args()

ssm = boto3.client("ssm")

path = f"/dd/{args.env}/{args.service}/config/"

resp = ssm.get_parameters_by_path(Path=path, Recursive=True, WithDecryption=True)
if len(resp.get("Parameters", [])) == 0:
    print(f"ERROR: Missing required config under {path}")
    sys.exit(1)

print("Config validated OK")
