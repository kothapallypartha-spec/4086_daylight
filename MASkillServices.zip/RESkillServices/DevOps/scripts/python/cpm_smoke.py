import boto3, time, statistics, json, os
client = boto3.client("lambda")

fn = os.environ["TARGET_LAMBDA"]

lat = []
for _ in range(15):
    t0 = time.time()
    r = client.invoke(FunctionName=fn, Payload=b'{}')
    t1 = time.time()
    lat.append((t1 - t0) * 1000)

p95 = statistics.quantiles(lat, n=20)[18]
print(json.dumps({"p95_ms": p95}))
if p95 > 900:
    raise Exception("FAIL: p95 too high")
