#!/usr/bin/env python3.6
import boto3
import json
import sys
import time
from botocore.exceptions import ClientError

def get_params():
    try:
        return json.loads(sys.argv[1])
    except:
        print("No parameters passed from command line")
        sys.exit(1)

params = get_params()
stack_name = params['stackName']
client = boto3.client('cloudformation')

def get_stack_status(params):
    try:
        stack_response = client.describe_stacks(StackName=stack_name)
    except ClientError as e:
        if e.response['Error']['Code'].startswith("Throttling"):
            return 'UNKNOWN', str(e.response['Error'])
        else:
            raise Exception("Unhandled Exception in describe_stack_events: {}".format(e))
    except Exception as e:
        raise Exception("Unhandled Exception in describe_stack_events: {}".format(e))

    print(str(stack_response))
    if not stack_response['Stacks']:
        return 'UNKNOWN', 'no stacks found'

    stack = stack_response['Stacks'][0]
    tags = stack.get('Tags', [])
    tag_dict = {tag['Key']: tag['Value'] for tag in tags}
    if tag_dict.get('AssetID') != params.get('assetId') or tag_dict.get('AssetGroup') != params.get('assetGroup'):
        print("Stack tags do not match the provided AssetID and AssetGroup")
        print(f"Provided AssetID: {params.get('assetId')}, Stack AssetID: {tag_dict.get('AssetID')}")
        print(f"Provided AssetGroup: {params.get('assetGroup')}, Stack AssetGroup: {tag_dict.get('AssetGroup')}")
        sys.exit(1)

    if 'StackStatus' not in stack:
        return 'UNKNOWN', 'no status found'

    stack_status = stack['StackStatus']

    if 'StackStatusReason' in stack:
        return stack_status, stack['StackStatusReason']

    return stack_status, 'UNKNOWN'

current_status, reason = get_stack_status(params)
print(f" current status {current_status} reason = {reason}")
print(f" deleting Stack Name = {stack_name}")
client.delete_stack(StackName=stack_name)
print("waiting....")
time.sleep(60)
print("Check Status....")
current_status, reason = get_stack_status(params)
print(f" status {current_status} reason = {reason}")

if current_status in ['DELETE_IN_PROGRESS', 'DELETE_COMPLETE', 'STACK_DOES_NOT_EXIST']:
    sys.exit(0)
else:
    sys.exit(1)