# Due Diligence Document Extraction Service

A FastAPI-based microservice that extracts and categorizes due diligence documents from Purchase and Sale Agreements (PSAs) using Large Language Models (LLMs).

## Overview

This service analyzes real estate Purchase and Sale Agreements to identify and extract:
- **Document names and titles** mentioned in the PSA
- **Responsible parties** (Seller, Buyer, Both, Third Party, Unspecified)
- **Document categories** (Leasing, Environmental, Title, Financial, etc.)
- **Deadlines and timelines** for document delivery

The service uses structured LLM outputs with Pydantic validation to ensure consistent, reliable extraction of due diligence requirements.

## Features

- **FastAPI REST API** with automatic OpenAPI documentation
- **AWS Lambda deployment** ready via Mangum adapter
- **Pre-signed URL support** for S3-hosted documents
- **Structured LLM output** using Pydantic models with strict typing
- **OpenAI-compatible LLM integration** via custom proxy
- **AWS Secrets Manager** integration for secure credential management
- **Comprehensive logging** with AWS CloudWatch support
- **HTML to text conversion** for document processing

## Prerequisites

- **Python 3.11 or higher** (required for numpy>=2.2.3)
- **AWS CLI** configured with appropriate credentials
- **AWS Secrets Manager** access for LLM API keys
- **Virtual environment** (venv)

## Installation

### 1. Navigate to project directory

```bash
cd 4086-daylight-skill-services/RESkillServices/DueDiligenceExtraction
```

### 2. Create and activate virtual environment

```bash
# Create venv with Python 3.11+
python3.11 -m venv venv

# Activate on macOS/Linux
source venv/bin/activate

# Activate on Windows
# venv\Scripts\activate
```

### 3. Install dependencies

```bash
# Upgrade pip
venv/bin/pip install --upgrade pip

# Install all requirements
venv/bin/pip install -r requirements.txt
```

## Configuration

### Environment Variables

Set these environment variables before running the service:

```bash
# LLM Model Configuration
export MODEL_NAME="OpenAI_gpt-4.1-2025-04-14_Daylight_US_3363_nonprod"

# AWS Configuration
export AWS_PROFILE="app-fos-nonprod-fosdev"
export AWS_DEFAULT_REGION="us-east-1"

# Optional: For local development without AWS Secrets
export USE_MOCK_SECRETS="true"
```

### AWS Credentials

Ensure your AWS credentials are up to date:

```bash

# Verify credentials are valid
aws sts get-caller-identity --profile prod-nl-dev-lpacontractanalysisdev
```

## Running Locally

### Start the FastAPI Server

```bash
# Navigate to src directory
cd Source/Lambda

# Set environment variables
export AWS_PROFILE=prod-nl-dev-lpacontractanalysisdev
export AWS_DEFAULT_REGION=us-east-1

# Start the server
uvicorn main:app --reload --host 0.0.0.0 --port 8080
```

The API will be available at:
- **API Base URL**: http://localhost:8080
- **Interactive API Docs**: http://localhost:8080/docs
- **Alternative API Docs**: http://localhost:8080/redoc
- **Health Check**: http://localhost:8080/healthz

### Running Tests

```bash
# Navigate to Tests directory
cd Tests


# Test against local server (server must be running)
python test_endpoint.py local

# Test against deployed endpoint in specific environment
export ASSET_GROUP="ddc1c"  # or "pdc1c" for production
python test_endpoint.py
```

## API Endpoints

### POST `/` or `/dd-docs-extraction/`

Extract due diligence documents from a Purchase and Sale Agreement.

**Request Body:**

```json
{
  "model_name": "OpenAI_gpt-4.1-2025-04-14_Daylight_US_3363_nonprod",
  "document_input": {
    "file_name": "psa_10",
    "url": "https://s3-presigned-url.amazonaws.com/document.html",
    "headers": {}
  }
}
```

**Alternative with direct content:**

```json
{
  "model_name": "OpenAI_gpt-4.1-2025-04-14_Daylight_US_3363_nonprod",
  "document_input": {
    "file_name": "psa_10",
    "content": "Full text content of the PSA...",
    "headers": {}
  }
}
```

**Response (Success - 200):**

```json
{
  "documents": [
    {
      "Document": "Current Tenant Leases",
      "Responsible_Party": "Seller",
      "Category": "Leasing",
      "Deadline": "Within 5 business days of Effective Date"
    },
    {
      "Document": "Phase I Environmental Site Assessment",
      "Responsible_Party": "Buyer",
      "Category": "Environmental",
      "Deadline": "2025-12-31"
    },
    {
      "Document": "Title Commitment",
      "Responsible_Party": "Third Party",
      "Category": "Title",
      "Deadline": "Within 10 days"
    }
  ]
}
```

**Response (Error - 500):**

```json
{
  "error": "Error message describing what went wrong",
  "traceback": "Full Python traceback for debugging",
  "statusCode": 500
}
```

### GET `/healthz`

Health check endpoint to verify service availability.

**Response (200):**

```json
{
  "ok": true
}
```


## Data Models

### Input Model: `Document`

```python
{
  "file_name": str,           # Document name or identifier (required)
  "content": str | None,      # Full text content (optional if URL provided)
  "url": str | None,          # Pre-signed S3 URL (optional if content provided)
  "headers": dict | None      # HTTP headers for URL request (optional)
}
```

**Validation**: Either `content` OR `url` must be provided.

### Output Model: `DueDiligenceDocument`

```python
{
  "Document": str,                    # Exact document name from PSA
  "Responsible_Party": str,           # One of: Seller, Buyer, Both, Third Party, Unspecified
  "Category": str,                    # Document category (see list below)
  "Deadline": str | None              # Deadline text or None if not specified
}
```

### Document Categories

The service classifies documents into these predefined categories:

- **Leasing** - Tenant leases, rent rolls, lease abstracts
- **Operations** - Operating agreements, management contracts
- **Financials** - Financial statements, tax returns, budgets
- **Environmental** - Phase I/II reports, environmental assessments
- **Physical** - Property condition reports, inspection reports
- **Title** - Title commitments, title policies, deeds
- **Personal Property Liens** - UCC searches, lien information
- **Seller's Loan Documents** - Loan agreements, mortgages
- **Survey** - Property surveys, boundary surveys
- **Zoning** - Zoning certificates, variance letters
- **Corporate** - Articles of incorporation, bylaws
- **Litigation** - Pending litigation notices, legal claims
- **Employees** - Employee lists, personnel files
- **Insurance** - Insurance policies, loss runs
- **Valuation** - Appraisals, valuations
- **Various** - Multiple categories
- **Unknown** - Cannot determine category

### Responsible Party Values

- **Seller** - Document to be provided by the seller
- **Buyer** - Document to be obtained or prepared by buyer
- **Both** - Joint responsibility
- **Third Party** - External party (title company, surveyor, etc.)
- **Unspecified** - Responsibility not clearly stated

## Core Functions

### `dd_docs_extraction_agent()`

Main extraction function that processes a PSA document.

```python
def dd_docs_extraction_agent(
    doc: Document,
    *,
    model_name: str,
    context: Any = None
) -> DueDiligenceExtractionOutput:
    """
    Extracts due diligence documents from a PSA.
    
    Args:
        doc: Document containing PSA content or URL
        model_name: LLM model identifier
        context: Optional context (unused, for compatibility)
    
    Returns:
        DueDiligenceExtractionOutput with list of extracted documents
    """
```

## AWS Lambda Deployment

The service is ready for AWS Lambda deployment using **Mangum**:

```python
from mangum import Mangum
handler = Mangum(app, lifespan="off")
```

### Lambda Handler

The `handler` object in `main.py` (line 96) is the AWS Lambda entry point.


### Environment Variables for Lambda

Set these in your Lambda configuration:
- `MODEL_NAME` - LLM model identifier
- `AWS_REGION` - AWS region for Secrets Manager

## Troubleshooting

### Connection Refused Error

**Problem**: `[Errno 61] Connection refused` when running tests

**Solution**: Ensure the FastAPI server is running in a separate terminal:

```bash
# Terminal 1: Start server
cd src
uvicorn main:app --reload --host 0.0.0.0 --port 8080

# Terminal 2: Run tests
cd Tests
python test_endpoint.py local
```

## Testing

### Manual Testing via API Docs

1. Start server: `cd src && uvicorn main:app --reload --host 0.0.0.0 --port 8080`
2. Open browser: http://localhost:8080/docs
3. Click "Try it out" on POST `/dd-docs-extraction/`
4. Paste test payload and click "Execute"

### Automated Testing

```bash
# Local endpoint
python Tests/test_endpoint.py local

# Deployed endpoint (dev)
export ASSET_GROUP=ddc1c
python Tests/test_endpoint.py

# Deployed endpoint (prod)
export ASSET_GROUP=pdc1c
python Tests/test_endpoint.py
```

### Sample Test Document

Use `psa_10.docx` in the project root as a sample PSA for testing.

## Logging

The service uses structured logging with CloudWatch integration:

```python
from aws.logger import get_logger
logger = get_logger()

logger.info("Message", extra={"key": "value"})
logger.error("Error occurred", exc_info=True)
```

