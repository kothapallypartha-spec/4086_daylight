import os
import sys
import tempfile
from pathlib import Path
import pytest

current_dir = os.path.dirname(os.path.abspath(__file__))
source_dir = os.path.abspath(os.path.join(current_dir, '..', '..', 'Source'))
if source_dir not in sys.path:
    sys.path.insert(0, source_dir)

from Lambda.main import app, extract_text_from_docx
from Lambda.dd_docs_extraction import Document
from fastapi.testclient import TestClient

@pytest.fixture
def client():
    return TestClient(app)

def test_health_endpoint(client):
    response = client.get('/health')
    assert response.status_code == 200
    assert response.json() == {'ok': True}

def test_healthz_env_vars(monkeypatch, client):
    monkeypatch.setenv("GIT_COMMIT", "abc123")
    monkeypatch.setenv("RELEASE_UNIT", "unit42")
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {
        "git_commit": "abc123",
        "release_unit": "unit42"
    }

def test_healthcheck_env_vars(monkeypatch, client):
    monkeypatch.setenv("GIT_COMMIT", "def456")
    monkeypatch.setenv("RELEASE_UNIT", "unit99")
    response = client.get("/healthcheck")
    assert response.status_code == 200
    assert response.json() == {
        "git_commit": "def456",
        "release_unit": "unit99"
    }

def test_extract_dd_docs_with_content(monkeypatch, client):
    mock_result = {'documents': [{'Document': 'Lease', 'Responsible_Party': 'Seller', 'Category': 'Leasing', 'Deadline': '2025-12-01'}]}
    monkeypatch.setattr('Lambda.main.dd_docs_extraction_agent', lambda *a, **kw: mock_result)
    req = {
        'document_input': {'file_name': 'test.pdf', 'content': 'text'},
        'model_name': 'mock-model'
    }
    response = client.post('/dd-docs-extraction/', json=req)
    assert response.status_code == 200
    assert 'documents' in response.json()

def test_extract_text_from_docx():
    from docx import Document as DocxDocument
    temp_docx = tempfile.NamedTemporaryFile(suffix='.docx', delete=False)
    doc = DocxDocument()
    doc.add_paragraph('Test paragraph')
    doc.save(temp_docx.name)
    text = extract_text_from_docx(Path(temp_docx.name))
    assert 'Test paragraph' in text
    Path(temp_docx.name).unlink()
