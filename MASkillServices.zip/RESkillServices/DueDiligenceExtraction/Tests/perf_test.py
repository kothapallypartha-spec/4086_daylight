import os
import sys
import boto3
import logging
from botocore.config import Config
import requests
import json
from pathlib import Path
import time
from statistics import mean, quantiles

DEBUG = True
logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger()
model_name = "OpenAI_gpt-5.1-2025-11-13_Daylight-RE_nonprod"

if "local" in sys.argv:
    URL = "http://localhost:8080/due-diligence-extraction/"
else:
    grp = os.environ.get('ASSET_GROUP', 'ddc1c')   # default to cert for now
    if grp[0] in ['d', 'c']:
        URL = f"https://{grp}-lplus-ai-services.route53.lexis.com/due-diligence-extraction/dd-docs-extraction/"
    else:
        URL = f"https://{grp}-ai-plus-services.route53.lexis.com/due-diligence-extraction/dd-docs-extraction/"

def pre_signed_url_output(file_name):
    """
    Upload file to S3 and generate pre-signed URL for access.
    Uses real AWS S3 (not LocalStack).
    """
    retry_config = Config(
        retries={
            'max_attempts': 5,
            'mode': 'standard'
        }
    )

    os.environ["AWS_DEFAULT_REGION"] = "us-east-1"
    os.environ["AWS_PROFILE"] = "app-fos-nonprod-fosdev"

    bucket_name = "6253-due-diligence-real-estate"
    s3_client = boto3.client('s3', config=retry_config)

    key = 'presigned_urls/' + os.path.basename(file_name)
    logger.info(f"Uploading {file_name} to s3://{bucket_name}/{key}")

    s3_client.upload_file(file_name, Bucket=bucket_name, Key=key)

    pre_signed_url = s3_client.generate_presigned_url(
        ClientMethod="get_object",
        Params={'Bucket': bucket_name, 'Key': key},
        ExpiresIn=3600
    )
    logger.info(f"Generated pre-signed URL: {pre_signed_url}")

    return pre_signed_url


def test_one_doc(fname_stem: str, presigned_url: str):
    """
    Test a single document and return success status with latency.
    Returns: (success: bool, latency_seconds: float)
    """
    logger.info(f"Sending request to {URL}")
    payload = {
        "model_name": model_name,
        "document_input": {
            "file_name": fname_stem,
            "url": presigned_url
        }
    }
    logger.debug(f"Payload: {json.dumps(payload, indent=2)}")
    minute = 60

    start_time = time.time()
    try:
        response = requests.post(
            URL,
            headers={"Content-Type": "application/json"},
            json=payload,
            timeout=5*minute
        )
        latency = time.time() - start_time

        logger.info(f"Response status: {response.status_code}")
        logger.debug(f"Response headers: {response.headers}")

        if response.status_code == 200:
            result = response.json()
            logger.info(f"Success! Latency: {latency:.2f}s")
            return True, latency
        else:
            logger.error(f"Error response: {response.text}")
            try:
                logger.error(response.json()['traceback'])
            except:
                pass
            return False, latency
    except Exception as e:
        latency = time.time() - start_time
        logger.error(f"Request failed with exception: {e}")
        return False, latency


def discover_xhtml_files(data_dir: Path):
    """
    Discover all .xhtml files in the data directory.
    Returns: list of Path objects
    """
    xhtml_files = sorted(data_dir.glob("*.xhtml"))
    logger.info(f"Found {len(xhtml_files)} .xhtml files in {data_dir}")
    return xhtml_files


def run_performance_tests(data_dir: Path):
    """
    Run performance tests on all xhtml files.
    Generates presigned URLs and tests each document sequentially.
    Collects and reports performance metrics.
    """
    # Discover files
    xhtml_files = discover_xhtml_files(data_dir)
    if not xhtml_files:
        logger.error(f"No .xhtml files found in {data_dir}")
        return

    # Generate presigned URLs for all files
    logger.info("=" * 80)
    logger.info("PHASE 1: Generating presigned URLs")
    logger.info("=" * 80)

    presigned_urls = {}
    for xhtml_file in xhtml_files:
        try:
            presigned_url = pre_signed_url_output(str(xhtml_file))
            presigned_urls[xhtml_file.stem] = presigned_url
            logger.info(f"✓ Generated URL for: {xhtml_file.name}")
        except Exception as e:
            logger.error(f"✗ Failed to generate URL for {xhtml_file.name}: {e}")

    logger.info(f"\nSuccessfully generated {len(presigned_urls)} presigned URLs\n")

    # Run performance tests sequentially
    logger.info("=" * 80)
    logger.info("PHASE 2: Running performance tests")
    logger.info("=" * 80)

    results = []
    for i, (file_stem, presigned_url) in enumerate(presigned_urls.items(), 1):
        logger.info(f"\n[{i}/{len(presigned_urls)}] Testing: {file_stem}")
        success, latency = test_one_doc(file_stem, presigned_url)
        results.append({
            'file': file_stem,
            'success': success,
            'latency': latency
        })

    # Generate performance report
    logger.info("\n" + "=" * 80)
    logger.info("PERFORMANCE TEST REPORT")
    logger.info("=" * 80)

    successful = [r for r in results if r['success']]
    failed = [r for r in results if not r['success']]
    latencies = [r['latency'] for r in successful]

    total_count = len(results)
    success_count = len(successful)
    failure_count = len(failed)
    success_rate = (success_count / total_count * 100) if total_count > 0 else 0

    logger.info(f"\nTotal Requests: {total_count}")
    logger.info(f"Successful: {success_count}")
    logger.info(f"Failed: {failure_count}")
    logger.info(f"Success Rate: {success_rate:.2f}%")

    if latencies:
        avg_latency = mean(latencies)
        min_latency = min(latencies)
        max_latency = max(latencies)

        logger.info(f"\nLatency Statistics (successful requests only):")
        logger.info(f"  Average: {avg_latency:.2f}s")
        logger.info(f"  Min: {min_latency:.2f}s")
        logger.info(f"  Max: {max_latency:.2f}s")

        # Calculate p90 if we have enough samples
        if len(latencies) >= 10:
            percentiles = quantiles(latencies, n=100)
            p90_latency = percentiles[89]  # 90th percentile (index 89 for 100 quantiles)
            logger.info(f"  P90: {p90_latency:.2f}s")
        else:
            logger.info(f"  P90: N/A (need at least 10 successful requests)")

    logger.info("\n" + "=" * 80)
    logger.info("Failed Requests:")
    if failed:
        for result in failed:
            logger.info(f"  - {result['file']} (latency: {result['latency']:.2f}s)")
    else:
        logger.info("  None - All requests successful!")

    logger.info("=" * 80)


# Run performance tests on all xhtml files in the data directory
if __name__ == "__main__":
    script_dir = Path(__file__).parent
    data_dir = script_dir / "data_test"

    if not data_dir.exists():
        logger.error(f"Data directory not found: {data_dir}")
        sys.exit(1)

    run_performance_tests(data_dir)
