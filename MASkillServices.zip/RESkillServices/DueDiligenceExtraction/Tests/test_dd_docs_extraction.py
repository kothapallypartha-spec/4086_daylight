import sys
import os
import pytest
from unittest.mock import patch, MagicMock

current_dir = os.path.dirname(os.path.abspath(__file__))
source_dir = os.path.abspath(os.path.join(current_dir, '..', '..', 'Source'))
if source_dir not in sys.path:
    sys.path.insert(0, source_dir)

from Lambda.dd_docs_extraction import Document, DueDiligenceDocument, dd_docs_extraction_agent, DueDiligenceExtractionOutput

def test_document_requires_content_or_url():
    with pytest.raises(ValueError):
        Document.validate({'file_name': 'test.pdf'})
    # Valid cases
    doc1 = Document(file_name='test.pdf', content='text')
    doc2 = Document(file_name='test.pdf', url='http://example.com')
    assert doc1.file_name == 'test.pdf'
    assert doc2.url == 'http://example.com'

def test_category_and_party_validation():
    # Invalid category/party defaults
    doc = DueDiligenceDocument(document='Lease', responsible_party='UnknownParty', document_category='InvalidCat')
    assert doc.document_category == 'Unknown'
    assert doc.responsible_party == 'Unspecified'
    # Valid category/party
    doc2 = DueDiligenceDocument(document='Lease', responsible_party='Seller', document_category='Leasing')
    assert doc2.document_category == 'Leasing'
    assert doc2.responsible_party == 'Seller'

@patch('Lambda.dd_docs_extraction.OpenAI_Like')
def test_dd_docs_extraction_agent(mock_openai):
    # Mock response
    mock_client = MagicMock()
    mock_response = MagicMock()
    mock_choice = MagicMock()
    mock_message = MagicMock()
    mock_message.parsed = DueDiligenceExtractionOutput(documents=[
        DueDiligenceDocument(document='Lease', responsible_party='Seller', document_category='Leasing', deadline='2025-12-01')
    ])
    mock_choice.message = mock_message
    mock_response.choices = [mock_choice]
    mock_client.chat.parse.return_value = mock_response
    mock_openai.return_value = mock_client
    doc = Document(file_name='test.pdf', content='text')
    result = dd_docs_extraction_agent(doc, model_name='mock-model')
    assert isinstance(result, DueDiligenceExtractionOutput)
    assert result.documents[0]['Document'] == 'Lease'
    assert result.documents[0]['Responsible_Party'] == 'Seller'
    assert result.documents[0]['Category'] == 'Leasing'
    assert result.documents[0]['Deadline'] == '2025-12-01'
