import sys
import os
import pytest
from unittest.mock import patch, MagicMock
from pydantic import BaseModel

current_dir = os.path.dirname(os.path.abspath(__file__))
source_dir = os.path.abspath(os.path.join(current_dir, '..', '..', 'Source'))
if source_dir not in sys.path:
    sys.path.insert(0, source_dir)

import Lambda.common.llm_proxy_openai as llm_mod

class DummyModel(BaseModel):
    field1: str
    field2: str

def test_extract_description_direct_docstring():
    class TestClass:
        """Test docstring"""
    assert llm_mod.extract_description(TestClass) == "Test docstring"

def test_extract_description_inherited_docstring():
    class Base:
        """Base doc"""
    class Child(Base):
        pass
    assert llm_mod.extract_description(Child) is None

def test_to_custom_json_schema_structure():
    schema = llm_mod.to_custom_json_schema(DummyModel)
    assert schema["type"] == "json_schema"
    assert "json_schema" in schema
    assert schema["json_schema"]["name"] == "DummyModel"
    assert "field1" in schema["json_schema"]["schema"]["properties"]

def test_chat_completion_structure():
    parsed = DummyModel(field1="a", field2="b")
    chat = llm_mod.ChatCompletion(parsed)
    assert hasattr(chat, "choices")
    assert isinstance(chat.choices[0].message.parsed, DummyModel)

def test_openai_like_client_init(monkeypatch):
    monkeypatch.setenv("GPT_4_1_MINI", "gpt-4.1-mini")
    monkeypatch.setenv("ASSET_ID", "test_id")
    monkeypatch.setenv("AssetGroup", "test_group")
    monkeypatch.setenv("SECRET_NAME", "test_secret")
    with patch("Lambda.common.llm_proxy_openai.SecretsManager") as mock_secrets:
        mock_secrets.return_value.get_secret.return_value = "tenant"
        client = llm_mod.OpenAI_Like()
        assert client.model_name == "gpt-4.1-mini"
        assert client.tenant == "tenant"
        assert hasattr(client, "chat")

def test_chat_completions_parse(monkeypatch):
    # Patch create_simple_proxy to return a mock with chat method
    monkeypatch.setenv("GPT_4_1_MINI", "gpt-4.1-mini")
    monkeypatch.setenv("ASSET_ID", "test_id")
    monkeypatch.setenv("AssetGroup", "test_group")
    monkeypatch.setenv("SECRET_NAME", "test_secret")
    with patch("Lambda.common.llm_proxy_openai.SecretsManager") as mock_secrets, \
         patch("Lambda.common.llm_proxy_openai.create_simple_proxy") as mock_proxy:
        mock_secrets.return_value.get_secret.return_value = "tenant"
        mock_proxy.return_value.chat.return_value = {"field1": "foo", "field2": "bar"}
        client = llm_mod.OpenAI_Like()
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "user"}
        ]
        result = client.chat.parse(
            model="gpt-4.1-mini",
            messages=messages,
            response_format=DummyModel
        )
        assert isinstance(result, llm_mod.ChatCompletion)
        assert result.choices[0].message.parsed.field1 == "foo"
        assert result.choices[0].message.parsed.field2 == "bar"
