import os
import sys
import json
import pytest

current_dir = os.path.dirname(os.path.abspath(__file__))
source_dir = os.path.abspath(os.path.join(current_dir, '..', 'Source'))
if source_dir not in sys.path:
    sys.path.insert(0, source_dir)

from Lambda.aws.secrets import SecretsManager
from Lambda.aws.logger import get_logger

@pytest.fixture
def mock_boto3(monkeypatch):
    class MockSession:
        def __init__(self, client):
            self._client = client
        def client(self, service_name):
            return self._client

    class MockBoto3:
        def __init__(self, session):
            self._session = session
        def Session(self):
            return self._session

    return MockBoto3, MockSession

def test_get_secret_success(monkeypatch, mock_boto3):
    MockBoto3, MockSession = mock_boto3
    mock_client = type('MockClient', (), {})()
    mock_client.get_secret_value = lambda **kwargs: {'SecretString': '{"key": "value"}'}
    monkeypatch.setattr('Lambda.aws.secrets.boto3', MockBoto3(MockSession(mock_client)))
    sm = SecretsManager('test_secret', 'us-east-1')
    assert sm.get_secret('key') == 'value'

def test_get_secret_missing_key(monkeypatch, mock_boto3):
    MockBoto3, MockSession = mock_boto3
    mock_client = type('MockClient', (), {})()
    mock_client.get_secret_value = lambda **kwargs: {'SecretString': '{"key": "value"}'}
    monkeypatch.setattr('Lambda.aws.secrets.boto3', MockBoto3(MockSession(mock_client)))
    sm = SecretsManager('test_secret', 'us-east-1')
    with pytest.raises(KeyError):
        sm.get_secret('missing')

def test_invalid_json(monkeypatch, mock_boto3):
    MockBoto3, MockSession = mock_boto3
    mock_client = type('MockClient', (), {})()
    mock_client.get_secret_value = lambda **kwargs: {'SecretString': 'not-json'}
    monkeypatch.setattr('Lambda.aws.secrets.boto3', MockBoto3(MockSession(mock_client)))
    with pytest.raises(RuntimeError):
        SecretsManager('test_secret', 'us-east-1')

def test_logger_debug_level(monkeypatch):
    monkeypatch.setenv('DEBUG', '1')
    logger = get_logger()
    assert logger.isEnabledFor(10)  # DEBUG level
    monkeypatch.setenv('DEBUG', '0')
    logger = get_logger()
    assert logger.isEnabledFor(20)  # INFO level
