import base64
import json
import os
import time
import xml
from copy import copy
from pathlib import Path
from typing import Tuple, Optional, Dict
import xml.dom.minidom
import grequests

import requests
from lxml import etree
from pydantic import BaseModel
from botocore.config import Config
import boto3
from requests.auth import HTTPBasicAuth

PROD_URL = "https://agent-svc.us.3363-rag-us-prod.sk8s.aws.lexis.com"
STAGING_URL = "https://agent-svc.us.3363-rag-us-staging.sk8s.aws.lexis.com"
CERT_URL = "https://cert-agent-svc.rag-us.use1.dev-searchplatform.nl.lexis.com"
DEV_URL = "http://agent-svc.rag-us.use1.dev-searchplatform.nl.lexis.com"
LOCAL_URL = "http://127.0.0.1:8081"  # Agent service runs on 8081, your DD extraction service is on 8080

VIEW_MORE = "https://agent-svc.rag.us.sk8s.aws.lexis.com/api/v1/proxy/documents/snippets?message_id=9b33a3ed-a5d0-4957-a735-c01f83a33101&content_type=analytical-materials&page=1&size=20"

ENV_DATA = {
    "prod": {"url": PROD_URL, "id": "urn:user:PA195739221", "asset_group": "pdc1c", "user": "protegeuser_1"},
    "staging": {"url": STAGING_URL, "id": "urn:user:PA195739219", "asset_group": "pdc2c", "user": "protegeuser_2"},
    "cert": {"url": CERT_URL, "id": "urn:user:CA200433345", "asset_group": "cdc1c", "user": "LPlusAI0"},  # LPlusAI0 - cert1
    "dev": {"url": DEV_URL, "id": "urn:user:CB204094827", "asset_group": "cdc7c", "user": "LPlusAI0"},  # LPlusAI0 - cert7
    "local": {"url": LOCAL_URL, "id": "urn:user:CB204094827", "asset_group": "cdc7c", "user": "LPlusAI0"}  # LPlusAI0 - cert7
    }
COMMOM_SERVER_ENDPOINT = "-i-services.route53.lexis.com"


def get_auth_tokens(username, password, server):

    request_header = """<rt:requestToken xmlns:rt="http://services.lexisnexis.com/xmlschema/request-token/1"><transactionID>00db4725-1c04-8f59-4fc1-4efca6a765c3</transactionID><sequence>1</sequence><featurePermID/><clientID>test client</clientID><cpmFeatureCode/><billBackString>test</billBackString><contextualFeaturePermID>1000516</contextualFeaturePermID><other><priceToken>Demo</priceToken></other></rt:requestToken>"""
    # According to Brian Rambacher application tokens never expire so hard coding it, ratherthan generating it again

    application_token = """<ns2:applicationToken xmlns:ns2="http://services.lexisnexis.com/xmlschema/application-token/1"><applicationPermID>1000202</applicationPermID><issued>2023-05-14T15:49:03.849Z</issued><signature>v1-29e7a301a1ff3dbbb3552fb00daef426</signature></ns2:applicationToken>"""

    headers = {"Content-Type": "application/xml", "Accept": "application/xml", "X-LN-Request": request_header}

    sso_post_data = (
            "<CreateSSOTokenRequest "
            'xmlns="http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            'xmlns:xsd="http://www.w3.org/2001/XMLSchema"> '
            "<userId>" + username + "</userId><password>" + password + "</password></CreateSSOTokenRequest>"
    )

    headers["X-LN-Application"] = application_token
    tokenUrlSSO = "http://" + server +  COMMOM_SERVER_ENDPOINT + "/identity/accesstoken/sso"

    print("Session call: " + tokenUrlSSO)
    sso_resp_data = requests.post(
        tokenUrlSSO, headers=headers, data=sso_post_data, auth=HTTPBasicAuth("internalsvcs", "3uF6ezaC")
        )

    sso_value = sso_resp_data.text
    xm = xml.dom.minidom.parseString(sso_value)
    sso_token = xm.documentElement.firstChild.firstChild.toxml()
    sso_tag = xm.documentElement.firstChild.toxml()

    # ----------------------- session ------------------------------

    tokenUrlSession = "http://" + server + COMMOM_SERVER_ENDPOINT + "/identity/accesstoken/session"

    session_post_data = (
            "<CreateSessionTokenRequest "
            'xmlns="http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            'xmlns:xsd="http://www.w3.org/2001/XMLSchema"><ssoCookieValue>'
            + sso_token
            + "</ssoCookieValue><lnSessionId>generate</lnSessionId></CreateSessionTokenRequest>"
    )

    print("Session call: " + tokenUrlSession)
    session_resp_data = requests.post(
        tokenUrlSession, headers=headers, data=session_post_data, auth=HTTPBasicAuth("internalsvcs", "3uF6ezaC")
        )
    session_value = session_resp_data.text
    xm = xml.dom.minidom.parseString(session_value)
    session_token = xm.documentElement.toxml()
    print("\n")
    print("X-LN-Session: " + session_token)
    print("--------------------------------------------------------")

    print("X-LN-Application: " + application_token)
    print("--------------------------------------------------------")

    print("X-LN-Request: " + request_header)
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Session: " + session_token.replace('"', '\\"'))
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Application: " + application_token.replace('"', '\\"'))
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Request: " + request_header.replace('"', '\\"'))
    print("--------------------------------------------------------")

    return request_header, application_token, session_token

def get_wam_headers(env):
    asset_group= ENV_DATA[env]["asset_group"]
    user = ENV_DATA[env]["user"]
    request_header, application_token, session_token = get_auth_tokens(user, "Testing99", server=asset_group)
    return {
        "X-LN-Validate-Output": "true",
        "X-LN-Application": application_token,
        "X-LN-Request": request_header,
        "X-LN-Session": session_token,
        }

class DocFileModel(BaseModel):
    document_display_name: str
    upload_identifier: str
    session_identifier: str
    upload_link: str
    document_page_count: Optional[int] = None
    document_character_count: Optional[int] = None


def create_session(agent_host, user_id):
    payload = {
        "user_id": user_id,
        "session_name": user_id,
        "client_id": "test",
        }
    payload = json.dumps(payload)
    headers = {"Content-Type": "application/json"}
    response = requests.request("POST", agent_host + "/api/v1/proxy/sessions", headers=headers, data=payload)
    
    # Debug: print the response
    print("agent_host:", agent_host)
    print("Payload:", payload)
    print(f"Response status code: {response.status_code}")
    print(f"Response body: {response.text}")
    
    response_json = response.json()
    
    # Handle different response structures
    if "data" in response_json:
        session_id = response_json["data"]["session_id"]
    elif "session_id" in response_json:
        session_id = response_json["session_id"]
    else:
        raise KeyError(f"Could not find session_id in response: {response_json}")
    
    print(f"Session ID: {session_id}")
    return session_id

def process_payload(agent_host, user_id, session_id, message, intent, vault_config, headers, highlighted_section=""):
    output_html_path = Path("/Users/kumars59/Documents/VSCode_projects/gen-ai-platform/data/tmp/vault/") / f"{intent.replace('/', '_')}_output.html"


    payload = {
        "user_id": user_id,
        "session_id": session_id,
        "message": message,
        "streaming": True,
        "intent": intent,
        "headers": headers,
        }

    if vault_config:
        payload["data_source"] = vault_config

    if highlighted_section:
        payload["highlighted_section"] = highlighted_section

    payload = json.dumps(payload)
    with open(Path("/Users/kumars59/Documents/VSCode_projects/gen-ai-platform/data/tmp/vault/") / f"{intent.replace('/', '_')}_request.json", "w") as f:
        f.write(payload)
    url = agent_host + "/api/v1/messages_stream"

    with requests.Session() as session:
        with session.post(url, headers=headers, data=payload, stream=True) as response:
            with open(output_html_path, "w", encoding="utf-8") as html_file:
                for line in response.iter_lines():
                    if line:  # filter out keep-alive new chunks
                        line = line.decode("utf-8")
                        if line.startswith(": ping"):
                            continue
                        line = line[len("data: ") :]
                        draft_dict = json.loads(line)
                        html_file.write(f"<p>{json.dumps(draft_dict)}</p>\n")
                        print(draft_dict)
                        if draft_dict["detail-type"] == "conversational-manager-message-finished":
                            return draft_dict

def main():
    CURR_ENV = "local"
    user_id = ENV_DATA[CURR_ENV]["id"]
    agent_host = ENV_DATA[CURR_ENV]["url"]
    message = "Perform the following skill service: Real Estate Due Diligence Docs Extraction"
    intent = "re_dd_docs_extraction_skill"
    vault_config =[
        {
            "type": "dbotf",
            "content_type": "",
            "document_type_filter": [],
            "corpus": [
                "bc542a55-7225-4103-a0d9-3e5693ac93e6/cbd01714-0eea-4f23-9877-0691951f7822/cfeec98f-0c3a-4bd8-bb9b-a414ffdd6fba"
                ],
            "documents": [
                # "05d25473-41c7-4f04-9403-10e1cde98d79",
                "579923b9-d988-433b-9e1d-f171d8c6ac22",
                # "6adecdf7-b8cd-4310-bffd-e58fd46ea7cf",
                # "6de48236-b04a-4ad3-b775-aa05f6403559",
                # "72f0a0aa-39f7-425b-ac63-1df208e46e35",
                # "904fb1a9-4a8c-4701-b230-9d0a6f52dd11",
                # "a954ca68-ea63-4b11-9260-a2640e3c25b3",
                # "aff94bcc-adf9-4a70-a171-18e028450f09",
                # "c08ad8c0-69b2-4805-bcd6-632f081b2dbd"
                ],
            "vault_public_id": "d5b38771-f3f1-4d89-8623-1fe1dfe1fbd2",
            "subvault_public_id": ""
            }
        ]
    # Create a session
    session_id = create_session(agent_host, user_id)

    headers = get_wam_headers(CURR_ENV)
    headers["x-ln-output-format"] = "json"

    output = process_payload(agent_host, user_id, session_id, message, intent, vault_config, headers, highlighted_section="")
    with open(Path("/Users/kumars59/Documents/VSCode_projects/gen-ai-platform/data/tmp/vault/") / f"{intent.replace('/', '_')}_output.json", "w") as f:
        json.dump(output, f, indent=2)

    return output


if __name__ == "__main__":
    print(main())
