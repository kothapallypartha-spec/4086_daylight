import os
import sys
import boto3
import logging
from botocore.config import Config
import requests
import pprint
import json
from pathlib import Path

DEBUG = True
logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger()
model_name = "OpenAI_gpt-4.1-2025-04-14_Daylight-RE_nonprod"

if "local" in sys.argv:
    URL = "http://localhost:8080/due-diligence-extraction/"
else:
    grp = os.environ.get('ASSET_GROUP', 'ddc1c')   # default to cert for now
    if grp[0] in ['d', 'c']:
        URL = f"https://{grp}-lplus-ai-services.route53.lexis.com/due-diligence-extraction/dd-docs-extraction/"
    else:
        URL = f"https://{grp}-ai-plus-services.route53.lexis.com/due-diligence-extraction/dd-docs-extraction/"

def pre_signed_url_output(file_name):
    """
    Upload file to S3 and generate pre-signed URL for access.
    Uses real AWS S3 (not LocalStack).
    """
    retry_config = Config(
        retries={
            'max_attempts': 5,
            'mode': 'standard'
        }
    )

    os.environ["AWS_DEFAULT_REGION"] = "us-east-1"
    os.environ["AWS_PROFILE"] = "app-fos-nonprod-fosdev"

    bucket_name = "6253-due-diligence-real-estate"
    s3_client = boto3.client('s3', config=retry_config)

    key = 'presigned_urls/' + os.path.basename(file_name)
    logger.info(f"Uploading {file_name} to s3://{bucket_name}/{key}")

    s3_client.upload_file(file_name, Bucket=bucket_name, Key=key)

    pre_signed_url = s3_client.generate_presigned_url(
        ClientMethod="get_object",
        Params={'Bucket': bucket_name, 'Key': key},
        ExpiresIn=3600
    )
    logger.info(f"Generated pre-signed URL: {pre_signed_url}")

    return pre_signed_url


def test_one_doc(fname_stem: str, presigned_url: str):
    logger.info(f"Sending request to {URL}")
    payload = {
        "model_name": model_name,
        "document_input": {
            "file_name": fname_stem,
            "url": presigned_url
        }
    }
    logger.info(f"Payload: {json.dumps(payload, indent=2)}")
    minute = 60
    response = requests.post(
        URL,
        headers={"Content-Type": "application/json"},
        json=payload,
        timeout=5*minute
    )

    logger.info(f"Response status: {response.status_code}")
    logger.info(f"Response headers: {response.headers}")

    if response.status_code == 200:
        result = response.json()
        logger.info(f"Success! Result: {json.dumps(result, indent=2)}")
        return result
    else:
        logger.error(f"Error response: {response.text}")
        try:
            print(response.json()['traceback'])
        except:
            pass

    return response


# Run tests
# fname = "Contracts.html"
fname = "psa_10.html"
presigned_url = pre_signed_url_output(fname)
test_one_doc(Path(fname).stem, presigned_url)

# presigned_url = pre_signed_url_output("IntellectualProperty.html")
# test_one_doc(presigned_url)
