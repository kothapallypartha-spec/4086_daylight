import os
import sys
import pytest

current_dir = os.path.dirname(os.path.abspath(__file__))
source_dir = os.path.abspath(os.path.join(current_dir, '..', '..', 'Source'))
if source_dir not in sys.path:
    sys.path.insert(0, source_dir)

from Lambda.common import prompts
from Lambda.common.llm_proxy_openai import ChatCompletion, Choice, Message

def test_prompts_exist():
    assert hasattr(prompts, 'dd_docs_user_prompt')
    assert hasattr(prompts, 'dd_docs_system_prompt')
    assert isinstance(prompts.dd_docs_user_prompt, str)
    assert isinstance(prompts.dd_docs_system_prompt, str)
    assert 'Analyse the following Purchase and Sale Agreement Text' in prompts.dd_docs_user_prompt
    assert 'Role & Objective' in prompts.dd_docs_system_prompt

def test_chat_completion_structure():
    parsed_result = {'key': 'value'}
    chat = ChatCompletion(parsed_result)
    assert isinstance(chat.choices[0], Choice)
    assert isinstance(chat.choices[0].message, Message)
    assert chat.choices[0].message.parsed == parsed_result
