import os
import sys
import logging
import importlib
import pytest

current_dir = os.path.dirname(os.path.abspath(__file__))
source_dir = os.path.abspath(os.path.join(current_dir, '..', '..', 'Source'))
if source_dir not in sys.path:
    sys.path.insert(0, source_dir)

@pytest.fixture(autouse=True)
def reload_logger_module():
    # Ensure fresh import for each test
    if "Lambda.aws.logger" in sys.modules:
        del sys.modules["Lambda.aws.logger"]

def test_get_logger_returns_logger(monkeypatch):
    import Lambda.aws.logger as logger_mod
    logger = logger_mod.get_logger()
    assert isinstance(logger, logging.Logger)

def test_logger_debug_level(monkeypatch):
    monkeypatch.setenv("DEBUG", "1")
    import Lambda.aws.logger as logger_mod
    importlib.reload(logger_mod)
    logger = logger_mod.get_logger()
    assert logger.level == logging.DEBUG or logger.getEffectiveLevel() == logging.DEBUG

def test_logger_info_level(monkeypatch):
    monkeypatch.setenv("DEBUG", "0")
    import Lambda.aws.logger as logger_mod
    importlib.reload(logger_mod)
    logger = logger_mod.get_logger()
    assert logger.level == logging.INFO or logger.getEffectiveLevel() == logging.INFO

def test_logger_singleton(monkeypatch):
    import Lambda.aws.logger as logger_mod
    logger1 = logger_mod.get_logger()
    logger2 = logger_mod.get_logger()
    assert logger1 is logger2

def test_botocore_and_urllib3_loggers_set_to_warning():
    import Lambda.aws.logger as logger_mod
    logger_mod.get_logger()
    for name in [
        "botocore.hooks", "botocore.endpoint", "botocore.utils", "botocore.auth",
        "botocore.credentials", "botocore.loaders", "botocore.client", "botocore.regions",
        "botocore.httpsession", "botocore.parsers", "botocore.retryhandler",
        "urllib3.connectionpool"
    ]:
        assert logging.getLogger(name).level == logging.WARNING or \
               logging.getLogger(name).getEffectiveLevel() == logging.WARNING
