import re
import unicodedata
from typing import List, Dict, Any, Tuple, Optional
from difflib import SequenceMatcher
from lxml import html, etree
import difflib
from typing import Tuple, Optional, Dict, Any, List
from common.text_utils import custom_tokenizer, filter_xml_tags, get_token_positions



_ZW_CHARS = "".join([
    "\u200b",  # zero width space
    "\u200c",  # zero width non-joiner
    "\u200d",  # zero width joiner
    "\ufeff",  # zero width no-break space/ BOM
])
_STRIP_CHARS = "[" + re.escape(_ZW_CHARS + "\xa0" + "\u00ad" + "❑") + "]"  # NBSP, soft hyphen, scan glyphs
_WS = re.compile(r"\s+")
TOK = re.compile(r"[a-z0-9']+")

def normalize_text(s: str) -> str:
    """NFKD + fix punctuation + remove NBSP/soft hyphen/zero-width + collapse spaces + lowercase."""
    if s is None:
        return ""
    t = unicodedata.normalize("NFKD", s)
    # unify punctuation we often see in Aspose/Word HTML exports
    t = (t.replace("–", "-").replace("—", "-")
           .replace("“", '"').replace("”", '"')
           .replace("’", "'"))
    # strip zero-width, NBSP, soft hyphen, stray scanner marks
    t = re.sub(_STRIP_CHARS, " ", t)
    # collapse whitespace and lowercase
    t = _WS.sub(" ", t).strip().lower()
    return t

def text_tokens(s: str) -> List[str]:
    return TOK.findall(normalize_text(s))

def iter_candidate_nodes(body: etree._Element) -> List[etree._Element]:
    """Collect candidate nodes in document order (p/li only)."""
    nodes: List[etree._Element] = []
    for el in body.iter():
        if el.tag in ("p", "li"):
            nodes.append(el)
    return nodes

def node_text_norm(el: etree._Element) -> str:
    """Normalized text_content for a node."""
    return normalize_text(el.text_content() or "")

def is_article_header_text(tnorm: str, n: int) -> bool:
    return bool(re.match(rf"^{n}\.", tnorm))  # e.g., "6. representations and warranties."

def find_article_scope(body: etree._Element, article_num: int) -> List[etree._Element]:
    """Return nodes from the Article N header up to (but not including) the next article header."""
    nodes = iter_candidate_nodes(body)
    start_i = None
    for i, el in enumerate(nodes):
        if el.tag == "p" and is_article_header_text(node_text_norm(el), article_num):
            start_i = i
            break
    if start_i is None:
        return nodes  # fallback to whole doc
    # find the next numbered paragraph like "N+1." or any "\d+."
    end_i = len(nodes)
    for j in range(start_i + 1, len(nodes)):
        if nodes[j].tag == "p" and re.match(r"^\d+\.", node_text_norm(nodes[j])):
            end_i = j
            break
    return nodes[start_i:end_i]

def parse_article_num_from_source_reference(s: str) -> Optional[int]:
    if not s:
        return None
    s2 = s.replace("—", "-").replace("–", "-")
    m = re.search(r"Article\s+(\d+)", s2, flags=re.I)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return None
    return None
    
def locate_by_verbatim(nodes: List[etree._Element], clause_text: str,
                       top_k: int = 1) -> List[Tuple[etree._Element, str, float]]:
    """
    Return top_k candidates as (node, method, score)
    method in {'exact','anchor','fuzzy'}
    """
    targets = normalize_text(clause_text)
    if not targets:
        return []

    # Concatenate scope text with sentinel to enable substring search
    pieces = [node_text_norm(n) for n in nodes]
    sep = "\n"
    doc_text = sep.join(pieces)

    # Precompute node spans in concatenated text
    spans: List[Tuple[int, int]] = []
    pos = 0
    for txt in pieces:
        start = pos
        end = start + len(txt)
        spans.append((start, end))
        pos = end + len(sep)

    def offset_to_node(off: int) -> int:
        # find node whose [start,end] contains off
        # linear scan is fine (docs are short); could binary search if needed
        for i, (a, b) in enumerate(spans):
            if a <= off < b:
                return i
        return max(0, len(spans) - 1)

    candidates: List[Tuple[etree._Element, str, float]] = []

    # 1) Exact normalized substring
    idx = doc_text.find(targets)
    if idx != -1:
        ni = offset_to_node(idx)
        candidates.append((nodes[ni], "exact", 3.0))

    # 2) Anchor snippet search (first ~20 tokens or ~160 chars)
    if not candidates:
        toks = TOK.findall(targets)
        for n_keep in (20, 16, 12, 8):
            if len(toks) >= n_keep:
                anchor = " ".join(toks[:n_keep])
                aidx = doc_text.find(anchor)
                if aidx != -1:
                    ni = offset_to_node(aidx)
                    candidates.append((nodes[ni], "anchor", 2.2))
                    break

    # 3) Fuzzy: rank every node
    if not candidates:
        tgt_tokens = TOK.findall(targets)
        tgt_set = set(tgt_tokens)
        results: List[Tuple[etree._Element, str, float]] = []
        for n, txt in zip(nodes, pieces):
            if not txt:
                continue
            # token recall vs. target (protect against short clauses)
            cand_tokens = set(TOK.findall(txt))
            if not cand_tokens:
                continue
            token_recall = len(tgt_set & cand_tokens) / max(1, len(tgt_set))

            # sequence similarity on normalized strings
            seq_sim = SequenceMatcher(None, txt, targets).ratio()

            # small boost if beginning overlaps
            lead_boost = 0.2 if txt[:80] in targets or targets[:80] in txt else 0.0

            score = 1.3 * token_recall + 0.7 * seq_sim + lead_boost
            results.append((n, "fuzzy", score))

        # keep only the top ones above a small floor
        results.sort(key=lambda r: r[2], reverse=True)
        for cand in results[:max(1, top_k)]:
            if cand[2] > 0.25:
                candidates.append(cand)

    # Deduplicate by element identity and keep top_k by score
    uniq: Dict[etree._Element, Tuple[etree._Element, str, float]] = {}
    for el, m, s in candidates:
        prev = uniq.get(el)
        if prev is None or s > prev[2]:
            uniq[el] = (el, m, s)
    final = sorted(uniq.values(), key=lambda r: r[2], reverse=True)[:max(1, top_k)]
    return final



def get_xpath(html_content, records, no_article_scope = False,top_k=1):
    results=[]
    for rec in records:
        src_ref = rec.get("Source_Reference") or ""
        verb = rec.get("Verbatim_Clause") or ""
        doc  = rec.get("Document") or ""
        tree = html.fromstring(html_content)
        body = tree.find('body')
        # choose search scope
        nodes_scope = iter_candidate_nodes(body)
        if not no_article_scope:
            art_num = parse_article_num_from_source_reference(src_ref)
            if art_num:
                scoped = find_article_scope(body, art_num)
                if scoped:  # only use if we found it
                    nodes_scope = scoped
        
        matches = locate_by_verbatim(nodes_scope, verb, top_k=top_k)
        if not matches:
            results.append({
                "Document": doc,
                "Source_Reference": src_ref,
                "XPath": None,
                "Method": "not_found",
                "Score": 0.0
            })
        
        # Primary (best) result
        best_el, best_method, best_score = matches[0]
        best_xpath = best_el.getroottree().getpath(best_el)
        row = {
            "Document": doc,
            "Source_Reference": src_ref,
            "XPath": best_xpath,
            "Method": best_method,
            "Score": round(float(best_score), 4),
        }
        results.append(row)
    return results


def merge_blocks(blocks, min_gap: int = 1, min_size: int = 2):
    """Merge nearby difflib blocks; mirrors your helper logic."""
    merged = []
    for block in blocks:
        if block.size < min_size:
            continue
        if merged and (block.a - (merged[-1].a + merged[-1].size) <= min_gap) and (block.b - (merged[-1].b + merged[-1].size) <= min_gap):
            last = merged.pop()
            new_size = last.size + (block.a - (last.a + last.size)) + block.size
            merged.append(difflib.Match(last.a, last.b, new_size))
        else:
            merged.append(block)
    return merged


def get_start_end_positions(sentences: List[str],
                        ref_sentence: str,
                        ref_alignments: Optional[List[Tuple[str, int, int]]] = None) -> List[Tuple[int, int]]:
    """
    Given one or more 'sentences' (arbitrary strings), return their (start_inclusive, end_inclusive)
    spans in the reference text by aligning token-by-token to 'ref_alignments'.
    Mirrors the approach in your uploaded helper.
    """
    if not ref_alignments:
        ref_tokens = custom_tokenizer(ref_sentence)
        ref_alignments = get_token_positions(ref_tokens, ref_sentence)

    alignments: List[Tuple[int, int]] = [None] * len(sentences)
    sub_alignments = []
    current_offset = 0
    previous_word_offset = -1
    previous_token = None
    ref_tokens = [t for t, _, _ in ref_alignments]

    for i, sentence in enumerate(sentences):
        last_sentence_start = len(sub_alignments)
        sentence_tokens = custom_tokenizer(sentence)

        for token in sentence_tokens:
            try:
                word_offset = ref_tokens.index(token, current_offset)
            except ValueError:
                word_offset = previous_word_offset + 1

            try:
                start_position = ref_alignments[word_offset][1]
            except Exception:
                start_position = ref_alignments[previous_word_offset + 1][1] if previous_word_offset + 1 < len(ref_alignments) else -1

            if token:
                sub_alignments.append((token, start_position, start_position + len(token) - 1, True))

            if (previous_token is not None) and word_offset - 1 == previous_word_offset:
                sub_alignments[-2] = (sub_alignments[-2][0], sub_alignments[-2][1], sub_alignments[-2][2], False)

            current_offset = word_offset + 1
            previous_word_offset = current_offset - 1
            previous_token = token

            if len(sentence.strip()) > 0:
                sub_alignments[-1] = (sub_alignments[-1][0], sub_alignments[-1][1], sub_alignments[-1][2], True)

        if sub_alignments and (sub_alignments[last_sentence_start][1] > sub_alignments[-1][2]):
            # Best-effort guard (mirrors your helper's warning)
            pass

        alignments[i] = (
            sub_alignments[last_sentence_start][1] if sub_alignments else -1,
            sub_alignments[-1][2] if sub_alignments else -1
        )
    return alignments


def clause_doc_span(cleaned_html: str,
                ref_tokens: List[str],
                ref_alignments: List[Tuple[str, int, int]],
                clause_text: str,
                *,
                min_block_size: int = 2) -> Optional[Tuple[int, int]]:
    """
    Compute the document-level (start_inclusive, end_exclusive) span of the clause by
    token SequenceMatcher (same spirit as your 'match_clauses_to_xpaths').
    """
    clause_tokens = custom_tokenizer(clause_text)
    if not clause_tokens:
        return None

    matcher = difflib.SequenceMatcher(None, ref_tokens, clause_tokens, autojunk=False)
    blocks = merge_blocks(matcher.get_matching_blocks(), min_gap=1, min_size=min_block_size)
    if not blocks:
        return None

    # Map from token indices to character offsets (inclusive -> exclusive)
    first = blocks[0]
    last = blocks[-1]
    # First token char-start
    start_char = ref_alignments[first.a][1]
    # Last token char-end (inclusive -> exclusive)
    end_char_excl = ref_alignments[last.a + last.size - 1][2] + 1
    return (start_char, end_char_excl)


def element_doc_span(html_content: str,
                    cleaned_html: str,
                    ref_alignments: List[Tuple[str, int, int]],
                    xpath: str) -> Optional[Tuple[int, int, str]]:
    """
    Compute the document-level (start_inclusive, end_exclusive) span for the element at `xpath`
    based on its text; also return the element's plain text.
    """
    doc = html.fromstring(html_content)
    elements = doc.xpath(xpath)
    if not elements:
        return None

    el = elements[0]
    el_text = " ".join(el.itertext()).strip()
    if not el_text:
        return None

    # Align the element's text into the ref (returns inclusive/inclusive -> convert)
    (st_inc, en_inc) = get_start_end_positions([el_text], cleaned_html, ref_alignments=ref_alignments)[0]
    if st_inc < 0 or en_inc < 0:
        return None

    return (st_inc, en_inc + 1, el_text)


def intersect(a0: int, a1: int, b0: int, b1: int) -> Optional[Tuple[int, int]]:
    """Return the intersection of [a0,a1) ∩ [b0,b1) if non-empty, else None."""
    s = max(a0, b0)
    e = min(a1, b1)
    return (s, e) if s < e else None


def compute_offsets_for_xpath(html_content: str,
                            xpath: str,
                            clause_text: Optional[str] = None) -> Dict[str, Any]:
    """
    Main one-liner you can call:
        - html_content: full HTML
        - xpath: absolute XPath to the matched element
        - clause_text: the Verbatim_Clause text (optional but recommended)

    Returns a dict with:
        doc_start, doc_end_excl, xpath_doc_start, xpath_doc_end_excl,
        in_xpath_start, in_xpath_end_excl, element_text
    """
    # 1) Build the "tags-as-spaces" reference for stable char positions
    cleaned = filter_xml_tags(html_content)
    ref_tokens = custom_tokenizer(cleaned)
    ref_alignments = get_token_positions(ref_tokens, cleaned)

    # 2) Compute the element's document span
    elem_span = element_doc_span(html_content, cleaned, ref_alignments, xpath)
    if not elem_span:
        return {
            "xpath": xpath,
            "error": "Element not found or empty text."
        }
    xpath_doc_start, xpath_doc_end_excl, elem_text = elem_span

    # 3) If we have the clause text, compute its document span and intersect
    if clause_text:
        cls = clause_doc_span(cleaned, ref_tokens, ref_alignments, clause_text)
        if cls:
            doc_start, doc_end_excl = cls
            inter = intersect(doc_start, doc_end_excl, xpath_doc_start, xpath_doc_end_excl)
            if inter:
                # Element-relative offsets
                in_xpath_start = inter[0] - xpath_doc_start
                in_xpath_end_excl = inter[1] - xpath_doc_start
            else:
                in_xpath_start = None
                in_xpath_end_excl = None
        else:
            doc_start = None
            doc_end_excl = None
            in_xpath_start = None
            in_xpath_end_excl = None
    else:
        # No clause provided: the "clause" defaults to the whole element span
        doc_start = xpath_doc_start
        doc_end_excl = xpath_doc_end_excl
        in_xpath_start = 0
        in_xpath_end_excl = xpath_doc_end_excl - xpath_doc_start

    return {
        "xpath": xpath,
        "doc_start": doc_start,
        "doc_end": doc_end_excl
    }
