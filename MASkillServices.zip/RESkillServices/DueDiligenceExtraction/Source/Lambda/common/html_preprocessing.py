import re
from bs4 import BeautifulSoup

def int_to_roman(n: int) -> str:
    vals = [(1000,"M"),(900,"CM"),(500,"D"),(400,"CD"),
            (100,"C"),(90,"XC"),(50,"L"),(40,"XL"),
            (10,"X"),(9,"IX"),(5,"V"),(4,"IV"),(1,"I")]
    out=[]
    for v,s in vals:
        while n>=v:
            out.append(s); n-=v
    return "".join(out)

def int_to_letters(n: int, lower=True) -> str:
    s=""
    while n>0:
        n, r = divmod(n-1, 26)
        s = chr(65+r) + s
    return s.lower() if lower else s

def _parse_css_rules(css_text: str):
    """
    Extract list formatting from style rules like:
      .awlistX > li:before { content:"(" counter(item, lower-alpha) ") "; }
    Returns:
      rules: {cls: {"kind":"alpha"/"roman", "lower":bool, "prefix":str, "suffix":str}}
      starts: {cls: int}  # from counter-reset
    """
    rules={}
    # content: "..." counter(name, lower-alpha) "..."
    for m in re.finditer(r"\.([A-Za-z0-9_-]+)\s*>\s*li:before\s*\{([^}]*)\}", css_text):
        cls, body = m.group(1), m.group(2)
        mfmt = re.search(
            r"counter\([^,]+,\s*(lower-roman|upper-roman|lower-alpha|upper-alpha|lower-latin|upper-latin)\)",
            body, re.I
        )
        if not mfmt:
            continue
        fmt = mfmt.group(1).lower().replace("latin", "alpha")
        kind = "roman" if "roman" in fmt else "alpha"
        lower = fmt.startswith("lower")
        before, after = body[:mfmt.start()], body[mfmt.end():]
        pre = re.findall(r'"([^"]*)"', before)
        post = re.findall(r'"([^"]*)"', after)
        rules[cls] = {
            "kind": kind, "lower": lower,
            "prefix": (pre[-1] if pre else ""),
            "suffix": (post[0] if post else ""),
        }
    starts = {cls:int(num) for cls, num in re.findall(
        r"\.([A-Za-z0-9_-]+)\s*\{[^}]*counter-reset:[^;{}]*?\s(\d+)", css_text)}
    return rules, starts

def _decide_kind_for_ol(ol, css_rules):
    # From type=
    typ = (ol.get("type") or "").strip()
    if typ in ("i","I"):
        return {"kind":"roman", "lower": typ=="i", "prefix":"", "suffix":". "}
    if typ in ("a","A"):
        return {"kind":"alpha", "lower": typ=="a", "prefix":"", "suffix":") "}

    # From inline style list-style-type
    style = (ol.get("style") or "").lower()
    m = re.search(r"list-style-type\s*:\s*(lower-alpha|upper-alpha|lower-roman|upper-roman)", style)
    if m:
        fmt = m.group(1)
        return {
            "kind": "roman" if "roman" in fmt else "alpha",
            "lower": fmt.startswith("lower"),
            "prefix": "",
            "suffix": ") " if "alpha" in fmt else ". "
        }

    # From CSS class rule (content: counter(...))
    for c in ol.get("class", []):
        if c in css_rules:
            return css_rules[c].copy()

    return None  # not special

def preprocess_html_preserve_enumeration(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    css_text = " ".join(tag.get_text() for tag in soup.find_all("style"))
    css_rules, css_starts = _parse_css_rules(css_text)

    # Track continuation across fragmented lists:
    # key = (kind, lower, prefix, suffix, tuple(sorted(classes)))
    cont_index = {}

    # Iterate all <ol> in document order
    for ol in soup.find_all("ol"):
        fmt = _decide_kind_for_ol(ol, css_rules)
        if not fmt:
            # not alpha/roman; let html2text do normal numerals
            continue

        classes = tuple(sorted(ol.get("class", [])))
        key = (fmt["kind"], fmt["lower"], fmt["prefix"], fmt["suffix"], classes)

        # Determine starting index:
        # 1) explicit start attribute
        start = ol.get("start")
        start = int(start) if start else None
        # 2) CSS counter-reset on the class
        if start is None:
            for c in classes:
                if c in css_starts:
                    start = css_starts[c]
                    break
        # 3) Continue from previous fragmented <ol> with the same signature
        if start is None and key in cont_index:
            start = cont_index[key] + 1
        # 4) Default
        if start is None:
            start = 1

        # Default punctuation if CSS didn’t specify
        prefix = fmt["prefix"]
        suffix = fmt["suffix"] or (") " if fmt["kind"] == "alpha" else ". ")

        idx = start
        # Only direct li children participate in numbering; honor <li value="">
        for li in ol.find_all("li", recursive=False):
            val_attr = li.get("value")
            if val_attr:
                try:
                    idx = int(val_attr)
                except ValueError:
                    pass

            marker = (int_to_roman(idx).lower() if fmt["lower"] and fmt["kind"]=="roman"
                      else int_to_roman(idx) if fmt["kind"]=="roman"
                      else int_to_letters(idx, lower=fmt["lower"]))

            li.insert(0, f"{prefix}{marker}{suffix}")
            cont_index[key] = idx  # remember last used for continuation
            idx += 1

        # Prevent html2text from re-numbering
        ol.name = "ul"

    return str(soup)