from common.llm_proxy_openai import OpenAI_Like
from pydantic import BaseModel, Field, field_validator, constr
from typing import List, Any, Optional, Literal, Dict
import json
import time
from aws.logger import get_logger
from common.prompts import dd_docs_system_prompt, dd_docs_user_prompt
from common.xpath_utils import get_xpath, compute_offsets_for_xpath

logger = get_logger()

# Request document model
class Document(BaseModel):
    file_name: str = Field(..., description="Document title or filename")
    content: str | None = Field(None, description=
        "Full textual content of the document (optional if URL is provided)")
    url: str | None = Field(None, description=
        "Pre-signed URL to the original document (optional if content is provided)")
    headers: dict | None = Field({}, description="Optional headers for HTTP requests")

    @classmethod
    def validate(cls, value):
        if not value.get('content') and not value.get('url'):
            raise ValueError("Either 'content' or 'url' must be provided.")
        return value
    
RESP_ALLOWED = {"Seller", "Buyer", "Both", "Third Party", "Unspecified"}
CAT_ALLOWED = {
    "Leasing","Operations","Financials","Environmental","Physical","Title",
    "Personal Property Liens","Seller's Loan Documents","Survey","Zoning",
    "Corporate","Litigation","Employees","Insurance","Valuation","Unknown","Various"
}

class DueDiligenceDocument(BaseModel):
    """
    Represents one due diligence document extracted from a PSA.
    """

    document: str = Field(
        ...,
        alias="Document",
        description="Exact name or title of the document as written in the PSA."
    )
    responsible_party: Literal["Seller", "Buyer", "Both", "Third Party", "Unspecified"] = Field(
        ...,
        alias="Responsible_Party",
        description="Party responsible for providing or managing the document."
    )
    document_category: Literal[
        "Leasing",
        "Operations",
        "Financials",
        "Environmental",
        "Physical",
        "Title",
        "Personal Property Liens",
        "Seller's Loan Documents",
        "Survey",
        "Zoning",
        "Corporate",
        "Litigation",
        "Employees",
        "Insurance",
        "Valuation",
        "Unknown",
        "Various"
    ] = Field(
        ...,
        alias="Category",
        description="Classification of the document according to predefined due diligence categories."
    )
    deadline: Optional[str] = Field(
        default="See PSA",
        alias="Deadline",
        description="Exact deadline text (fixed date or relative clause) extracted from PSA, or None if not applicable."
    )

    source_reference: constr(strip_whitespace=True, min_length=1) = Field(
        ...,
        alias="Source_Reference",
         description=("Operative-body citation formatted as "
                     "'Section <number[.<number>][(sub)]> — <Heading>' "
                     "optionally followed by '; Article <roman-or-digit-as-in-text> — <Heading>'. "
                     "Preserve the Article numeral exactly as it appears in the PSA."),
    )
    verbatim_clause: str = Field(
        ...,
        alias="Verbatim_Clause",
        min_length=1,
        description="Exact operative-body sentence(s) copied verbatim from the PSA. Use \\n for line breaks."
    )
    xpaths: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        alias="XPaths",
        description="List of XPath locations with offsets for the clause in the document."
    )
    
    class Config:
        populate_by_name = True

    @field_validator("xpaths", mode="before")
    @classmethod
    def _normalize_xpaths(cls, v):
        if v == "" or v is None:
            return None
        if isinstance(v, list):
            return v
        return None

    @field_validator("document_category", mode="before")
    @classmethod
    def _default_unknown_category(cls, v):
        if not isinstance(v, str) or not v.strip() or v.strip() not in CAT_ALLOWED:
            return "Unknown"
        return v.strip()

    @field_validator("responsible_party", mode="before")
    @classmethod
    def _default_unspecified_party(cls, v):
        if not isinstance(v, str) or not v.strip() or v.strip() not in RESP_ALLOWED:
            return "Unspecified"
        return v.strip()

class DueDiligenceExtractionOutput(BaseModel):
    """
    Full output list of due diligence documents extracted from a PSA.
    """
    document_name: str = Field(..., description="Source document filename.", alias="document_name")
    documents: List[DueDiligenceDocument] = Field(
        ...,
        description="Serialized list of due diligence documents with responsible party, category, and deadline."
    )


def dd_docs_extraction_agent(
        doc: Document, *, model_name: str, html_content: str,context: Any = None
    ) -> DueDiligenceExtractionOutput:
    logger.info(f"Starting dd docs extraction with model: {model_name}")
    client = OpenAI_Like(model_name=model_name)
    messages = [
        {"role": "system", "content": dd_docs_system_prompt},
        {"role": "user", "content": dd_docs_user_prompt.format(psa_doc_text=doc.content)}
    ]
    
    start_time = time.time()
    response = client.chat.parse(
        model=model_name,
        messages=messages,
        response_format=DueDiligenceExtractionOutput,
    )
    llm_response_time = time.time() - start_time
    logger.info(f"LLM response time: {llm_response_time:.2f} seconds")
    
    result = DueDiligenceExtractionOutput(
        document_name=doc.file_name,
        documents=response.choices[0].message.parsed.documents
        )    # Prepare records for xpath computation
    records = []
    for extracted_doc in result.documents:
        records.append({
            "Document": extracted_doc.document,
            "Source_Reference": extracted_doc.source_reference,
            "Verbatim_Clause": extracted_doc.verbatim_clause
        })

    # Get XPaths for all records
    xpath_start_time = time.time()
    xpath_results = get_xpath(html_content, records, no_article_scope=True)
    xpath_get_time = time.time() - xpath_start_time
    logger.info(f"get_xpath() time: {xpath_get_time:.2f} seconds for {len(records)} records")

    # Prepare fallback records for failed offset computations
    fallback_records = []
    fallback_indices = []
    
    # Update each document with xpath and offsets
    offset_start_time = time.time()
    for i, extracted_doc in enumerate(result.documents):
        xpath_info = xpath_results[i] if i < len(xpath_results) else {}
        xpath_str = xpath_info.get("XPath")

        # Compute offsets if xpath is available
        offsets = {}
        if xpath_str:
            offsets = compute_offsets_for_xpath(
                html_content=html_content,
                xpath=xpath_str,
                clause_text=extracted_doc.verbatim_clause
            )
            # Collect failed cases for batch processing
            if not offsets.get("doc_start") or not offsets.get("doc_end"):
                fallback_records.append({"Verbatim_Clause": extracted_doc.source_reference})
                fallback_indices.append(i)
        
        # Temporarily store results
        extracted_doc.xpaths = [
            {
                "xpath_value": xpath_str,
                "offsets": offsets
            }
        ] if xpath_str else None
    
    offset_compute_time = time.time() - offset_start_time
    logger.info(f"compute_offsets_for_xpath() time: {offset_compute_time:.2f} seconds")
    
    # Batch process fallback cases
    if fallback_records:
        fallback_start_time = time.time()
        logger.info(f"Processing {len(fallback_records)} fallback records")
        fallback_xpath_results = get_xpath(html_content, fallback_records, no_article_scope=True)
        
        for idx, fallback_xpath_info in enumerate(fallback_xpath_results):
            original_idx = fallback_indices[idx]
            extracted_doc = result.documents[original_idx]
            fallback_xpath = fallback_xpath_info.get("XPath")
            
            if fallback_xpath:
                offsets = compute_offsets_for_xpath(
                    html_content=html_content,
                    xpath=fallback_xpath,
                    clause_text=extracted_doc.source_reference
                )
                # Update with fallback xpath
                extracted_doc.xpaths = [
                    {
                        "xpath_value": fallback_xpath,
                        "offsets": offsets
                    }
                ]
        
        fallback_time = time.time() - fallback_start_time
        logger.info(f"Fallback processing time: {fallback_time:.2f} seconds")
    
    data = {"document_name": doc.file_name, "documents": result.documents}
    result = DueDiligenceExtractionOutput.model_validate(data)
    xpath_processing_time = time.time() - xpath_start_time
    logger.info(f"Total XPath processing time: {xpath_processing_time:.2f} seconds")
    logger.info(f"Extraction complete. Result: {result}")
    return result