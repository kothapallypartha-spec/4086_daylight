import html2text
import os
import re
import traceback
import json
import time
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field
from typing import List, Dict, Any
from mangum import Mangum
from dd_docs_extraction import (
    dd_docs_extraction_agent,
    DueDiligenceExtractionOutput,
    Document
)
from aws.logger import get_logger
from common.html_preprocessing import preprocess_html_preserve_enumeration
import urllib.request

logger = get_logger()
logger.info("Logger initialized")
app = FastAPI(title="Due Diligence Docs Extraction API")

MODEL_NAME = os.getenv("ModelName", "OpenAI_gpt-4.1-2025-04-14_Daylight-RE_nonprod")




class IdentifyRequest(BaseModel):
    """
    This is where we validate the input side of the APP TEAM'S API contract.
    We do not need to validate the ALB→Lambda contract here, that is done in the wrapper.
    """
    document_input: Document
    # more fields as needed, e.g., authentication tokens, request metadata
    model_name: str = Field(MODEL_NAME, description="The name of the model to use for processing")


class ErrorResponse(BaseModel):
    error: str = Field(..., description="Error message")
    traceback: str = Field(..., description="Traceback of the error")
    statusCode: int = Field(500, description="HTTP status code")

    @classmethod
    def from_exception(cls, e: Exception) -> "ErrorResponse":
        tb = traceback.format_exception(type(e), e, e.__traceback__)
        return cls(error=str(e), traceback="".join(tb), statusCode=500)

    @classmethod
    def from_error_message(cls, error: str, statusCode: int = 500) -> "ErrorResponse":
        return cls(error=error, traceback="", statusCode=statusCode)


class OutputModel(BaseModel):
    document_name: str = Field(..., description="Source document filename")
    clauses: List[DueDiligenceExtractionOutput] = Field(..., description="List of Due diligence Docs extraction output")


@app.get("/due-diligence-extraction/healthcheck")
def healthcheck() -> Dict[str, Any]:
    git_commit = os.environ.get("GIT_COMMIT", "")
    release_unit = os.environ.get("RELEASE_UNIT", "")
    return {
        "git_commit": git_commit,
        "release_unit": release_unit
        }

LambdaOutput = ErrorResponse | DueDiligenceExtractionOutput

def log_metric(metric_name: str, value: float, unit: str = "None", **dimensions):
    """
    Log structured metric data for CloudWatch Insights parsing.
    """
    metric_log = {
        "metric_type": "custom_metric",
        "metric_name": metric_name,
        "value": value,
        "unit": unit,
        **dimensions
    }
    logger.info(json.dumps(metric_log))

@app.post("/due-diligence-extraction/")
@app.post("/due-diligence-extraction/dd-docs-extraction/")
async def extract_dd_docs(identify_req: IdentifyRequest) -> LambdaOutput:
    """
    FastAPI automatically parses the request body into IdentifyRequest model.
    """
    start_time = time.time()
    request_success = False

    logger.info(f"Received request for document: {identify_req.document_input.file_name}")
    # result: ErrorResponse | OutputModel = ErrorResponse.from_error_message(
    #     error="Unknown error occurred before processing", statusCode=500
    # )
    try:
        document = identify_req.document_input
        if not document.content:
            if not document.url:
                raise ValueError("Either content or url must be provided.")

            if re.match(".*-la-sp-upload.route53.lexis.com.*upload", document.url) and ("artifacts" not in document.url):
                logger.warning("Manipulating upload URL to point to docxhtml directly")
                document.url = document.url.replace("upload/", "upload/artifacts/")
            req = urllib.request.Request(document.url, headers=document.headers or {})
            
            # Download the file content
            with urllib.request.urlopen(req) as response:
                html = response.read().decode('utf-8')
            h = html2text.HTML2Text()
            h.body_width = 0 
            document.content = h.handle(preprocess_html_preserve_enumeration(html))
            
        dd_doc_extraction_output = dd_docs_extraction_agent(
            document,
            model_name=identify_req.model_name,
            html_content=html,
            context=None
        )
        request_success = True
        latency = (time.time() - start_time) * 1000
        log_metric("RequestLatency", latency, "Milliseconds", status="success")
        log_metric("SuccessfulRequest", 1, "Count")

        return dd_doc_extraction_output
    except Exception as e:
        logger.exception(e)
        latency = (time.time() - start_time) * 1000
        log_metric("RequestLatency", latency, "Milliseconds", status="error")
        log_metric("FailedRequest", 1, "Count")

        error_response = ErrorResponse.from_exception(e)
        raise HTTPException(
            status_code=error_response.statusCode,
            detail={"error": error_response.error, "traceback": error_response.traceback}
            )
    finally:
        # Log total request count
        log_metric("IncomingRequest", 1, "Count")
def f(obj):
    if isinstance(obj, DueDiligenceExtractionOutput):
        return obj.model_dump()
    raise TypeError("Object of type %s is not JSON serializable" % type(obj).__name__)
    # return dd_doc_extraction_output


handler = Mangum(app, lifespan="off")
