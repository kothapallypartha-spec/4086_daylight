"""Structured JSON logging with correlation ID support."""
import json
import logging
import os
import sys
import time
from contextvars import ContextVar
from typing import Any, Dict, Optional


# Context variable for request correlation ID
request_id_var: ContextVar[Optional[str]] = ContextVar("request_id", default=None)


class JSONFormatter(logging.Formatter):
    """Format log records as JSON with correlation ID and structured fields."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON string."""
        log_data: Dict[str, Any] = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add correlation ID if present
        request_id = request_id_var.get()
        if request_id:
            log_data["request_id"] = request_id
        
        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields from LoggerAdapter or record
        if hasattr(record, "extra_fields"):
            log_data.update(record.extra_fields)
        
        return json.dumps(log_data)


class StructuredLogger(logging.LoggerAdapter):
    """Logger adapter that supports structured logging with extra fields."""
    
    def process(self, msg: str, kwargs: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
        """Add extra fields to log record."""
        extra = kwargs.get("extra", {})
        
        # Add correlation ID to extra fields
        request_id = request_id_var.get()
        if request_id:
            extra["request_id"] = request_id
        
        kwargs["extra"] = {"extra_fields": extra}
        return msg, kwargs


_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
_log_format = os.getenv("LOG_FORMAT", "json").lower()  # "json" or "text"

# Configure root logger
if _log_format == "json":
    formatter = JSONFormatter()
else:
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")

handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(formatter)

logging.basicConfig(
    level=getattr(logging, _LEVEL, logging.INFO),
    handlers=[handler],
    force=True
)


def get_logger(name: str) -> StructuredLogger:
    """Return a structured logger with JSON formatting and correlation ID support.
    
    Args:
        name: Logger name (typically __name__)
        
    Returns:
        StructuredLogger instance that supports extra fields
        
    Example:
        logger = get_logger(__name__)
        logger.info("Processing document", extra={"doc_id": "123", "page_count": 10})
    """
    base_logger = logging.getLogger(name)
    base_logger.setLevel(getattr(logging, _LEVEL, logging.INFO))
    return StructuredLogger(base_logger, {})


def set_request_id(request_id: str) -> None:
    """Set correlation ID for current request context.
    
    Args:
        request_id: Unique identifier for the request
    """
    request_id_var.set(request_id)


def get_request_id() -> Optional[str]:
    """Get correlation ID from current request context.
    
    Returns:
        Request ID if set, None otherwise
    """
    return request_id_var.get()


def clear_request_id() -> None:
    """Clear correlation ID from current request context."""
    request_id_var.set(None)
