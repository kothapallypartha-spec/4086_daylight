"""
Evidence Pydantic models for Family 1 (Price & Economics), notebook-approved.
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.common.text_utils import norm_text, coerce_list


class EvidencePurchasePriceAndPaymentMethod(BaseModel):
    model_config = ConfigDict(extra="ignore")
    purchase_price_text: Optional[str] = None
    payment_method_summary: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator("purchase_price_text", "payment_method_summary", mode="before")
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceEarnestMoney(BaseModel):
    model_config = ConfigDict(extra="ignore")
    earnest_money_amount_text: Optional[str] = None
    timing_and_disposition: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator("earnest_money_amount_text", "timing_and_disposition", mode="before")
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceClosingAdjustments(BaseModel):
    model_config = ConfigDict(extra="ignore")
    cutover_datetime_text: Optional[str] = None
    items_prorated: Optional[List[str]] = None
    price_adjustment_events: Optional[List[str]] = None
    post_closing_readjustment: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "cutover_datetime_text",
        "post_closing_readjustment",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "items_prorated",
        "price_adjustment_events",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceClosingCosts(BaseModel):
    model_config = ConfigDict(extra="ignore")
    key_cost_allocations: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator("key_cost_allocations", "seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceBrokerageCommissions(BaseModel):
    model_config = ConfigDict(extra="ignore")
    key_brokerage_terms: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator("key_brokerage_terms", "seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceDealPoints(BaseModel):
    model_config = ConfigDict(extra="ignore")
    purchase_price_and_payment_method: Optional[EvidencePurchasePriceAndPaymentMethod] = None
    earnest_money: Optional[EvidenceEarnestMoney] = None
    closing_adjustments: Optional[EvidenceClosingAdjustments] = None
    closing_costs: Optional[EvidenceClosingCosts] = None
    brokerage_commissions: Optional[EvidenceBrokerageCommissions] = None


class EvidenceDocumentPE(BaseModel):
    model_config = ConfigDict(extra="ignore")
    document_name: str
    deal_points: EvidenceDealPoints
