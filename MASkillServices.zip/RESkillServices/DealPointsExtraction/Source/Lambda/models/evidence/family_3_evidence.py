"""
Evidence Pydantic models for Family 3 (Closing Mechanics & Conditions).
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.common.text_utils import norm_text, coerce_list


class EvidenceClosingMechanics(BaseModel):
    model_config = ConfigDict(extra="ignore")

    closing_date_text: Optional[str] = None
    closing_place_text: Optional[str] = None
    closing_procedure_steps: Optional[List[str]] = None
    adjournment_or_extension_terms: Optional[str] = None
    other_closing_mechanics: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "closing_date_text",
        "closing_place_text",
        "adjournment_or_extension_terms",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "closing_procedure_steps",
        "other_closing_mechanics",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceProceedingsAtClosing(BaseModel):
    model_config = ConfigDict(extra="ignore")

    seller_deliverables: Optional[List[str]] = None
    purchaser_deliverables: Optional[List[str]] = None
    mutual_or_other_deliverables: Optional[List[str]] = None
    title_company_deliverables: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "seller_deliverables",
        "purchaser_deliverables",
        "mutual_or_other_deliverables",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceConditionsToClosing(BaseModel):
    model_config = ConfigDict(extra="ignore")

    buyer_conditions: Optional[List[str]] = None
    seller_conditions: Optional[List[str]] = None
    mutual_conditions: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "buyer_conditions",
        "seller_conditions",
        "mutual_conditions",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidencePossessionAtClosing(BaseModel):
    model_config = ConfigDict(extra="ignore")

    possession_timing_text: Optional[str] = None
    condition_of_possession: Optional[str] = None
    post_closing_occupancy_terms: Optional[str] = None
    keys_and_access_terms: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "possession_timing_text",
        "condition_of_possession",
        "post_closing_occupancy_terms",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "keys_and_access_terms",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceDealPointsCM(BaseModel):
    model_config = ConfigDict(extra="ignore")

    closing_mechanics: Optional[EvidenceClosingMechanics] = None
    proceedings_at_closing: Optional[EvidenceProceedingsAtClosing] = None
    conditions_to_closing: Optional[EvidenceConditionsToClosing] = None
    possession_at_closing: Optional[EvidencePossessionAtClosing] = None


class EvidenceDocumentCM(BaseModel):
    model_config = ConfigDict(extra="ignore")

    document_name: str
    deal_points: EvidenceDealPointsCM
