"""
Evidence Pydantic models for Family 4 (Reps & Covenants).
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.common.text_utils import norm_text, coerce_list


class EvidenceAffirmativeCovenants(BaseModel):
    model_config = ConfigDict(extra="ignore")

    operating_in_ordinary_course_terms: Optional[List[str]] = None
    no_new_burdens_or_title_changes_terms: Optional[List[str]] = None
    leasing_and_rent_concession_terms: Optional[List[str]] = None
    lease_proposals_and_tenant_information_delivery_terms: Optional[List[str]] = None
    security_deposits_and_rent_application_terms: Optional[List[str]] = None
    compliance_and_permits_terms: Optional[List[str]] = None
    notice_and_material_change_terms: Optional[List[str]] = None
    contacts_and_service_agreements_terms: Optional[List[str]] = None
    other_affirmative_covenants_terms: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "operating_in_ordinary_course_terms",
        "no_new_burdens_or_title_changes_terms",
        "leasing_and_rent_concession_terms",
        "lease_proposals_and_tenant_information_delivery_terms",
        "security_deposits_and_rent_application_terms",
        "compliance_and_permits_terms",
        "notice_and_material_change_terms",
        "contacts_and_service_agreements_terms",
        "other_affirmative_covenants_terms",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceSellerWarrantiesRepsCovenants(BaseModel):
    model_config = ConfigDict(extra="ignore")

    summary_of_key_reps: Optional[List[str]] = None
    litigation_or_violation_statements: Optional[List[str]] = None
    seller_promises_facts: Optional[List[str]] = None
    combined_summary_of_reps_warranties: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator("combined_summary_of_reps_warranties", mode="before")
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "summary_of_key_reps",
        "litigation_or_violation_statements",
        "seller_promises_facts",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceBuyerWarrantiesRepsCovenants(BaseModel):
    model_config = ConfigDict(extra="ignore")

    summary_of_key_buyer_reps: Optional[List[str]] = None
    buyer_financial_ability_and_source_of_funds_terms: Optional[List[str]] = None
    buyer_no_conflict_or_violation_statements: Optional[List[str]] = None
    other_buyer_reps_and_covenants_terms: Optional[List[str]] = None
    combined_summary_of_buyer_reps_warranties: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator("combined_summary_of_buyer_reps_warranties", mode="before")
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "summary_of_key_buyer_reps",
        "buyer_financial_ability_and_source_of_funds_terms",
        "buyer_no_conflict_or_violation_statements",
        "other_buyer_reps_and_covenants_terms",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceDealPointsRC(BaseModel):
    model_config = ConfigDict(extra="ignore")

    affirmative_covenants: Optional[EvidenceAffirmativeCovenants] = None
    seller_warranties_reps_covenants: Optional[EvidenceSellerWarrantiesRepsCovenants] = None
    buyer_warranties_reps_covenants: Optional[EvidenceBuyerWarrantiesRepsCovenants] = None


class EvidenceDocumentRC(BaseModel):
    model_config = ConfigDict(extra="ignore")

    document_name: str
    deal_points: EvidenceDealPointsRC
