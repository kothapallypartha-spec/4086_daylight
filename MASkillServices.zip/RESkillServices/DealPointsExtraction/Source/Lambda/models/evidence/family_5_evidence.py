"""
Evidence Pydantic models for Family 5 (Risk Allocation).
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.common.text_utils import norm_text, coerce_list


class EvidenceRiskOfLossAndInsuranceRA(BaseModel):
    model_config = ConfigDict(extra="ignore")

    risk_of_loss_allocation_terms: Optional[str] = None
    casualty_severity_thresholds_and_consequences: Optional[str] = None
    pre_closing_insurance_obligations: Optional[str] = None
    insurance_proceeds_and_assignments: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "risk_of_loss_allocation_terms",
        "casualty_severity_thresholds_and_consequences",
        "pre_closing_insurance_obligations",
        "insurance_proceeds_and_assignments",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceCondemnationRA(BaseModel):
    model_config = ConfigDict(extra="ignore")

    condemnation_triggers_and_notice: Optional[str] = None
    condemnation_minor_vs_major_thresholds: Optional[str] = None
    buyer_rights_in_condemnation: Optional[str] = None
    seller_rights_in_condemnation: Optional[str] = None
    allocation_of_condemnation_awards: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "condemnation_triggers_and_notice",
        "condemnation_minor_vs_major_thresholds",
        "buyer_rights_in_condemnation",
        "seller_rights_in_condemnation",
        "allocation_of_condemnation_awards",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceRemediesDefaultRA(BaseModel):
    model_config = ConfigDict(extra="ignore")

    buyer_default_and_seller_general_remedies: Optional[str] = None
    seller_default_and_buyer_general_remedies: Optional[str] = None
    remedies_for_breach_of_buyer_reps_and_warranties: Optional[str] = None
    remedies_for_breach_of_seller_reps_and_warranties: Optional[str] = None
    remedies_for_failure_of_closing_conditions: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "buyer_default_and_seller_general_remedies",
        "seller_default_and_buyer_general_remedies",
        "remedies_for_breach_of_buyer_reps_and_warranties",
        "remedies_for_breach_of_seller_reps_and_warranties",
        "remedies_for_failure_of_closing_conditions",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceIndemnityRA(BaseModel):
    model_config = ConfigDict(extra="ignore")

    core_seller_indemnity_obligations: Optional[str] = None
    core_buyer_indemnity_obligations: Optional[str] = None
    indemnity_survival_periods_and_notice: Optional[str] = None
    access_and_inspection_indemnity: Optional[str] = None
    environmental_indemnity: Optional[str] = None
    broker_related_indemnity: Optional[str] = None
    escrow_related_indemnity: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "core_seller_indemnity_obligations",
        "core_buyer_indemnity_obligations",
        "indemnity_survival_periods_and_notice",
        "access_and_inspection_indemnity",
        "environmental_indemnity",
        "broker_related_indemnity",
        "escrow_related_indemnity",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceDealPointsRA(BaseModel):
    model_config = ConfigDict(extra="ignore")

    risk_of_loss_and_insurance: Optional[EvidenceRiskOfLossAndInsuranceRA] = None
    condemnation: Optional[EvidenceCondemnationRA] = None
    remedies_default: Optional[EvidenceRemediesDefaultRA] = None
    indemnity: Optional[EvidenceIndemnityRA] = None


class EvidenceDocumentRA(BaseModel):
    model_config = ConfigDict(extra="ignore")

    document_name: str
    deal_points: EvidenceDealPointsRA
