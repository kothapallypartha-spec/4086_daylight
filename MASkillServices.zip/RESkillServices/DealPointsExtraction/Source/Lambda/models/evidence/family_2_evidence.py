"""
Evidence Pydantic models for Family 2 (Due Diligence), notebook-approved.
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.common.text_utils import norm_text, coerce_list


class EvidenceAccessAndInspection(BaseModel):
    model_config = ConfigDict(extra="ignore")

    due_diligence_period_terms: Optional[str] = None
    buyer_rights_terms: Optional[str] = None
    buyer_obligations_terms: Optional[str] = None
    seller_duties_terms: Optional[str] = None
    seller_rights_terms: Optional[str] = None
    due_diligence_materials_terms: Optional[List[str]] = None
    buyer_termination_approval_terms: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "due_diligence_period_terms",
        "buyer_rights_terms",
        "buyer_obligations_terms",
        "seller_duties_terms",
        "seller_rights_terms",
        "buyer_termination_approval_terms",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "due_diligence_materials_terms",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceTitleDD(BaseModel):
    model_config = ConfigDict(extra="ignore")

    title_commitment_terms: Optional[str] = None
    title_objection_procedure: Optional[str] = None
    permitted_exceptions_terms: Optional[str] = None
    seller_cure_terms: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "title_commitment_terms",
        "title_objection_procedure",
        "permitted_exceptions_terms",
        "seller_cure_terms",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceSurveyDD(BaseModel):
    model_config = ConfigDict(extra="ignore")

    survey_requirements: Optional[str] = None
    survey_specifications: Optional[str] = None
    survey_responsibility_terms: Optional[str] = None
    survey_defect_terms: Optional[str] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "survey_requirements",
        "survey_specifications",
        "survey_responsibility_terms",
        "survey_defect_terms",
        mode="before",
    )
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("seq_ids", mode="before")
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceEnvironmentalAssessments(BaseModel):
    model_config = ConfigDict(extra="ignore")

    buyer_access_rights: Optional[List[str]] = None
    responsible_party_for_costs: Optional[List[str]] = None
    seq_ids: Optional[List[int]] = None

    @field_validator(
        "buyer_access_rights",
        "responsible_party_for_costs",
        "seq_ids",
        mode="before",
    )
    def _to_list(cls, v):
        return coerce_list(v)


class EvidenceDealPointsDD(BaseModel):
    model_config = ConfigDict(extra="ignore")

    access_and_inspection: EvidenceAccessAndInspection
    title: EvidenceTitleDD
    survey: EvidenceSurveyDD
    environmental_assessments: EvidenceEnvironmentalAssessments


class EvidenceDocumentDD(BaseModel):
    model_config = ConfigDict(extra="ignore")

    document_name: str
    deal_points: EvidenceDealPointsDD
