# Evidence models package init
from .family_1_evidence import (
    EvidenceDocumentPE,
    EvidenceDealPoints as Family1DealPoints,
    EvidencePurchasePriceAndPaymentMethod as Family1PurchasePriceAndPaymentMethod,
    EvidenceEarnestMoney as Family1EarnestMoney,
    EvidenceClosingAdjustments as Family1ClosingAdjustments,
    EvidenceClosingCosts as Family1ClosingCosts,
    EvidenceBrokerageCommissions as Family1BrokerageCommissions,
    # Re-export base classes from family_1 (these are the canonical definitions)
    EvidencePurchasePriceAndPaymentMethod,
    EvidenceEarnestMoney,
    EvidenceClosingAdjustments,
    EvidenceClosingCosts,
    EvidenceBrokerageCommissions,
    EvidenceDealPoints,
)
# Alias for backward compatibility
EvidenceDocument = EvidenceDocumentPE
from .family_2_evidence import EvidenceDocumentDD, EvidenceDealPointsDD
from .family_3_evidence import EvidenceDocumentCM, EvidenceDealPointsCM
from .family_4_evidence import EvidenceDocumentRC, EvidenceDealPointsRC
from .family_5_evidence import EvidenceDocumentRA, EvidenceDealPointsRA

__all__ = [
    "EvidencePurchasePriceAndPaymentMethod",
    "EvidenceEarnestMoney",
    "EvidenceClosingAdjustments",
    "EvidenceClosingCosts",
    "EvidenceBrokerageCommissions",
    "EvidenceDealPoints",
    "EvidenceDocument",
    "EvidenceDocumentPE",
    "Family1DealPoints",
    "Family1PurchasePriceAndPaymentMethod",
    "Family1EarnestMoney",
    "Family1ClosingAdjustments",
    "Family1ClosingCosts",
    "Family1BrokerageCommissions",
    "EvidenceDocumentDD",
    "EvidenceDealPointsDD",
    "EvidenceDocumentCM",
    "EvidenceDealPointsCM",
    "EvidenceDocumentRC",
    "EvidenceDealPointsRC",
    "EvidenceDocumentRA",
    "EvidenceDealPointsRA",
]
