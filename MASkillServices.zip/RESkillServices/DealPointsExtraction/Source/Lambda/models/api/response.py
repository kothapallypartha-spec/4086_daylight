from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class XPathMapping(BaseModel):
    upload_identifier: str
    xpaths: List[str]
    offsets: List[List[int]]


class DealPointExtractionResponse(BaseModel):
    """Simplified response without widget_data - handled by wrapper after Lambda."""
    deal_points: Dict[str, Any]  # Flattened deal points from all families
    tokens: Dict[str, Any] = {}
    failed_families: Optional[List[Dict[str, Any]]] = None  # Optional: families that failed processing
