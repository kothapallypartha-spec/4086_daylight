from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import AliasChoices, BaseModel, Field, field_validator


class DocumentMetadata(BaseModel):
    document_id: Optional[str] = None
    document_display_name: str = Field(..., validation_alias=AliasChoices("document_display_name", "file_name"))
    upload_identifier: Optional[str] = None
    upload_link: Optional[str] = Field(None, validation_alias=AliasChoices("upload_link", "url"))
    content: Optional[str] = None  # Allow inline HTML content
    headers: Optional[Dict[str, str]] = None
    document_page_count: Optional[int] = None
    document_character_count: Optional[int] = None


class DealPointExtractionRequest(BaseModel):
    user_id: str
    session_id: str
    message: str = Field(default="Extract deal points")
    streaming: bool = False
    intent: Optional[str] = None
    docs: List[DocumentMetadata] = Field(..., validation_alias=AliasChoices("docs", "documents", "document_input"))
    headers: Dict[str, str] = Field(default_factory=dict)
    vault_config: Optional[List[Dict[str, Any]]] = Field(default=None, description="Vault configuration for document enrichment")
    data_source: Optional[List[Dict[str, Any]]] = Field(default=None, description="Data source configuration (alias for vault_config)")
    model_name: Optional[str] = Field(
        None,
        description="Optional LLM model name override. If not provided, uses MODEL_NAME environment variable."
    )

    @field_validator("docs", mode="before")
    @classmethod
    def _ensure_list(cls, v):
        """Ensure docs is a list, even if a single object is provided (e.g. document_input)."""
        if isinstance(v, dict):
            return [v]
        return v

    @field_validator("docs")
    @classmethod
    def validate_single_document(cls, v):
        if len(v) != 1:
            raise ValueError("Exactly 1 document required")
        return v
