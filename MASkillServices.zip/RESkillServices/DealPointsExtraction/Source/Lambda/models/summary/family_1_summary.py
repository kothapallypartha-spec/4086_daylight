from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.models.summary.base_summary import BaseSummaryDealPoint
from Lambda.common.text_utils import norm_text, coerce_list, limit_sentences
from Lambda.config.constants import (
    SENTENCE_LIMIT_EARNEST_MONEY,
    SENTENCE_LIMIT_CLOSING_ADJUSTMENTS,
    SENTENCE_LIMIT_CLOSING_COSTS,
    SENTENCE_LIMIT_BROKERAGE_COMMISSIONS,
)


class PurchasePriceAndPaymentMethod(BaseSummaryDealPoint):
    purchase_price_text: Optional[str] = None
    payment_method_summary: Optional[str] = None
    combined_summary_purchase_price: Optional[str] = None

    @field_validator("purchase_price_text", "payment_method_summary", mode="before")
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_purchase_price", mode="before")
    @classmethod
    def _limit_pp_summary(cls, v):
        return limit_sentences(norm_text(v), 3)


class EarnestMoney(BaseSummaryDealPoint):
    earnest_money_amount_text: Optional[str] = None
    timing_and_disposition: Optional[str] = None
    combined_summary_earnest_money: Optional[str] = None

    @field_validator("earnest_money_amount_text", "timing_and_disposition", mode="before")
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_earnest_money", mode="before")
    @classmethod
    def _limit_em_summary(cls, v):
        return limit_sentences(norm_text(v), SENTENCE_LIMIT_EARNEST_MONEY)


class ClosingAdjustments(BaseSummaryDealPoint):
    cutover_datetime_text: Optional[str] = None
    items_prorated: Optional[List[str]] = None
    price_adjustment_events: Optional[List[str]] = None
    post_closing_readjustment: Optional[str] = None
    combined_summary_closing_adjustments: Optional[str] = None

    @field_validator("cutover_datetime_text", "post_closing_readjustment", mode="before")
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("items_prorated", "price_adjustment_events", "source_section_paths", "source_texts", mode="before")
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_closing_adjustments", mode="before")
    @classmethod
    def _limit_ca_summary(cls, v):
        return limit_sentences(norm_text(v), SENTENCE_LIMIT_CLOSING_ADJUSTMENTS)


class ClosingCosts(BaseSummaryDealPoint):
    key_cost_allocations: Optional[List[str]] = None
    combined_summary_closing_costs: Optional[str] = None

    @field_validator("key_cost_allocations", "source_section_paths", "source_texts", mode="before")
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_closing_costs", mode="before")
    @classmethod
    def _limit_cc_summary(cls, v):
        return limit_sentences(norm_text(v), SENTENCE_LIMIT_CLOSING_COSTS)


class BrokerageCommissions(BaseSummaryDealPoint):
    key_brokerage_terms: Optional[List[str]] = None
    combined_summary_brokerage_commissions: Optional[str] = None

    @field_validator("key_brokerage_terms", "source_section_paths", "source_texts", mode="before")
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_brokerage_commissions", mode="before")
    @classmethod
    def _limit_bc_summary(cls, v):
        return limit_sentences(norm_text(v), SENTENCE_LIMIT_BROKERAGE_COMMISSIONS)


class Family1DealPointsSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    purchase_price_and_payment_method: Optional[PurchasePriceAndPaymentMethod] = None
    earnest_money: Optional[EarnestMoney] = None
    closing_adjustments: Optional[ClosingAdjustments] = None
    closing_costs: Optional[ClosingCosts] = None
    brokerage_commissions: Optional[BrokerageCommissions] = None


class Family1SummaryDocument(BaseModel):
    model_config = ConfigDict(extra="ignore")
    document_name: Optional[str] = None
    deal_points: Optional[Family1DealPointsSummary] = None
