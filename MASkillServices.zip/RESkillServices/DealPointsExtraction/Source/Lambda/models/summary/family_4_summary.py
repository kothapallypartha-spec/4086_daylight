from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.models.summary.base_summary import BaseSummaryDealPoint
from Lambda.common.text_utils import norm_text, coerce_list, limit_sentences


class AffirmativeCovenants(BaseSummaryDealPoint):
    operating_in_ordinary_course_terms: Optional[List[str]] = None
    insurance_maintenance_terms: Optional[List[str]] = None
    no_new_burdens_or_title_changes_terms: Optional[List[str]] = None
    leasing_and_rent_concession_terms: Optional[List[str]] = None
    lease_proposals_and_tenant_information_delivery_terms: Optional[List[str]] = None
    security_deposits_and_rent_application_terms: Optional[List[str]] = None
    contracts_and_service_agreements_terms: Optional[List[str]] = None
    compliance_and_permits_terms: Optional[List[str]] = None
    notice_and_material_change_terms: Optional[List[str]] = None
    contacts_and_service_agreements_terms: Optional[List[str]] = None
    other_affirmative_covenants_terms: Optional[List[str]] = None
    combined_summary_affirmative_covenants: Optional[str] = None

    @field_validator(
        "operating_in_ordinary_course_terms",
        "insurance_maintenance_terms",
        "no_new_burdens_or_title_changes_terms",
        "leasing_and_rent_concession_terms",
        "lease_proposals_and_tenant_information_delivery_terms",
        "security_deposits_and_rent_application_terms",
        "contracts_and_service_agreements_terms",
        "compliance_and_permits_terms",
        "notice_and_material_change_terms",
        "contacts_and_service_agreements_terms",
        "other_affirmative_covenants_terms",
        "source_section_paths",
        "source_texts",
        mode="before",
    )
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_affirmative_covenants", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class SellerWarrantiesRepsCovenants(BaseSummaryDealPoint):
    summary_of_key_reps: Optional[List[str]] = None
    litigation_or_violation_statements: Optional[List[str]] = None
    seller_promises_facts: Optional[List[str]] = None
    combined_summary_of_reps_warranties: Optional[str] = None

    @field_validator(
        "summary_of_key_reps",
        "litigation_or_violation_statements",
        "seller_promises_facts",
        "source_section_paths",
        "source_texts",
        mode="before",
    )
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_of_reps_warranties", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class BuyerWarrantiesRepsCovenants(BaseSummaryDealPoint):
    summary_of_key_buyer_reps: Optional[List[str]] = None
    buyer_financial_ability_and_source_of_funds_terms: Optional[List[str]] = None
    buyer_no_conflict_or_violation_statements: Optional[List[str]] = None
    other_buyer_reps_and_covenants_terms: Optional[List[str]] = None
    combined_summary_of_buyer_reps_warranties: Optional[str] = None

    @field_validator(
        "summary_of_key_buyer_reps",
        "buyer_financial_ability_and_source_of_funds_terms",
        "buyer_no_conflict_or_violation_statements",
        "other_buyer_reps_and_covenants_terms",
        "source_section_paths",
        "source_texts",
        mode="before",
    )
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_of_buyer_reps_warranties", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class Family4DealPointsSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    affirmative_covenants: Optional[AffirmativeCovenants] = None
    seller_warranties_reps_covenants: Optional[SellerWarrantiesRepsCovenants] = None
    buyer_warranties_reps_covenants: Optional[BuyerWarrantiesRepsCovenants] = None


class Family4SummaryDocument(BaseModel):
    model_config = ConfigDict(extra="ignore")
    document_name: Optional[str] = None
    deal_points: Optional[Family4DealPointsSummary] = None
