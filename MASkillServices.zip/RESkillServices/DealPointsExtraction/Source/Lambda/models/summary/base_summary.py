from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, field_validator, model_validator
from Lambda.common.text_utils import norm_text, coerce_list, limit_sentences
from Lambda.config.constants import FALLBACK_NOT_FOUND


class BaseSummaryDealPoint(BaseModel):
    model_config = ConfigDict(extra="ignore")
    source_section_paths: Optional[List[str]] = None
    source_texts: Optional[List[str]] = None
    xpath_mapping: Optional[List[Dict[str, Any]]] = None

    @field_validator("source_section_paths", "source_texts", mode="before")
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)
    
    @model_validator(mode="after")
    def _add_fallback_for_null_summary(self):
        """
        Add fallback message if combined_summary field is None but evidence exists.
        This improves UX by providing context when extraction fails.
        """
        # Find all fields that start with 'combined_summary'
        for field_name in self.model_fields.keys():
            if field_name.startswith("combined_summary"):
                value = getattr(self, field_name, None)
                # Only add fallback if:
                # 1. The combined_summary is None
                # 2. We have source_texts (meaning evidence was found but summary failed)
                if value is None and self.source_texts:
                    setattr(self, field_name, FALLBACK_NOT_FOUND)
        return self
