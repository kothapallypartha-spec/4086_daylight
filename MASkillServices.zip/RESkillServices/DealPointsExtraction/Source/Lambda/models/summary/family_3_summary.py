from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.models.summary.base_summary import BaseSummaryDealPoint
from Lambda.common.text_utils import norm_text, coerce_list, limit_sentences


class ClosingMechanics(BaseSummaryDealPoint):
    closing_date_text: Optional[str] = None
    closing_place_text: Optional[str] = None
    closing_mechanics_text: Optional[str] = None
    funding_and_disbursement_mechanics: Optional[str] = None
    cross_references_to_deliverables: Optional[str] = None
    combined_summary_closing: Optional[str] = None

    @field_validator(
        "closing_date_text",
        "closing_place_text",
        "closing_mechanics_text",
        "funding_and_disbursement_mechanics",
        "cross_references_to_deliverables",
        mode="before",
    )
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_closing", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class ProceedingsAtClosing(BaseSummaryDealPoint):
    seller_closing_deliverables: Optional[List[str]] = None
    purchaser_closing_deliverables: Optional[List[str]] = None
    third_party_or_escrow_deliverables: Optional[List[str]] = None
    closing_procedure_notes: Optional[str] = None
    title_company_deliverables: Optional[List[str]] = None
    combined_summary_proceedings_at_closing: Optional[str] = None

    @field_validator("closing_procedure_notes", mode="before")
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator(
        "seller_closing_deliverables",
        "purchaser_closing_deliverables",
        "third_party_or_escrow_deliverables",
        "title_company_deliverables",
        "source_section_paths",
        "source_texts",
        mode="before",
    )
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_proceedings_at_closing", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class ConditionsToClosing(BaseSummaryDealPoint):
    buyer_requirements: Optional[List[str]] = None
    seller_requirements: Optional[List[str]] = None
    mutual_or_general_conditions: Optional[List[str]] = None
    combined_summary_conditions_to_closing: Optional[str] = None

    @field_validator(
        "buyer_requirements",
        "seller_requirements",
        "mutual_or_general_conditions",
        "source_section_paths",
        "source_texts",
        mode="before",
    )
    @classmethod
    def _to_list(cls, v):
        return coerce_list(v)

    @field_validator("combined_summary_conditions_to_closing", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class PossessionAtClosing(BaseSummaryDealPoint):
    possession_timing_text: Optional[str] = None
    condition_of_property_at_possession: Optional[str] = None
    post_closing_occupancy_or_lease_terms: Optional[str] = None
    holdover_or_early_access_terms: Optional[str] = None
    combined_summary_possession_at_closing: Optional[str] = None

    @field_validator(
        "possession_timing_text",
        "condition_of_property_at_possession",
        "post_closing_occupancy_or_lease_terms",
        "holdover_or_early_access_terms",
        mode="before",
    )
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_possession_at_closing", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class Family3DealPointsSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    closing_mechanics: Optional[ClosingMechanics] = None
    proceedings_at_closing: Optional[ProceedingsAtClosing] = None
    conditions_to_closing: Optional[ConditionsToClosing] = None
    possession_at_closing: Optional[PossessionAtClosing] = None


class Family3SummaryDocument(BaseModel):
    model_config = ConfigDict(extra="ignore")
    document_name: Optional[str] = None
    deal_points: Optional[Family3DealPointsSummary] = None
