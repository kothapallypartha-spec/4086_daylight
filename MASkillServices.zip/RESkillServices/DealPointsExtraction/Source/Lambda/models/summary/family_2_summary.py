from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict


class Family2DealPointsSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    deal_points: Optional[Any] = None


class Family2SummaryDocument(BaseModel):
    model_config = ConfigDict(extra="ignore")
    document_name: Optional[str] = None
    deal_points: Optional[Any] = None
