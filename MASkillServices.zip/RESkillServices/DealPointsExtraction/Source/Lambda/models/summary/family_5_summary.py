from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, field_validator
from Lambda.models.summary.base_summary import BaseSummaryDealPoint
from Lambda.common.text_utils import norm_text, limit_sentences


class RiskOfLossAndInsurance(BaseSummaryDealPoint):
    risk_of_loss_allocation_terms: Optional[str] = None
    casualty_severity_thresholds_and_consequences: Optional[str] = None
    pre_closing_insurance_obligations: Optional[str] = None
    insurance_proceeds_and_assignments: Optional[str] = None
    combined_summary_risk_of_loss_and_insurance: Optional[str] = None

    @field_validator(
        "risk_of_loss_allocation_terms",
        "casualty_severity_thresholds_and_consequences",
        "pre_closing_insurance_obligations",
        "insurance_proceeds_and_assignments",
        mode="before",
    )
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_risk_of_loss_and_insurance", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class Condemnation(BaseSummaryDealPoint):
    condemnation_triggers_and_notice: Optional[str] = None
    condemnation_minor_vs_major_thresholds: Optional[str] = None
    buyer_rights_in_condemnation: Optional[str] = None
    seller_rights_in_condemnation: Optional[str] = None
    allocation_of_condemnation_awards: Optional[str] = None
    combined_summary_condemnation: Optional[str] = None

    @field_validator(
        "condemnation_triggers_and_notice",
        "condemnation_minor_vs_major_thresholds",
        "buyer_rights_in_condemnation",
        "seller_rights_in_condemnation",
        "allocation_of_condemnation_awards",
        mode="before",
    )
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_condemnation", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class RemediesDefault(BaseSummaryDealPoint):
    buyer_default_and_seller_general_remedies: Optional[str] = None
    seller_default_and_buyer_general_remedies: Optional[str] = None
    remedies_for_breach_of_buyer_reps_and_warranties: Optional[str] = None
    remedies_for_breach_of_seller_reps_and_warranties: Optional[str] = None
    remedies_for_failure_of_closing_conditions: Optional[str] = None
    combined_summary_remedies_default: Optional[str] = None

    @field_validator(
        "buyer_default_and_seller_general_remedies",
        "seller_default_and_buyer_general_remedies",
        "remedies_for_breach_of_buyer_reps_and_warranties",
        "remedies_for_breach_of_seller_reps_and_warranties",
        "remedies_for_failure_of_closing_conditions",
        mode="before",
    )
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_remedies_default", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class Indemnity(BaseSummaryDealPoint):
    core_seller_indemnity_obligations: Optional[str] = None
    core_buyer_indemnity_obligations: Optional[str] = None
    indemnity_survival_periods_and_notice: Optional[str] = None
    access_and_inspection_indemnity: Optional[str] = None
    environmental_indemnity: Optional[str] = None
    broker_related_indemnity: Optional[str] = None
    combined_summary_indemnity: Optional[str] = None

    @field_validator(
        "core_seller_indemnity_obligations",
        "core_buyer_indemnity_obligations",
        "indemnity_survival_periods_and_notice",
        "access_and_inspection_indemnity",
        "environmental_indemnity",
        "broker_related_indemnity",
        mode="before",
    )
    @classmethod
    def _norm_str(cls, v):
        return norm_text(v)

    @field_validator("combined_summary_indemnity", mode="before")
    @classmethod
    def _limit_summary(cls, v):
        return limit_sentences(norm_text(v), 5)


class Family5DealPointsSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")
    risk_of_loss_and_insurance: Optional[RiskOfLossAndInsurance] = None
    condemnation: Optional[Condemnation] = None
    remedies_default: Optional[RemediesDefault] = None
    indemnity: Optional[Indemnity] = None


class Family5SummaryDocument(BaseModel):
    model_config = ConfigDict(extra="ignore")
    document_name: Optional[str] = None
    deal_points: Optional[Family5DealPointsSummary] = None
