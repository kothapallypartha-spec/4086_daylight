"""
Lambda entrypoint for deal point extraction.

Flow:
- Accept inline HTML (`event["html"]`) or URL (`event["url"]`).
- Fetch HTML if needed, preprocess to XHTML chunks.
- Run orchestrator to process families.
- Return aggregated JSON. No filesystem writes.

Uses FastAPI + Mangum for ALB compatibility with Application Load Balancer.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import time
import traceback
import urllib.request
import uuid
from typing import Any, Dict, List, Optional

import requests
from fastapi import FastAPI, HTTPException, Request
from mangum import Mangum
from pydantic import BaseModel, Field

from Lambda.preprocessing.xhtml_processor import XHTMLProcessor
from Lambda.preprocessing.html_fetcher import HTMLFetcher
from Lambda.core.orchestrator import Orchestrator
from Lambda.models.api.request import DealPointExtractionRequest, DocumentMetadata
from Lambda.models.api.response import DealPointExtractionResponse
from Lambda.config.settings import config
from common.aws.logger import get_logger, set_request_id, clear_request_id

logger = get_logger(__name__)

# Initialize FastAPI app
app = FastAPI(title="Deal Points Extraction API")

# Log startup with config validation
logger.info(
    "Deal Points Extraction Lambda initialized",
    extra={
        "model_name": config.model_name,
        "log_level": config.log_level,
        "llm_timeout": config.llm_proxy_timeout,
        "environment": config.environment,
    }
)


class ErrorResponse(BaseModel):
    """Error response model with detailed traceback."""
    error: str = Field(..., description="Error message")
    traceback: str = Field(..., description="Traceback of the error")
    statusCode: int = Field(500, description="HTTP status code")

    @classmethod
    def from_exception(cls, e: Exception) -> "ErrorResponse":
        tb = traceback.format_exception(type(e), e, e.__traceback__)
        return cls(error=str(e), traceback="".join(tb), statusCode=500)

    @classmethod
    def from_error_message(cls, error: str, statusCode: int = 500) -> "ErrorResponse":
        return cls(error=error, traceback="", statusCode=statusCode)


@app.get("/deal-points-extraction/healthcheck")
def healthcheck() -> Dict[str, str]:
    """
    Health check endpoint for ALB.
    Returns git commit and release unit for deployment tracking.
    """
    git_commit = os.environ.get("GIT_COMMIT", "")
    release_unit = os.environ.get("RELEASE_UNIT", "")
    return {
        "status": "healthy",
        "git_commit": git_commit,
        "release_unit": release_unit
    }


def _normalize_headers(h: Dict[str, Any]) -> Dict[str, str]:
    """Normalize headers for document fetching."""
    out = {}
    if not h:
        return out
    for k, v in h.items():
        if v is None:
            continue
        key_low = str(k).lower()
        if key_low == 'x-ln-application':
            key = 'X-LN-Application'
        elif key_low == 'x-ln-request':
            key = 'X-LN-Request'
        elif key_low in ('x-ln-session', 'x-ln-sess', 'x-ln-sessionid'):
            key = 'X-LN-Session'
        else:
            key = str(k)

        if isinstance(v, (bytes, bytearray)):
            try:
                val = v.decode('utf-8')
            except Exception:
                val = str(v)
        else:
            val = str(v)
        val = val.replace('\n', '').replace('\r', '').strip()
        out[key] = val
    return out


async def _fetch_document_html(doc: DocumentMetadata, request_headers: Optional[Dict[str, Any]]) -> str:
    """Fetch HTML content from document content or upload link."""
    if doc.content:
        logger.info("using_inline_html", extra={"content_length": len(doc.content)})
        return doc.content
    
    if doc.upload_link:
        raw_headers = (doc.headers or {}) or (request_headers or {})
        headers = _normalize_headers(raw_headers)
        try:
            html = await HTMLFetcher.fetch(doc.upload_link, headers=headers)
            logger.info("html_fetched_successfully", extra={
                "content_length": len(html), 
                "fetched_from": doc.upload_link
            })
            return html
        except Exception as e:
            logger.error("failed_to_fetch_document", extra={"error": str(e)})
            raise ValueError(f"Failed to fetch document from URL: {str(e)}")
            
    raise ValueError("Document must have either 'content' or 'upload_link'")


@app.middleware("http")
async def log_requests(request: Request, call_next):
    body = await request.body()
    logger.info(f"Incoming request: {request.method} {request.url} Body: {body.decode('utf-8')[:1000]}")
    
    # We need to replace the request body so the next handler can read it
    def receive():
        return {"type": "http.request", "body": body}
    
    request._receive = receive
    
    response = await call_next(request)
    logger.info(f"Response status: {response.status_code}")
    return response


@app.middleware("http")
async def add_request_id_middleware(request: Request, call_next):
    """Add correlation ID to all requests for tracing."""
    request_id = str(uuid.uuid4())
    set_request_id(request_id)
    
    # Add request ID to response headers
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    
    # Clear context after request
    clear_request_id()
    return response


@app.post("/deal-points-extraction/")
@app.post("/deal-points-extraction/extract/")
def extract_deal_points(request: DealPointExtractionRequest) -> DealPointExtractionResponse:
    """
    Main endpoint for deal point extraction.
    """
    start_time = time.time()
    try:
        doc = request.docs[0]
        logger.info("request_started", extra={
            "document_name": doc.document_display_name,
            "upload_identifier": doc.upload_identifier,
        })
        
        # Determine model name
        model_name = request.model_name or config.model_name
        
        # Fetch HTML content
        try:
            html = asyncio.run(_fetch_document_html(doc, request.headers))
        except ValueError as ve:
            # Handle fetch failure as a structured response if it's a URL issue
            if doc.upload_link:
                return DealPointExtractionResponse(
                    deal_points={},
                    tokens={},
                    failed_families=[{
                        "upload_identifier": doc.upload_identifier,
                        "error": str(ve),
                        "status": 500
                    }]
                )
            raise ve

        # Process HTML to XHTML chunks
        processing_start = time.time()
        chunks = XHTMLProcessor.process(html)
        logger.info("xhtml_processing_complete", extra={
            "chunk_count": len(chunks),
            "duration": round(time.time() - processing_start, 2),
        })
        
        # Run orchestrator
        orchestrator = Orchestrator(model_name=model_name)
        extraction_start = time.time()
        
        result = asyncio.run(
            orchestrator.process_document(
                xhtml_chunks=chunks,
                upload_identifier=doc.upload_identifier,
                document_name=doc.document_display_name,
            )
        )
        
        logger.info("extraction_completed", extra={
            "duration": round(time.time() - extraction_start, 2),
            "total_duration": round(time.time() - start_time, 2),
            "tokens": result.get("tokens_used", 0),
        })
        
        return DealPointExtractionResponse(**result)
        
    except ValueError as ve:
        logger.warning("validation_error", extra={"error": str(ve)})
        error_response = ErrorResponse.from_error_message(str(ve), statusCode=400)
        raise HTTPException(status_code=400, detail=error_response.dict())
    except Exception as e:
        logger.exception("extraction_failed", extra={"error": str(e)})
        error_response = ErrorResponse.from_exception(e)
        raise HTTPException(status_code=500, detail=error_response.dict())


# Mangum handler for AWS Lambda
handler = Mangum(app, lifespan="off")
