"""
XHTML Processor: Convert HTML/XHTML documents into structured chunks for LLM processing.

This module is the FIRST STEP in the deal point extraction pipeline:
1. Takes raw HTML document as input
2. Parses it into semantic chunks (paragraphs, lists, list items)
3. Extracts text content with location metadata (XPath)
4. Preserves character offsets for traceability back to source

Output format:
  - seq_id: Sequential chunk number (document order)
  - xpath: XPath location in document tree (e.g., /html/body/p[5])
  - text: Normalized text content (whitespace cleaned)
  - start_offset: Character position where chunk starts in original HTML
  - end_offset: Character position where chunk ends in original HTML

These chunks are then sent to the LLM for evidence extraction.
"""


import re
from typing import List, Dict, Tuple


from lxml import etree  # type: ignore
from common.aws.logger import get_logger


logger = get_logger(__name__)


# Define which HTML elements constitute a "chunk"
# We extract paragraphs (<p>), ordered lists (<ol>), and list items (<li>)
# These typically contain complete thoughts/clauses in legal documents
FILTER_TAG_ALL = "/html/body//p | /html/body//ol | /html/body//li"




def normalize_text(text: str) -> str:
    """
    Clean and normalize text content for LLM consumption.
    
    Transformations:
    - Replace non-breaking spaces (\u00A0) with regular spaces
    - Collapse multiple whitespace characters into single spaces
    - Remove leading/trailing whitespace
    
    This ensures consistent text formatting in prompts sent to the LLM.
    """
    if not text:
        return ""
    # Convert non-breaking spaces to regular spaces
    text = text.replace("\u00A0", " ")
    # Collapse any sequence of whitespace into single space
    text = re.sub(r"\s+", " ", text.strip())
    return text




def custom_tokenizer(sentence: str):
    """
    Tokenize text while preserving punctuation and whitespace.
    
    This tokenizer:
    - Splits on punctuation characters but keeps them as separate tokens
    - Preserves whitespace sequences as tokens
    - Handles alphanumeric text as word tokens
    
    Used for precise character offset calculation when mapping
    tokens back to the original HTML source.
    
    Returns: List of token strings
    """
    if isinstance(sentence, float):
        return []
    if not sentence:
        return []

    # Extract all punctuation characters from the sentence
    tokenization_chars = set(re.sub(r"[\sA-Za-z0-9\u00C0-\u017F]+", "", sentence))
    
    # Build regex that splits on each punctuation char (captured) and whitespace
    split_regex = "|".join("(" + re.escape(x) + ")" for x in tokenization_chars)
    if split_regex:
        split_regex += "|"
    split_regex += r"(\s+)"  # Also split on whitespace
    
    # Split and filter empty tokens
    splits = re.split(split_regex, sentence)
    tokens = [y for y in splits if y and y.strip()]
    return tokens




def filter_xml_tags(xml_text: str) -> str:
    """
    Replace tags with spaces of equal length.


    This preserves the string length so that offsets on the cleaned
    string match positions in the original XHTML.
    """
    return re.sub(r"<[^<]+>", lambda m: " " * len(m.group()), xml_text)




def get_token_positions(tokens: List[str], text: str) -> List[Tuple[str, int, int]]:
    """
    Align each token to its start and end (inclusive) offsets in the given text.
    """
    alignments = []
    current_offset = 0
    for token in tokens:
        try:
            word_offset = text.index(token, current_offset)
            start_position = word_offset
            end_position = start_position + len(token) - 1
            alignments.append((token, start_position, end_position))
            current_offset = word_offset + len(token)
        except ValueError:
            continue
    return alignments




def get_all_xpaths(html_content: str, filter_tag: str = FILTER_TAG_ALL):
    """
    Extract element text and XPaths from HTML.


    Returns:
        list of (element_text, xpath) ordered as they appear in the document.
    """
    parser = etree.HTMLParser()
    tree = etree.fromstring(html_content, parser)
    tree_with_getpath = etree.ElementTree(tree)


    all_elements = tree.xpath(filter_tag)


    elements = []
    for element in all_elements:
        element_text = " ".join(element.itertext())
        if element_text.strip():
            elements.append((element_text, tree_with_getpath.getpath(element)))
    return elements




def _find_token_offset(token, ref_tokens, ref_alignments, current_offset, previous_word_offset):
    """Helper to find token offset in reference tokens."""
    try:
        word_offset = ref_tokens.index(token, current_offset)
    except ValueError:
        word_offset = previous_word_offset + 1

    try:
        start_position = ref_alignments[word_offset][1]
    except Exception:
        if previous_word_offset + 1 < len(ref_alignments):
            start_position = ref_alignments[previous_word_offset + 1][1]
        else:
            start_position = -1
    return word_offset, start_position


def _process_sentence_tokens(sentence, ref_tokens, ref_alignments, sub_alignments, state):
    """Process tokens for a single sentence and update sub_alignments and state."""
    sentence_tokens = custom_tokenizer(sentence)
    for token in sentence_tokens:
        word_offset, start_position = _find_token_offset(
            token, ref_tokens, ref_alignments, state["current_offset"], state["previous_word_offset"]
        )

        if token:
            sub_alignments.append(
                (token, start_position, start_position + len(token) - 1, True)
            )

        if (state["previous_token"] is not None) and word_offset - 1 == state["previous_word_offset"]:
            sub_alignments[-2] = (
                sub_alignments[-2][0],
                sub_alignments[-2][1],
                sub_alignments[-2][2],
                False,
            )

        state["current_offset"] = word_offset + 1
        state["previous_word_offset"] = state["current_offset"] - 1
        state["previous_token"] = token

        if len(sentence.strip()) > 0:
            sub_alignments[-1] = (
                sub_alignments[-1][0],
                sub_alignments[-1][1],
                sub_alignments[-1][2],
                True,
            )


def get_start_end_positions(sentences, ref_sentence, ref_alignments=None):
    """
    Map each sentence to a (start, end) char offset in ref_sentence.
    ref_alignments is list of (token, start, end) for full ref_sentence.
    """
    if not ref_alignments:
        ref_sentence_tokens = custom_tokenizer(ref_sentence)
        ref_alignments = get_token_positions(ref_sentence_tokens, ref_sentence)

    alignments = [None] * len(sentences)
    sub_alignments = []
    ref_tokens = [t for t, _, _ in ref_alignments]
    state = {
        "current_offset": 0,
        "previous_word_offset": -1,
        "previous_token": None
    }

    for i, sentence in enumerate(sentences):
        last_sentence_start = len(sub_alignments)
        _process_sentence_tokens(sentence, ref_tokens, ref_alignments, sub_alignments, state)

        if sub_alignments and len(sub_alignments) > last_sentence_start:
            if sub_alignments[last_sentence_start][1] > sub_alignments[-1][2]:
                logger.warning("Something went wrong in alignment detection.")
            alignments[i] = (
                sub_alignments[last_sentence_start][1],
                sub_alignments[-1][2],
            )
        else:
            alignments[i] = (-1, -1)

    return alignments




def _fallback_offsets_from_text(text: str, cleaned_content: str):
    """
    Fallback when alignment fails:
      1) build a whitespace-flexible regex from normalized text
      2) if that fails, try first token exact search
    Returns (start, end) or (-1, -1) if still nothing.
    """
    norm = normalize_text(text)
    if not norm:
        return -1, -1


    # whitespace-flexible regex: spaces -> \s+
    pat = re.escape(norm)
    pat = pat.replace(r"\ ", r"\s+")
    m = re.search(pat, cleaned_content)
    if m:
        return m.start(), m.end() - 1


    # fallback: first token
    tokens = custom_tokenizer(norm)
    if not tokens:
        return -1, -1


    first = tokens[0]
    idx = cleaned_content.find(first)
    if idx == -1:
        return -1, -1


    # crude span based on length of norm
    return idx, idx + len(norm) - 1




def compute_xpath_offsets(html_content: str, filter_tag: str = FILTER_TAG_ALL):
    """
    Compute start and end offsets for each xpath in an XHTML document.


    Offsets:
      - 0 based
      - inclusive
      - measured on original html_content string
    """
    logger.info("Building cleaned_content by masking tags with spaces")
    cleaned_content = filter_xml_tags(html_content)


    logger.info("Tokenizing cleaned_content and computing token positions")
    ref_sentence_tokens = custom_tokenizer(cleaned_content)
    ref_alignments = get_token_positions(ref_sentence_tokens, cleaned_content)


    logger.info("Extracting xpaths and texts from HTML")
    all_xpaths = get_all_xpaths(html_content, filter_tag=filter_tag)
    total_expected = len(all_xpaths)
    if not all_xpaths:
        logger.warning("No xpaths found for this file")
        return []


    sentences = [text for text, _ in all_xpaths]


    logger.info("Aligning each xpath text to cleaned_content offsets")
    alignments = get_start_end_positions(sentences, cleaned_content, ref_alignments)


    rows = []
    failed = 0


    for (raw_text, xpath), (start_pos, end_pos) in zip(all_xpaths, alignments):
        # If alignment failed, try fallback string search
        if (
            start_pos is None
            or end_pos is None
            or start_pos < 0
            or end_pos < start_pos
        ):
            fb_start, fb_end = _fallback_offsets_from_text(raw_text, cleaned_content)
            start_pos, end_pos = fb_start, fb_end


        if start_pos < 0 or end_pos < start_pos:
            failed += 1
            logger.debug("Failed to align xpath %s", xpath)
            continue


        rows.append(
            {
                "xpath": xpath,
                "raw_text": raw_text,
                "start_offset": int(start_pos),
                "end_offset": int(end_pos),
            }
        )


    logger.info(
        "Computed offsets for %d xpath nodes (expected %d, failed %d)",
        len(rows),
        total_expected,
        failed,
    )
    return rows




class XHTMLProcessor:
    """Process HTML/XHTML content into chunks with offsets, matching html_to_json.py logic."""


    @staticmethod
    def process(html_content: str) -> List[Dict]:
        """
        Process HTML content into chunks with seq_id, xpath, text, start_offset, end_offset.


        Args:
            html_content: Raw HTML/XHTML content as string


        Returns:
            List of chunk dictionaries with:
                - seq_id: Sequential ID (0-based)
                - xpath: XPath of the element
                - text: Normalized text content
                - start_offset: Start character offset in original HTML
                - end_offset: End character offset in original HTML
        """
        offset_rows = compute_xpath_offsets(
            html_content=html_content,
            filter_tag=FILTER_TAG_ALL,
        )


        chunks = []
        for seq_id, row in enumerate(offset_rows):
            normalized = normalize_text(row["raw_text"])
            if not normalized:
                continue
            chunks.append(
                {
                    "seq_id": seq_id,
                    "xpath": row["xpath"],
                    "text": normalized,
                    "start_offset": row["start_offset"],
                    "end_offset": row["end_offset"],
                }
            )


        logger.info(f"Processed {len(chunks)} chunks from HTML content")
        return chunks
