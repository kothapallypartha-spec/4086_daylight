"""
Utility helpers to load flattened XHTML chunk JSON files and produce
structures/CSV outputs that match the experimentation notebook.

Typical use:
  - Point to a directory of per-document chunk JSONs produced by xhtml_processor.
  - Load each file into a list of rows with keys: path, text, seq_id, start/end offsets.
  - Optionally dump a combined CSV with one row per chunk across all documents.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping

JSON_EXT = ".json"


def collect_alignment_files(directory: str, ext: str = JSON_EXT) -> List[Path]:
    """Return sorted list of JSON chunk files in the given directory."""
    root = Path(directory)
    if not root.exists():
        raise FileNotFoundError(f"Directory not found: {directory}")
    return sorted(p for p in root.iterdir() if p.is_file() and p.suffix.lower() == ext.lower())


def load_xhtml_rows_from_file(path: Path) -> List[Dict[str, Any]]:
    """
    Load a single XHTML chunk JSON file and normalize rows.

    Expected input shape per item:
      { "seq_id": int, "xpath": str, "text": str, "start_offset": int, "end_offset": int }
    """
    data = json.loads(path.read_text(encoding="utf-8"))
    rows: List[Dict[str, Any]] = []
    for row in data:
        text = (row.get("text") or "").strip()
        if not text:
            continue
        rows.append(
            {
                "path": row.get("xpath", ""),
                "text": text,
                "seq_id": row.get("seq_id"),
                "start_offset": row.get("start_offset"),
                "end_offset": row.get("end_offset"),
            }
        )
    return rows


def build_dataset(directory: str, ext: str = JSON_EXT) -> Dict[str, List[Dict[str, Any]]]:
    """
    Load all chunk files into a dict keyed by filename.

    Returns:
      { "<file>.json": [ {path, text, seq_id, start_offset, end_offset}, ... ], ... }
    """
    files = collect_alignment_files(directory, ext)
    dataset: Dict[str, List[Dict[str, Any]]] = {}
    for file_path in files:
        rows = load_xhtml_rows_from_file(file_path)
        dataset[file_path.name] = rows
    return dataset


def summarize_dataset(dataset: Mapping[str, List[Mapping[str, Any]]]) -> List[Dict[str, Any]]:
    """Create a simple summary list with filename and row counts."""
    return [{"file": name, "rows": len(rows)} for name, rows in dataset.items()]


def flatten_dict(d: Mapping[str, Any], prefix: str = "") -> Dict[str, Any]:
    """Recursively flatten nested dictionaries using dot notation."""
    out: Dict[str, Any] = {}
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, Mapping):
            out.update(flatten_dict(v, key))
        else:
            out[key] = v
    return out


def write_rows_csv(dataset: Mapping[str, Iterable[Mapping[str, Any]]], output_csv: Path) -> None:
    """
    Write a CSV with one row per chunk across all documents.
    Columns: file, seq_id, path, text, start_offset, end_offset.
    """
    fieldnames = ["file", "seq_id", "path", "text", "start_offset", "end_offset"]
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for file_name, rows in dataset.items():
            for row in rows:
                writer.writerow(
                    {
                        "file": file_name,
                        "seq_id": row.get("seq_id"),
                        "path": row.get("path"),
                        "text": row.get("text"),
                        "start_offset": row.get("start_offset"),
                        "end_offset": row.get("end_offset"),
                    }
                )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Load XHTML chunk JSON files and optionally dump a flattened CSV."
    )
    parser.add_argument(
        "--input-dir",
        required=True,
        help="Directory containing XHTML chunk JSON files (one per document).",
    )
    parser.add_argument(
        "--ext",
        default=JSON_EXT,
        help=f"File extension to load (default: {JSON_EXT}).",
    )
    parser.add_argument(
        "--rows-csv",
        type=Path,
        help="Optional path to write a flattened CSV of all rows.",
    )
    parser.add_argument(
        "--summary-json",
        type=Path,
        help="Optional path to write a summary JSON (filename + row counts).",
    )

    args = parser.parse_args()

    dataset = build_dataset(args.input_dir, args.ext)
    summary = summarize_dataset(dataset)

    print(f"Loaded {len(dataset)} documents from {args.input_dir}")
    for item in summary[:20]:
        print(f"{item['file']}: {item['rows']} rows")

    if args.summary_json:
        args.summary_json.parent.mkdir(parents=True, exist_ok=True)
        args.summary_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Wrote summary JSON -> {args.summary_json}")

    if args.rows_csv:
        write_rows_csv(dataset, args.rows_csv)
        print(f"Wrote rows CSV -> {args.rows_csv}")


if __name__ == "__main__":
    main()
