"""HTML fetcher for DealPointsExtraction service.


Handles fetching HTML/XHTML content from upload links with proper
URL manipulation and header handling for Lexis upload links.
"""
import asyncio
import re
import urllib.request
import urllib.error
from typing import Dict, Optional
from common.aws.logger import get_logger


logger = get_logger(__name__)




class HTMLFetcher:
    """Fetches HTML content from upload links with proper URL handling."""


    @staticmethod
    def _normalize_url(url: str) -> str:
        """
        Normalize Lexis upload URLs to point to the docxhtml artifact.
        """
        # Pattern: *-la-sp-upload.route53.lexis.com*upload
        # Using a simpler check to be more robust
        if "lexis.com" in url and "/upload/" in url:
            # If doesn't have artifacts, add it (matches DueDiligence logic)
            if "/artifacts/" not in url:
                logger.info("Normalizing upload URL to point to artifacts")
                url = url.replace("/upload/", "/upload/artifacts/")
            
            # Ensure it points to docxhtml instead of docx or nothing
            if "docxhtml" not in url:
                if url.endswith("/docx"):
                    url = url.replace("/docx", "/docxhtml")
                else:
                    url = url.rstrip("/") + "/docxhtml"
       
        return url


    @staticmethod
    async def fetch(url: str, headers: Optional[Dict[str, str]] = None) -> str:
        """
        Fetch HTML/XHTML content from the given URL.
       
        Works in both local testing and Lambda environments:
        - Uses standard library urllib (no external dependencies)
        - Handles authentication headers (X-LN-* tokens)
        - Includes timeout to prevent hanging requests
       
        Args:
            url: Upload link URL (may need normalization)
            headers: Optional headers for authentication (e.g., X-LN-* headers)
           
        Returns:
            Raw HTML/XHTML content as string (UTF-8 decoded)
           
        Raises:
            urllib.error.HTTPError: If HTTP request fails
            urllib.error.URLError: If URL is invalid or network error occurs
            ValueError: If response cannot be decoded as UTF-8
            asyncio.TimeoutError: If request times out
        """
        # Normalize URL to ensure it points to docxhtml artifact
        normalized_url = HTMLFetcher._normalize_url(url)
        logger.info(f"Fetching HTML from: {normalized_url}")
       
        # Prepare request with headers
        request_headers = headers or {}
        req = urllib.request.Request(normalized_url, headers=request_headers)
       
        # Fetch content with timeout context manager
        try:
            async with asyncio.timeout(30):
                # Run blocking urllib call in a thread to avoid blocking the event loop
                def _get_content():
                    with urllib.request.urlopen(req) as response:
                        return response.read().decode('utf-8')
                
                html_content = await asyncio.to_thread(_get_content)
           
            logger.info(f"Successfully fetched HTML content ({len(html_content)} chars)")
            return html_content
           
        except asyncio.TimeoutError:
            logger.error(f"Timeout fetching {normalized_url} after 30 seconds")
            raise
        except urllib.error.HTTPError as e:
            logger.error(f"HTTP error {e.code} fetching {normalized_url}: {e.reason}")
            raise
        except urllib.error.URLError as e:
            logger.error(f"URL error fetching {normalized_url}: {e.reason}")
            raise
        except UnicodeDecodeError as e:
            logger.error(f"Failed to decode response as UTF-8: {e}")
            raise ValueError(f"Response is not valid UTF-8: {e}") from e
