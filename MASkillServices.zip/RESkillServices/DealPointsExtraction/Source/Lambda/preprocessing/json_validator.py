"""
JSON validation and repair module for LLM responses.

Handles common issues with LLM-generated JSON:
- Incomplete JSON (truncated responses)
- Unescaped control characters
- Missing closing braces/brackets
- Invalid trailing commas
- Mixed quote styles
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, Optional
from common.aws.logger import get_logger

logger = get_logger(__name__)


class JSONValidator:
    """Validates and repairs JSON from LLM responses."""
    
    @staticmethod
    def validate_and_repair(raw_response: str, max_repair_attempts: int = 3) -> Dict[str, Any]:
        """
        Validate JSON from LLM response with automatic repair attempts.
        
        Args:
            raw_response: Raw JSON string from LLM
            max_repair_attempts: Number of repair strategies to attempt
            
        Returns:
            Parsed JSON dict
            
        Raises:
            ValueError: If JSON cannot be parsed after all repair attempts
        """
        # Step 1: Clean up code blocks
        cleaned = JSONValidator._extract_json_content(raw_response)
        
        # Step 2: Try direct parsing first
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as initial_error:
            logger.warning(
                f"Initial JSON parsing failed at position {initial_error.pos}",
                extra={
                    "error": initial_error.msg,
                    "line": initial_error.lineno,
                    "column": initial_error.colno,
                }
            )
        
        # Step 3: Try repair strategies
        repair_strategies = [
            JSONValidator._fix_unescaped_control_chars,
            JSONValidator._fix_incomplete_json,
            JSONValidator._fix_trailing_commas,
            JSONValidator._fix_mixed_quotes,
            JSONValidator._extract_valid_json_block,
        ]
        
        for attempt, strategy in enumerate(repair_strategies[:max_repair_attempts], 1):
            try:
                logger.info(f"Attempting JSON repair strategy {attempt}/{len(repair_strategies)}: {strategy.__name__}")
                repaired = strategy(cleaned)
                parsed = json.loads(repaired)
                logger.info(f"JSON repair successful using strategy: {strategy.__name__}")
                return parsed
            except ValueError as e:
                logger.debug(f"Strategy {strategy.__name__} failed: {str(e)[:100]}")
                continue
        
        # Step 4: If all strategies fail, raise detailed error
        raise ValueError(
            f"Failed to parse JSON after {max_repair_attempts} repair attempts.\n"
            f"Raw response preview: {cleaned[:200]}...\n"
            f"Last error: {initial_error.msg} at position {initial_error.pos}"
        )
    
    @staticmethod
    def _extract_json_content(raw_response: str) -> str:
        """Remove code block markers and whitespace."""
        cleaned = (
            raw_response.strip()
            .removeprefix("```json")
            .removeprefix("```")
            .removesuffix("```")
            .strip()
        )
        return cleaned
    
    @staticmethod
    def _fix_unescaped_control_chars(json_str: str) -> str:
        """
        Fix unescaped control characters in JSON strings.
        
        Handles:
        - Literal newlines/carriage returns within quoted strings
        - Literal tabs within quoted strings
        - Other control characters
        """
        def escape_control_chars_in_string(match):
            """Escape control characters within a JSON string value."""
            string_content = match.group(1)
            
            # Replace literal control characters with escaped versions
            # Only if not already escaped
            string_content = re.sub(r'(?<!\\)\r\n', r'\\n', string_content)
            string_content = re.sub(r'(?<!\\)\n', r'\\n', string_content)
            string_content = re.sub(r'(?<!\\)\r', r'\\r', string_content)
            string_content = re.sub(r'(?<!\\)\t', r'\\t', string_content)
            
            return f'"{string_content}"'
        
        # Match quoted strings (double quotes only for standard JSON)
        # This regex finds strings and their content, handling escaped quotes
        json_str = re.sub(
            r'"((?:[^"\\]|\\.)*)"',
            escape_control_chars_in_string,
            json_str
        )
        
        return json_str
    
    @staticmethod
    def _fix_incomplete_json(json_str: str) -> str:
        """
        Attempt to fix incomplete JSON by adding missing closing characters.
        
        Counts opening and closing braces/brackets and adds missing ones.
        """
        # Count braces and brackets (ignoring those in strings)
        in_string = False
        escape_next = False
        brace_count = 0
        bracket_count = 0
        
        for char in json_str:
            if escape_next:
                escape_next = False
                continue
            
            if char == '\\':
                escape_next = True
                continue
            
            if char == '"':
                in_string = not in_string
                continue
            
            if not in_string:
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1
                elif char == '[':
                    bracket_count += 1
                elif char == ']':
                    bracket_count -= 1
        
        # Add missing closing characters
        json_str = json_str.rstrip(',')  # Remove trailing comma
        json_str += ']' * bracket_count
        json_str += '}' * brace_count
        
        return json_str
    
    @staticmethod
    def _fix_trailing_commas(json_str: str) -> str:
        """Remove trailing commas before closing brackets/braces."""
        # Remove comma before ]
        json_str = re.sub(r',\s*\]', ']', json_str)
        # Remove comma before }
        json_str = re.sub(r',\s*\}', '}', json_str)
        return json_str
    
    @staticmethod
    def _fix_mixed_quotes(json_str: str) -> str:
        """
        Attempt to fix mixed quote styles in JSON.
        
        Converts single quotes to double quotes where appropriate.
        (This is a heuristic and may not always be correct.)
        """
        # Simple heuristic: replace single quotes with double quotes
        # This is risky but better than nothing for malformed JSON
        # Only do this if the string doesn't contain double quotes
        
        # First, protect already-escaped sequences
        protected = json_str.replace('\\"', '__ESCAPED_QUOTE__')
        
        # Replace single quotes that look like JSON property quotes
        protected = re.sub(r"'([^']*)':", r'"\1":', protected)
        
        # Restore escaped quotes
        protected = protected.replace('__ESCAPED_QUOTE__', '\\"')
        
        return protected
    
    @staticmethod
    def _extract_valid_json_block(json_str: str) -> str:
        """
        Extract the first valid JSON block from the string.
        
        Useful if the LLM response contains JSON followed by explanation text.
        """
        # Try to find a complete JSON object or array
        for start_idx, char in enumerate(json_str):
            if char in '{[':
                # Try to parse from this position
                for end_idx in range(len(json_str), start_idx, -1):
                    try:
                        candidate = json_str[start_idx:end_idx]
                        json.loads(candidate)
                        logger.info(f"Extracted valid JSON block from position {start_idx} to {end_idx}")
                        return candidate
                    except json.JSONDecodeError:
                        continue
        
        # If no valid block found, return original
        return json_str


class JSONRepairLogger:
    """Logs JSON repair attempts and their outcomes."""
    
    def __init__(self):
        self.repairs_attempted = 0
        self.repairs_successful = 0
        self.repair_history = []
    
    def log_repair_attempt(self, strategy: str, success: bool, error: Optional[str] = None):
        """Log a repair attempt."""
        self.repairs_attempted += 1
        if success:
            self.repairs_successful += 1
        
        self.repair_history.append({
            "strategy": strategy,
            "success": success,
            "error": error,
            "attempt_number": self.repairs_attempted,
        })
    
    def get_summary(self) -> Dict[str, Any]:
        """Get repair summary."""
        return {
            "total_attempts": self.repairs_attempted,
            "successful_repairs": self.repairs_successful,
            "success_rate": (
                self.repairs_successful / self.repairs_attempted
                if self.repairs_attempted > 0
                else 0.0
            ),
            "history": self.repair_history,
        }
