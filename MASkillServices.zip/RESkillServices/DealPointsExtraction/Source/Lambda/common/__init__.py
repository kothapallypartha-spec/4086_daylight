# Shared helpers for Lambda components
