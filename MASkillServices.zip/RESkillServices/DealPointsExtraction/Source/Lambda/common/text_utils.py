from __future__ import annotations

import re
from typing import Any, List, Optional


def norm_text(s: Optional[str]) -> Optional[str]:
    if s is None:
        return None
    s = re.sub(r"\s+", " ", str(s)).strip()
    return s or None


def coerce_list(x: Any) -> Optional[List[str]]:
    if x is None:
        return None
    if isinstance(x, list):
        out = [norm_text(i) for i in x if norm_text(i)]
        return out or None
    s = norm_text(x)
    return [s] if s else None


def limit_sentences(s: Optional[str], max_sentences: int = 3) -> Optional[str]:
    if not s:
        return s
    text = norm_text(s)
    if not text:
        return None
    parts = re.split(r"(?<=[.!?])\s+", text)
    if len(parts) <= max_sentences:
        return text
    return " ".join(parts[:max_sentences]).strip()
