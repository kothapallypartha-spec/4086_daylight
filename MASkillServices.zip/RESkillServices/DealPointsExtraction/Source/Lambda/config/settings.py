"""
Application configuration using Pydantic Settings.

Validates all environment variables at startup and provides typed access.
"""
from typing import Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppConfig(BaseSettings):
    """Application configuration loaded from environment variables.
    
    All configuration is validated at startup. Missing required fields
    will raise ValidationError, causing the application to fail fast.
    """
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",  # Ignore extra environment variables
    )
    
    # LLM Configuration
    model_name: str = Field(
        default="OpenAI_gpt-5.1-2025-11-13_Daylight-RE_nonprod",
        description="Default LLM model name"
    )
    
    llm_proxy_tenant: Optional[str] = Field(
        default=None,
        alias="LLM_PROXY_TENANT",
        description="LLM proxy tenant identifier"
    )
    
    llm_proxy_retry: int = Field(
        default=3,
        alias="LLM_PROXY_RETRY",
        description="Number of retries for LLM calls",
        ge=0,
        le=10
    )
    
    llm_proxy_timeout: int = Field(
        default=420,
        alias="LLM_PROXY_TIMEOUT",
        description="Timeout for LLM calls in seconds",
        ge=30,
        le=600
    )
    
    # Logging Configuration
    log_level: str = Field(
        default="INFO",
        alias="LOG_LEVEL",
        description="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)"
    )
    
    log_format: str = Field(
        default="json",
        alias="LOG_FORMAT",
        description="Log format: 'json' or 'text'"
    )
    
    # AWS Configuration
    asset_id: str = Field(
        default="6253",
        alias="ASSET_ID",
        description="Asset ID for AWS resources"
    )
    
    asset_group: str = Field(
        default="ddc4c",
        alias="AssetGroup",
        description="Asset group for deployment"
    )
    
    aws_region: str = Field(
        default="us-east-1",
        alias="AWS_DEFAULT_REGION",
        description="AWS region"
    )
    
    # Deployment Metadata
    git_commit: Optional[str] = Field(
        default=None,
        alias="GIT_COMMIT",
        description="Git commit hash for deployment tracking"
    )
    
    release_unit: Optional[str] = Field(
        default=None,
        alias="RELEASE_UNIT",
        description="Release unit identifier"
    )
    
    environment: str = Field(
        default="dev",
        alias="ENVIRONMENT",
        description="Deployment environment (dev, cert, prod)"
    )
    
    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """Validate log level is one of the standard levels."""
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        v_upper = v.upper()
        if v_upper not in valid_levels:
            raise ValueError(f"log_level must be one of {valid_levels}, got '{v}'")
        return v_upper
    
    @field_validator("log_format")
    @classmethod
    def validate_log_format(cls, v: str) -> str:
        """Validate log format is either 'json' or 'text'."""
        v_lower = v.lower()
        if v_lower not in {"json", "text"}:
            raise ValueError(f"log_format must be 'json' or 'text', got '{v}'")
        return v_lower
    
    @field_validator("environment")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        """Validate environment is one of the expected values."""
        valid_envs = {"dev", "cert", "prod", "ddc1c", "cdc1c", "pdc1c"}
        v_lower = v.lower()
        if v_lower not in valid_envs:
            raise ValueError(f"environment must be one of {valid_envs}, got '{v}'")
        return v_lower


# Singleton instance - validates configuration on module import
# This will fail fast at startup if configuration is invalid
try:
    config = AppConfig()
except Exception as e:
    # Log error and re-raise to prevent application from starting
    import sys
    print(f"FATAL: Configuration validation failed: {e}", file=sys.stderr)
    raise
