"""
Family registry driving models/prompts/model selection for Stage 1.
Extend/update as needed; set enabled=False to skip a family.
"""

from __future__ import annotations

from typing import Dict

from Lambda.models.evidence import (
    EvidenceDocumentPE,
    EvidenceDocumentDD,
    EvidenceDocumentCM,
    EvidenceDocumentRC,
    EvidenceDocumentRA,
)
from Lambda.models.summary.family_1_summary import Family1SummaryDocument
from Lambda.models.summary.family_2_summary import Family2SummaryDocument
from Lambda.models.summary.family_3_summary import Family3SummaryDocument
from Lambda.models.summary.family_4_summary import Family4SummaryDocument
from Lambda.models.summary.family_5_summary import Family5SummaryDocument


FAMILY_REGISTRY: Dict[str, Dict] = {
    "family_1": {
        "name": "Price & Economics",
        "enabled": True,
        "evidence_model": EvidenceDocumentPE,
        "summary_model": Family1SummaryDocument,
        "prompt_family": "family_1",
        "model_name": None,  # fallback to default MODEL_NAME if None
    },
    "family_2": {
        "name": "Due Diligence",
        "enabled": True,
        "evidence_model": EvidenceDocumentDD,
        "summary_model": Family2SummaryDocument,
        "prompt_family": "family_2",
        "model_name": None,
    },
    "family_3": {
        "name": "Closing Mechanics & Conditions",
        "enabled": True,
        "evidence_model": EvidenceDocumentCM,
        "summary_model": Family3SummaryDocument,
        "prompt_family": "family_3",
        "model_name": None,
    },
    "family_4": {
        "name": "Reps & Covenants",
        "enabled": True,
        "evidence_model": EvidenceDocumentRC,
        "summary_model": Family4SummaryDocument,
        "prompt_family": "family_4",
        "model_name": None,
    },
    "family_5": {
        "name": "Risk Allocation",
        "enabled": True,
        "evidence_model": EvidenceDocumentRA,
        "summary_model": Family5SummaryDocument,
        "prompt_family": "family_5",
        "model_name": None,
    },
}


def enabled_families() -> Dict[str, Dict]:
    """Return registry entries for enabled families."""
    return {k: v for k, v in FAMILY_REGISTRY.items() if v.get("enabled", False)}
