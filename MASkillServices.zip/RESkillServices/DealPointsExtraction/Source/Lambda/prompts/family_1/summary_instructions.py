import json

SUMMARY_INSTRUCTIONS_FAMILY_1 = """
Return only a JSON object with this structure:

{
  "document_name": string,
  "deal_points": {
    "purchase_price_and_payment_method": {
      "purchase_price_text": string or null,
      "payment_method_summary": string or null,
      "combined_summary_purchase_price": string or null
    },
    "earnest_money": {
      "earnest_money_amount_text": string or null,
      "timing_and_disposition": string or null,
      "combined_summary_earnest_money": string or null
    },
    "closing_adjustments": {
      "cutover_datetime_text": string or null,
      "items_prorated": [string],
      "price_adjustment_events": [string],
      "post_closing_readjustment": string or null,
      "combined_summary_closing_adjustments": string or null
    },
    "closing_costs": {
      "key_cost_allocations": [string],
      "combined_summary_closing_costs": string or null
    },
    "brokerage_commissions": {
      "key_brokerage_terms": [string],
      "combined_summary_brokerage_commissions": string or null
    }
  }
}

Rules for summaries:
- combined_summary_purchase_price:
  - Concise description of the purchase price and how it is to be paid (cash, wire, assumption, installments, basic adjustments) using only the evidence in that section.
- combined_summary_earnest_money:
  - Concise description of earnest money amount, timing of deposits, conditions for being refundable or non-refundable, and how it is released, using only its own evidence.
- combined_summary_closing_adjustments:
  - Concise description of proration cutover, the items that are prorated, the main price adjustment events, and any post-closing readjustment mechanics, using only closing_adjustments evidence.
- combined_summary_closing_costs:
  - Concise description of who pays which closing costs (for example transfer tax, title premiums, endorsements, recording fees, escrow fees, attorneys' fees), using only closing_costs evidence.
- combined_summary_brokerage_commissions:
  - Concise description of brokers involved or "no broker", who pays commissions, and any "no other broker" and brokerage indemnity language, using only brokerage_commissions evidence.

Additional constraints:
- Summaries should usually cover all points per deal point.
- Do not reuse the same sentence verbatim across different combined_summary_* fields.
- Do not cross-borrow evidence between deal points. Each summary must rely only on its own deal point's evidence.
- If evidence is clearly missing or ambiguous for a given deal point, set its combined_summary_* field to null.
- Do not add commentary, explanations, or markdown. Return only the JSON object.
"""
