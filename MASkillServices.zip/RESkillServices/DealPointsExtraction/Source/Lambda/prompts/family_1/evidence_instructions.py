EVIDENCE_INSTRUCTIONS_FAMILY_1 = """
Return only a valid JSON object with this structure:

{
  "document_name": "string",
  "deal_points": {
    "purchase_price_and_payment_method": {
      "purchase_price_text": "string or null",
      "payment_method_summary": "string or null",
      "seq_ids": [0, 1, 2]
    },
    "earnest_money": {
      "earnest_money_amount_text": "string or null",
      "timing_and_disposition": "string or null",
      "seq_ids": [0, 1, 2]
    },
    "closing_adjustments": {
      "cutover_datetime_text": "string or null",
      "items_prorated": ["string"],
      "price_adjustment_events": ["string"],
      "post_closing_readjustment": "string or null",
      "seq_ids": [0, 1, 2]
    },
    "closing_costs": {
      "key_cost_allocations": ["string"],
      "seq_ids": [0, 1, 2]
    },
    "brokerage_commissions": {
      "key_brokerage_terms": ["string"],
      "seq_ids": [0, 1, 2]
    }
  }
}

Rules:
- Populate only evidence fields and their seq_ids.
- If your schema also contains any combined_summary_* fields, set them explicitly to null in this stage and do not write summaries.
- **IMPORTANT**: For each deal point, include the seq_ids array with the sequence IDs where you found the evidence.
- seq_ids should contain integers representing the SEQ_ID values from the input chunks where the deal point information appears.
- Use short, precise micro-summaries for list fields (items_prorated, price_adjustment_events, key_cost_allocations, key_brokerage_terms) that closely track the contract language.
- If no evidence exists for a deal point in the document, you may set seq_ids to [] (empty array), but include the deal point in your response.
- Do not include commentary, labels, or markdown. Return only the JSON object.
"""
