"""
Prompt builder helpers. Replace with full formatting logic.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List


class PromptBuilder:
    @staticmethod
    def build_evidence_user_prompt(
        document_name: str,
        xhtml_chunks: List[Dict[str, Any]],
        schema_json: Dict[str, Any],
        instructions: str | None = None,
        max_chunks: int = 1000,
    ) -> str:
        lines = []
        for i, r in enumerate(xhtml_chunks[:max_chunks], start=1):
            lines.append(f"[{i}] PATH: {r.get('path','')}\n     TEXT: {r.get('text','')}")
        section = "\n".join(lines)
        return f"""DOCUMENT NAME: {document_name}

DOCUMENT TEXT:
{section}

JSON SCHEMA:
{json.dumps(schema_json, indent=2)}

TASK:
{instructions or ''}

Return only JSON matching the schema."""

    @staticmethod
    def build_summary_user_prompt(document_name: str, evidence_json: Dict[str, Any], instructions: str) -> str:
        pretty = json.dumps(evidence_json, indent=2, ensure_ascii=False)
        return f"""DOCUMENT NAME: {document_name}

EXISTING EVIDENCE JSON:
{pretty}

TASK:
{instructions}

Return only JSON with summary fields populated."""
