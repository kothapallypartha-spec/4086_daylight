EVIDENCE_INSTRUCTIONS_FAMILY_4 = """
Return only a valid JSON object with this structure:

{
  "document_name": "string",
  "deal_points": {
    "affirmative_covenants": {
      "operating_in_ordinary_course_terms": ["string"],
      "no_new_burdens_or_title_changes_terms": ["string"],
      "leasing_and_rent_concession_terms": ["string"],
      "lease_proposals_and_tenant_information_delivery_terms": ["string"],
      "security_deposits_and_rent_application_terms": ["string"],
      "compliance_and_permits_terms": ["string"],
      "notice_and_material_change_terms": ["string"],
      "contacts_and_service_agreements_terms": ["string"],
      "other_affirmative_covenants_terms": ["string"],
      "seq_ids": [0, 1, 2]
    },
    "seller_warranties_reps_covenants": {
      "summary_of_key_reps": ["string"],
      "litigation_or_violation_statements": ["string"],
      "seller_promises_facts": ["string"],
      "combined_summary_of_reps_warranties": "string or null",
      "seq_ids": [0, 1, 2]
    },
    "buyer_warranties_reps_covenants": {
      "summary_of_key_buyer_reps": ["string"],
      "buyer_financial_ability_and_source_of_funds_terms": ["string"],
      "buyer_no_conflict_or_violation_statements": ["string"],
      "other_buyer_reps_and_covenants_terms": ["string"],
      "combined_summary_of_buyer_reps_warranties": "string or null",
      "seq_ids": [0, 1, 2]
    }
  }
}

Rules:
- The shape of your JSON must match this evidence schema exactly.
- Populate only evidence fields and their seq_ids.
- For this Stage 1 task, do not write any combined_summary_* fields. If such keys exist, set them explicitly to null.
- **IMPORTANT**: For each deal point, include the seq_ids array with the sequence IDs where you found the evidence.
- seq_ids should contain integers representing the SEQ_ID values from the input chunks where the deal point information appears.
- For list fields, use short, precise micro summaries that closely track the contract language.
- If no evidence exists for a deal point in the document, you may set seq_ids to [] (empty array), but include the deal point in your response.
- Do not include commentary, labels, or markdown. Return only the JSON object.
"""
