SUMMARY_INSTRUCTIONS_FAMILY_4 = """
Return only a JSON object with this structure:

{
  "document_name": string,
  "deal_points": {
    "affirmative_covenants": {
      "operating_in_ordinary_course_terms": [string],
      "insurance_maintenance_terms": [string],
      "no_new_burdens_or_title_changes_terms": [string],
      "leasing_and_rent_concession_terms": [string],
      "lease_proposals_and_tenant_information_delivery_terms": [string],
      "security_deposits_and_rent_application_terms": [string],
      "contracts_and_service_agreements_terms": [string],
      "compliance_and_permits_terms": [string],
      "notice_and_material_change_terms": [string],
      "contacts_and_service_agreements_terms": [string],
      "other_affirmative_covenants_terms": [string],
      "combined_summary_affirmative_covenants": string or null
    },
    "seller_warranties_reps_covenants": {
      "summary_of_key_reps": [string],
      "litigation_or_violation_statements": [string],
      "seller_promises_facts": [string],
      "combined_summary_of_reps_warranties": string or null
    },
    "buyer_warranties_reps_covenants": {
      "summary_of_key_buyer_reps": [string],
      "buyer_financial_ability_and_source_of_funds_terms": [string],
      "buyer_no_conflict_or_violation_statements": [string],
      "other_buyer_reps_and_covenants_terms": [string],
      "combined_summary_of_buyer_reps_warranties": string or null
    }
  }
}

Rules for summaries:
- combined_summary_affirmative_covenants:
  - Concise description of Seller's (and, if present, Buyer's) forward-looking covenants between signing and Closing,
    including ordinary-course operation, maintenance of insurance, limits on new liens/encumbrances and title burdens,
    leasing and rent concession restrictions, handling of security deposits and rents, rules on new or amended service
    and management contracts, continued legal and permit compliance, and notice obligations for casualty, condemnation,
    tenant/contract defaults, or other material adverse changes, using only affirmative_covenants evidence.

- combined_summary_of_reps_warranties:
  - Concise description of the core Seller representations and warranties, including Seller's authority, existence,
    and power to convey, absence of conflicts, litigation or violations, and key property, lease, contract, permit,
    or disclosure statements, using only seller_warranties_reps_covenants evidence.

- combined_summary_of_buyer_reps_warranties:
  - Concise description of the core Buyer/Purchaser representations and warranties, including Buyer's organization and
    authority, enforceability of the PSA, financial ability or sources of funds to close, and absence of conflicts or
    violations in connection with Buyer's execution and performance, using only buyer_warranties_reps_covenants evidence.

Additional constraints:
- Summaries should usually capture all major points for that deal point.
- Do not reuse the same sentence verbatim across the different combined_summary_* fields.
- Do not cross borrow evidence between deal points. Each summary must rely only on its own deal point evidence.
- If evidence is clearly missing or ambiguous for a given deal point, set its combined_summary_* field to null.
- Do not add commentary, explanations, or markdown. Return only the JSON object.
"""
