"""
Evidence JSON schemas for Stage 1 (all families), trimmed to production names.
"""

# Schema field descriptions (constants to avoid string duplication)
_REQUIRED_STRING_ARRAY = "string (at least 1 required)"
_OPTIONAL_STRING = "string or null"

EVIDENCE_SCHEMA_FAMILY_1 = {
    "document_name": "string",
    "deal_points": {
        "purchase_price_and_payment_method": {
            "purchase_price_text": _OPTIONAL_STRING,
            "payment_method_summary": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "earnest_money": {
            "earnest_money_amount_text": _OPTIONAL_STRING,
            "timing_and_disposition": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "closing_adjustments": {
            "cutover_datetime_text": _OPTIONAL_STRING,
            "items_prorated": ["string"],
            "price_adjustment_events": ["string"],
            "post_closing_readjustment": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "closing_costs": {
            "key_cost_allocations": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "brokerage_commissions": {
            "key_brokerage_terms": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
    },
}


EVIDENCE_SCHEMA_FAMILY_2 = {
    "document_name": "string",
    "deal_points": {
        "access_and_inspection": {
            "due_diligence_period_terms": _OPTIONAL_STRING,
            "buyer_rights_terms": _OPTIONAL_STRING,
            "buyer_obligations_terms": _OPTIONAL_STRING,
            "seller_duties_terms": _OPTIONAL_STRING,
            "seller_rights_terms": _OPTIONAL_STRING,
            "due_diligence_materials_terms": ["string"],
            "buyer_termination_approval_terms": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "title": {
            "title_commitment_terms": _OPTIONAL_STRING,
            "title_objection_procedure": _OPTIONAL_STRING,
            "permitted_exceptions_terms": _OPTIONAL_STRING,
            "seller_cure_terms": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "survey": {
            "survey_requirements": _OPTIONAL_STRING,
            "survey_specifications": _OPTIONAL_STRING,
            "survey_responsibility_terms": _OPTIONAL_STRING,
            "survey_defect_terms": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "environmental_assessments": {
            "buyer_access_rights": ["string"],
            "responsible_party_for_costs": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
    },
}


EVIDENCE_SCHEMA_FAMILY_3 = {
    "document_name": "string",
    "deal_points": {
        "closing_mechanics": {
            "closing_date_text": _OPTIONAL_STRING,
            "closing_place_text": _OPTIONAL_STRING,
            "closing_procedure_steps": ["string"],
            "adjournment_or_extension_terms": _OPTIONAL_STRING,
            "other_closing_mechanics": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "proceedings_at_closing": {
            "seller_deliverables": ["string"],
            "purchaser_deliverables": ["string"],
            "mutual_or_other_deliverables": ["string"],
            "title_company_deliverables": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "conditions_to_closing": {
            "buyer_conditions": ["string"],
            "seller_conditions": ["string"],
            "mutual_conditions": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "possession_at_closing": {
            "possession_timing_text": _OPTIONAL_STRING,
            "condition_of_possession": _OPTIONAL_STRING,
            "post_closing_occupancy_terms": _OPTIONAL_STRING,
            "keys_and_access_terms": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
    },
}


EVIDENCE_SCHEMA_FAMILY_4 = {
    "document_name": "string",
    "deal_points": {
        "affirmative_covenants": {
            "operating_in_ordinary_course_terms": ["string"],
            "no_new_burdens_or_title_changes_terms": ["string"],
            "leasing_and_rent_concession_terms": ["string"],
            "lease_proposals_and_tenant_information_delivery_terms": ["string"],
            "security_deposits_and_rent_application_terms": ["string"],
            "compliance_and_permits_terms": ["string"],
            "notice_and_material_change_terms": ["string"],
            "contacts_and_service_agreements_terms": ["string"],
            "other_affirmative_covenants_terms": ["string"],
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "seller_warranties_reps_covenants": {
            "summary_of_key_reps": ["string"],
            "litigation_or_violation_statements": ["string"],
            "seller_promises_facts": ["string"],
            "combined_summary_of_reps_warranties": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "buyer_warranties_reps_covenants": {
            "summary_of_key_buyer_reps": ["string"],
            "buyer_financial_ability_and_source_of_funds_terms": ["string"],
            "buyer_no_conflict_or_violation_statements": ["string"],
            "other_buyer_reps_and_covenants_terms": ["string"],
            "combined_summary_of_buyer_reps_warranties": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
    },
}


EVIDENCE_SCHEMA_FAMILY_5 = {
    "document_name": "string",
    "deal_points": {
        "risk_of_loss_and_insurance": {
            "risk_of_loss_allocation_terms": _OPTIONAL_STRING,
            "casualty_severity_thresholds_and_consequences": _OPTIONAL_STRING,
            "pre_closing_insurance_obligations": _OPTIONAL_STRING,
            "insurance_proceeds_and_assignments": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "condemnation": {
            "condemnation_triggers_and_notice": _OPTIONAL_STRING,
            "condemnation_minor_vs_major_thresholds": _OPTIONAL_STRING,
            "buyer_rights_in_condemnation": _OPTIONAL_STRING,
            "seller_rights_in_condemnation": _OPTIONAL_STRING,
            "allocation_of_condemnation_awards": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "remedies_default": {
            "buyer_default_and_seller_general_remedies": _OPTIONAL_STRING,
            "seller_default_and_buyer_general_remedies": _OPTIONAL_STRING,
            "remedies_for_breach_of_buyer_reps_and_warranties": _OPTIONAL_STRING,
            "remedies_for_breach_of_seller_reps_and_warranties": _OPTIONAL_STRING,
            "remedies_for_failure_of_closing_conditions": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
        "indemnity": {
            "core_seller_indemnity_obligations": _OPTIONAL_STRING,
            "core_buyer_indemnity_obligations": _OPTIONAL_STRING,
            "indemnity_survival_periods_and_notice": _OPTIONAL_STRING,
            "access_and_inspection_indemnity": _OPTIONAL_STRING,
            "environmental_indemnity": _OPTIONAL_STRING,
            "broker_related_indemnity": _OPTIONAL_STRING,
            "escrow_related_indemnity": _OPTIONAL_STRING,
            "source_section_paths": [_REQUIRED_STRING_ARRAY],
            "source_texts": [_REQUIRED_STRING_ARRAY],
        },
    },
}
