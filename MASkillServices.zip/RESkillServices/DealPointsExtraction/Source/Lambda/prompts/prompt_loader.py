"""
Prompt loader. Returns family-specific prompts and schemas.
Currently populated for family_1 evidence; other families return empty placeholders.
"""

from __future__ import annotations

from typing import Any, Dict

from Lambda.prompts.evidence_schemas import (
    EVIDENCE_SCHEMA_FAMILY_1,
    EVIDENCE_SCHEMA_FAMILY_2,
    EVIDENCE_SCHEMA_FAMILY_3,
    EVIDENCE_SCHEMA_FAMILY_4,
    EVIDENCE_SCHEMA_FAMILY_5,
)
from Lambda.prompts.summary_schemas import (
    SUMMARY_SCHEMA_FAMILY_1,
    SUMMARY_SCHEMA_FAMILY_2,
    SUMMARY_SCHEMA_FAMILY_3,
    SUMMARY_SCHEMA_FAMILY_4,
    SUMMARY_SCHEMA_FAMILY_5,
)
from Lambda.prompts.family_1.evidence_system import EVIDENCE_SYSTEM_MESSAGE_FAMILY_1
from Lambda.prompts.family_1.evidence_instructions import EVIDENCE_INSTRUCTIONS_FAMILY_1
from Lambda.prompts.family_1.summary_system import SUMMARY_SYSTEM_MESSAGE_FAMILY_1
from Lambda.prompts.family_1.summary_instructions import SUMMARY_INSTRUCTIONS_FAMILY_1
from Lambda.prompts.family_2.evidence_system import EVIDENCE_SYSTEM_MESSAGE_FAMILY_2
from Lambda.prompts.family_2.evidence_instructions import EVIDENCE_INSTRUCTIONS_FAMILY_2
from Lambda.prompts.family_2.summary_system import SUMMARY_SYSTEM_MESSAGE_FAMILY_2
from Lambda.prompts.family_2.summary_instructions import SUMMARY_INSTRUCTIONS_FAMILY_2
from Lambda.prompts.family_3.evidence_system import EVIDENCE_SYSTEM_MESSAGE_FAMILY_3
from Lambda.prompts.family_3.evidence_instructions import EVIDENCE_INSTRUCTIONS_FAMILY_3
from Lambda.prompts.family_3.summary_system import SUMMARY_SYSTEM_MESSAGE_FAMILY_3
from Lambda.prompts.family_3.summary_instructions import SUMMARY_INSTRUCTIONS_FAMILY_3
from Lambda.prompts.family_4.evidence_system import EVIDENCE_SYSTEM_MESSAGE_FAMILY_4
from Lambda.prompts.family_4.evidence_instructions import EVIDENCE_INSTRUCTIONS_FAMILY_4
from Lambda.prompts.family_4.summary_system import SUMMARY_SYSTEM_MESSAGE_FAMILY_4
from Lambda.prompts.family_4.summary_instructions import SUMMARY_INSTRUCTIONS_FAMILY_4
from Lambda.prompts.family_5.evidence_system import EVIDENCE_SYSTEM_MESSAGE_FAMILY_5
from Lambda.prompts.family_5.evidence_instructions import EVIDENCE_INSTRUCTIONS_FAMILY_5
from Lambda.prompts.family_5.summary_system import SUMMARY_SYSTEM_MESSAGE_FAMILY_5
from Lambda.prompts.family_5.summary_instructions import SUMMARY_INSTRUCTIONS_FAMILY_5


# Centralized mappings for O(1) lookup
_SYSTEM_MESSAGES = {
    "family_1": EVIDENCE_SYSTEM_MESSAGE_FAMILY_1,
    "family_2": EVIDENCE_SYSTEM_MESSAGE_FAMILY_2,
    "family_3": EVIDENCE_SYSTEM_MESSAGE_FAMILY_3,
    "family_4": EVIDENCE_SYSTEM_MESSAGE_FAMILY_4,
    "family_5": EVIDENCE_SYSTEM_MESSAGE_FAMILY_5,
}

_INSTRUCTIONS = {
    "family_1": EVIDENCE_INSTRUCTIONS_FAMILY_1,
    "family_2": EVIDENCE_INSTRUCTIONS_FAMILY_2,
    "family_3": EVIDENCE_INSTRUCTIONS_FAMILY_3,
    "family_4": EVIDENCE_INSTRUCTIONS_FAMILY_4,
    "family_5": EVIDENCE_INSTRUCTIONS_FAMILY_5,
}

_SCHEMAS = {
    "family_1": EVIDENCE_SCHEMA_FAMILY_1,
    "family_2": EVIDENCE_SCHEMA_FAMILY_2,
    "family_3": EVIDENCE_SCHEMA_FAMILY_3,
    "family_4": EVIDENCE_SCHEMA_FAMILY_4,
    "family_5": EVIDENCE_SCHEMA_FAMILY_5,
}

# Summary prompts and schemas (Stage 2)
_SUMMARY_SYSTEM_MESSAGES = {
    "family_1": SUMMARY_SYSTEM_MESSAGE_FAMILY_1,
    "family_2": SUMMARY_SYSTEM_MESSAGE_FAMILY_2,
    "family_3": SUMMARY_SYSTEM_MESSAGE_FAMILY_3,
    "family_4": SUMMARY_SYSTEM_MESSAGE_FAMILY_4,
    "family_5": SUMMARY_SYSTEM_MESSAGE_FAMILY_5,
}

_SUMMARY_INSTRUCTIONS = {
    "family_1": SUMMARY_INSTRUCTIONS_FAMILY_1,
    "family_2": SUMMARY_INSTRUCTIONS_FAMILY_2,
    "family_3": SUMMARY_INSTRUCTIONS_FAMILY_3,
    "family_4": SUMMARY_INSTRUCTIONS_FAMILY_4,
    "family_5": SUMMARY_INSTRUCTIONS_FAMILY_5,
}

_SUMMARY_SCHEMAS = {
    "family_1": SUMMARY_SCHEMA_FAMILY_1,
    "family_2": SUMMARY_SCHEMA_FAMILY_2,
    "family_3": SUMMARY_SCHEMA_FAMILY_3,
    "family_4": SUMMARY_SCHEMA_FAMILY_4,
    "family_5": SUMMARY_SCHEMA_FAMILY_5,
}


class PromptLoader:
    @staticmethod
    def get_evidence_system(family_name: str) -> str:
        """Get system message for evidence extraction."""
        return _SYSTEM_MESSAGES.get(family_name, "")

    @staticmethod
    def get_evidence_instructions(family_name: str) -> str:
        """Get instructions for evidence extraction."""
        return _INSTRUCTIONS.get(family_name, "")

    @staticmethod
    def get_evidence_schema(family_name: str) -> Dict[str, Any]:
        """Get JSON schema for evidence extraction."""
        return _SCHEMAS.get(family_name, {})

    @staticmethod
    def get_summary_system(family_name: str) -> str:
        """Get system message for Stage 2 summarization."""
        return _SUMMARY_SYSTEM_MESSAGES.get(family_name, "")

    @staticmethod
    def get_summary_instructions(family_name: str) -> str:
        """Get instructions for Stage 2 summarization."""
        return _SUMMARY_INSTRUCTIONS.get(family_name, "")

    @staticmethod
    def get_summary_schema(family_name: str) -> Dict[str, Any]:
        """Get JSON schema for Stage 2 summarization."""
        return _SUMMARY_SCHEMAS.get(family_name, {})
