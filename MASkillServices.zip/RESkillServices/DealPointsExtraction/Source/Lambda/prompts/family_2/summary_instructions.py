SUMMARY_INSTRUCTIONS_FAMILY_2 = """
Return only a JSON object with this structure:

{
  "document_name": string,
  "deal_points": {
    "access_and_inspection": {
      "due_diligence_period_terms": string or null,
      "buyer_rights_terms": string or null,
      "buyer_obligations_terms": string or null,
      "seller_duties_terms": string or null,
      "seller_rights_terms": string or null,
      "due_diligence_materials_terms": [string],
      "buyer_termination_approval_terms": string or null,
      "combined_summary_access_and_inspection": string or null
    },
    "title": {
      "title_commitment_terms": string or null,
      "title_objection_procedure": string or null,
      "permitted_exceptions_terms": string or null,
      "seller_cure_terms": string or null,
      "combined_summary_title": string or null
    },
    "survey": {
      "survey_requirements": string or null,
      "survey_specifications": string or null,
      "survey_responsibility_terms": string or null,
      "survey_defect_terms": string or null,
      "combined_summary_survey": string or null
    },
    "environmental_assessments": {
      "buyer_access_rights": [string],
      "responsible_party_for_costs": [string],
      "combined_summary_environmental_assessments": string or null
    }
  }
}

Rules for summaries:
- combined_summary_access_and_inspection:
  - Concise description of the due diligence period, buyer rights and obligations during due diligence, seller duties and seller rights, required or expected due diligence materials, and any buyer termination or approval conditions, using only access_and_inspection evidence.
- combined_summary_title:
  - Concise description of title commitment delivery and key terms, buyer objection mechanics, seller cure obligations, and key permitted exceptions, using only title evidence.
- combined_summary_survey:
  - Concise description of whether a new or existing survey is required, key survey specifications, who provides or pays for the survey, and how survey related defects are handled, using only survey evidence.
- combined_summary_environmental_assessments:
  - Concise description of buyer access rights for environmental inspections or testing, and who bears costs or financial responsibility for environmental assessments, remediation, or related damages, using only environmental_assessments evidence.

Additional constraints:
- Summaries should usually capture all major points for that deal point.
- Do not reuse the same sentence verbatim across different combined_summary_* fields.
- Do not cross borrow evidence between deal points. Each summary must rely only on its own deal point evidence.
- If evidence is clearly missing or ambiguous for a given deal point, set its combined_summary_* field to null.
- Do not add commentary, explanations, or markdown. Return only the JSON object.
"""
