EVIDENCE_INSTRUCTIONS_FAMILY_3 = """
Return only a valid JSON object with this structure:

{
  "document_name": "string",
  "deal_points": {
    "closing_mechanics": {
      "closing_date_text": "string or null",
      "closing_place_text": "string or null",
      "closing_procedure_steps": ["string"],
      "adjournment_or_extension_terms": "string or null",
      "other_closing_mechanics": ["string"],
      "seq_ids": [0, 1, 2]
    },
    "proceedings_at_closing": {
      "seller_deliverables": ["string"],
      "purchaser_deliverables": ["string"],
      "mutual_or_other_deliverables": ["string"],
      "title_company_deliverables": ["string"],
      "seq_ids": [0, 1, 2]
    },
    "conditions_to_closing": {
      "buyer_conditions": ["string"],
      "seller_conditions": ["string"],
      "mutual_conditions": ["string"],
      "seq_ids": [0, 1, 2]
    },
    "possession_at_closing": {
      "possession_timing_text": "string or null",
      "condition_of_possession": "string or null",
      "post_closing_occupancy_terms": "string or null",
      "keys_and_access_terms": ["string"],
      "seq_ids": [0, 1, 2]
    }
  }
}

Rules:
- Populate only evidence fields and their seq_ids.
- Do not invent any combined_summary_* fields. If any such fields are present in the schema, set them to null.
- **IMPORTANT**: For each deal point, include the seq_ids array with the sequence IDs where you found the evidence.
- seq_ids should contain integers representing the SEQ_ID values from the input chunks where the deal point information appears.
- For list fields, return a list of short, precise micro summaries that closely track the actual contract language.
- If no evidence exists for a deal point in the document, you may set seq_ids to [] (empty array), but include the deal point in your response.
- Do not reuse a sentence across multiple deal points unless it clearly and expressly supports both.
- Do not include commentary, labels, or markdown. Return only the JSON object.
"""
