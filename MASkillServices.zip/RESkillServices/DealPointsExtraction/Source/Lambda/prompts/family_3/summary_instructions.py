SUMMARY_INSTRUCTIONS_FAMILY_3 = """
Return only a JSON object with this structure:

{
  "document_name": string,
  "deal_points": {
    "closing_mechanics": {
      "closing_date_text": string or null,
      "closing_place_text": string or null,
      "closing_mechanics_text": string or null,
      "funding_and_disbursement_mechanics": string or null,
      "cross_references_to_deliverables": string or null,
      "combined_summary_closing_mechanics": string or null
    },
    "proceedings_at_closing": {
      "seller_closing_deliverables": [string],
      "purchaser_closing_deliverables": [string],
      "third_party_or_escrow_deliverables": [string],
      "closing_procedure_notes": string or null,
      "title_company_deliverables": [string],
      "combined_summary_proceedings_at_closing": string or null
    },
    "conditions_to_closing": {
      "buyer_requirements": [string],
      "seller_requirements": [string],
      "mutual_or_general_conditions": [string],
      "combined_summary_conditions_to_closing": string or null
    },
    "possession_at_closing": {
      "possession_timing_text": string or null,
      "condition_of_property_at_possession": string or null,
      "post_closing_occupancy_or_lease_terms": string or null,
      "holdover_or_early_access_terms": string or null,
      "combined_summary_possession_at_closing": string or null
    }
  }
}

Rules for summaries:

- combined_summary_closing_mechanics:
  - Provide a detailed narrative description of when the closing occurs, where it occurs, and how the closing is carried out.
  - Capture core mechanics such as required pre closing steps, method of payment and funding flow, disbursement of funds, escrow or title company roles, and any cross references to closing deliverables or other sections.
  - Use only the closing evidence.

- combined_summary_proceedings_at_closing:
  - Provide a detailed description of what must be delivered, executed, or exchanged at closing.
  - Clearly describe Seller deliverables, Purchaser deliverables, and any third party or escrow deliverables, including key documents, certificates, opinions, estoppels, assignments, bills of sale, recorded documents, and closing statements.
  - Include any important notes about sequencing, conditions for delivery, and who is responsible for providing each item, using only proceedings_at_closing evidence.

- combined_summary_conditions_to_closing:
  - Provide a detailed description of conditions precedent to Buyer's obligation to close, conditions precedent to Seller's obligation to close, and any mutual or general conditions that apply to both.
  - Cover regulatory or third party approvals, representations and warranties bring down requirements, covenant compliance, title and survey conditions, delivery of closing documents, absence of litigation or material adverse change, and any other explicit closing conditions.
  - Summarize Buyer side and Seller side conditions in a structured way, using only conditions_to_closing evidence.

- combined_summary_possession_at_closing:
  - Provide a detailed description of when and how possession of the property is delivered.
  - Capture whether possession is delivered at closing, at a specified time after closing, or subject to existing tenants, and any conditions tied to delivery of possession.
  - Include any early access rights, post closing occupancy by Seller, license or lease back terms, holdover rules, and risk allocation around possession timing, using only possession_at_closing evidence.

Additional constraints:
- Each combined_summary_* should usually capture all major material points for that deal point and can be multi sentence.
- Do not reuse the same sentence verbatim across different combined_summary_* fields.
- Do not cross borrow evidence between deal points. Each summary must rely only on its own deal point's evidence.
- If evidence is clearly missing or ambiguous for a given deal point, set its combined_summary_* field to null.
- Do not add commentary, explanations, or markdown. Return only the JSON object.
"""
