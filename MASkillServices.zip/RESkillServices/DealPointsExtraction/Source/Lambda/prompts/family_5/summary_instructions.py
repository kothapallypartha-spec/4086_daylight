SUMMARY_INSTRUCTIONS_FAMILY_5 = """
Return only a JSON object with this structure:

{
  "document_name": string,
  "deal_points": {
    "risk_of_loss_and_insurance": {
      "risk_of_loss_allocation_terms": string or null,
      "casualty_severity_thresholds_and_consequences": string or null,
      "pre_closing_insurance_obligations": string or null,
      "insurance_proceeds_and_assignments": string or null,
      "combined_summary_risk_of_loss_and_insurance": string or null
    },
    "condemnation": {
      "condemnation_triggers_and_notice": string or null,
      "condemnation_minor_vs_major_thresholds": string or null,
      "buyer_rights_in_condemnation": string or null,
      "seller_rights_in_condemnation": string or null,
      "allocation_of_condemnation_awards": string or null,
      "combined_summary_condemnation": string or null
    },
    "remedies_default": {
      "buyer_default_and_seller_general_remedies": string or null,
      "seller_default_and_buyer_general_remedies": string or null,
      "remedies_for_breach_of_buyer_reps_and_warranties": string or null,
      "remedies_for_breach_of_seller_reps_and_warranties": string or null,
      "remedies_for_failure_of_closing_conditions": string or null,
      "combined_summary_remedies_default": string or null
    },
    "indemnity": {
      "core_seller_indemnity_obligations": string or null,
      "core_buyer_indemnity_obligations": string or null,
      "indemnity_survival_periods_and_notice": string or null,
      "access_and_inspection_indemnity": string or null,
      "environmental_indemnity": string or null,
      "broker_related_indemnity": string or null,
      "combined_summary_indemnity": string or null
    }
  }
}

Rules for summaries:
- combined_summary_risk_of_loss_and_insurance:
  - Concise description of pre-closing risk of loss allocation, how casualty or damage is handled (including any materiality thresholds), required insurance maintenance, and who receives or controls insurance proceeds or assignments, using only risk_of_loss_and_insurance evidence.
- combined_summary_condemnation:
  - Concise description of what happens if condemnation or a governmental taking is threatened or occurs before closing, including any minor versus major thresholds, which party may terminate or proceed, and how condemnation awards are allocated, using only condemnation evidence.
- combined_summary_remedies_default:
  - Concise description of what constitutes Buyer and Seller defaults under the PSA and the related remedies, including treatment of deposits or earnest money, specific performance, damages, and any remedies linked to breaches of representations, warranties, or closing conditions, using only remedies_default evidence.
- combined_summary_indemnity:
  - Concise description of the main indemnity structure, including Seller indemnity in favor of Buyer, Buyer indemnity in favor of Seller, key survival and notice mechanics, and any special indemnities tied to access and inspection, environmental matters, or brokers, using only indemnity evidence.

Additional constraints:
- Summaries should usually capture all major points for that deal point.
- Do not reuse the same sentence verbatim across different combined_summary_* fields.
- Do not cross borrow evidence between deal points. Each summary must rely only on its own deal point evidence.
- If evidence is clearly missing or ambiguous for a given deal point, set its combined_summary_* field to null.
- Do not add commentary, explanations, or markdown. Return only the JSON object.
"""
