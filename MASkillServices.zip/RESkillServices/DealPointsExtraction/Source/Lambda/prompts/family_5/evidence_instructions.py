EVIDENCE_INSTRUCTIONS_FAMILY_5 = """
Return only a valid JSON object with this structure:

{
  "document_name": "string",
  "deal_points": {
    "risk_of_loss_and_insurance": {
      "risk_of_loss_allocation_terms": "string or null",
      "casualty_severity_thresholds_and_consequences": "string or null",
      "pre_closing_insurance_obligations": "string or null",
      "insurance_proceeds_and_assignments": "string or null",
      "seq_ids": [0, 1, 2]
    },
    "condemnation": {
      "condemnation_triggers_and_notice": "string or null",
      "condemnation_minor_vs_major_thresholds": "string or null",
      "buyer_rights_in_condemnation": "string or null",
      "seller_rights_in_condemnation": "string or null",
      "allocation_of_condemnation_awards": "string or null",
      "seq_ids": [0, 1, 2]
    },
    "remedies_default": {
      "buyer_default_and_seller_general_remedies": "string or null",
      "seller_default_and_buyer_general_remedies": "string or null",
      "remedies_for_breach_of_buyer_reps_and_warranties": "string or null",
      "remedies_for_breach_of_seller_reps_and_warranties": "string or null",
      "remedies_for_failure_of_closing_conditions": "string or null",
      "seq_ids": [0, 1, 2]
    },
    "indemnity": {
      "core_seller_indemnity_obligations": "string or null",
      "core_buyer_indemnity_obligations": "string or null",
      "indemnity_survival_periods_and_notice": "string or null",
      "access_and_inspection_indemnity": "string or null",
      "environmental_indemnity": "string or null",
      "broker_related_indemnity": "string or null",
      "escrow_related_indemnity": "string or null",
      "seq_ids": [0, 1, 2]
    }
  }
}

Rules:
- The shape of your JSON must match this evidence schema exactly.
- Populate only evidence fields and their seq_ids.
- Do not write any combined_summary_* fields in this stage. If such keys exist, set them explicitly to null.
- **IMPORTANT**: For each deal point, include the seq_ids array with the sequence IDs where you found the evidence.
- seq_ids should contain integers representing the SEQ_ID values from the input chunks where the deal point information appears.
- For all string fields, use short, precise micro summaries that closely track the contract language.
- For list fields, each element must be a concise micro summary or clause fragment that closely tracks the contract language.
- If no evidence exists for a deal point in the document, you may set seq_ids to [] (empty array), but include the deal point in your response.
- Do not include commentary, labels, or markdown. Return only the JSON object.
"""
