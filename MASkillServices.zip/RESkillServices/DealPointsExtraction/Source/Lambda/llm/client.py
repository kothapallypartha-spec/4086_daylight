from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Tuple

from llm_proxy import create_simple_proxy
from llm_proxy.prompt import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)
from Lambda.config.constants import (
    DEFAULT_MAX_TOKENS,
    DEFAULT_LLM_RETRY,
    DEFAULT_LLM_TIMEOUT,
    DEFAULT_TEMPERATURE,
    NANO_MINI_TEMPERATURE,
    CHARS_PER_TOKEN_ESTIMATE,
    MESSAGE_OVERHEAD_TOKENS,
    CONVERSATION_OVERHEAD_TOKENS,
    ENV_LLM_PROXY_TENANT,
    ENV_LLM_PROXY_RETRY,
    ENV_LLM_PROXY_TIMEOUT,
    ENV_ASSET_ID,
    MODEL_NAME_GPT_5,
    MODEL_NAME_GPT_4,
    MODEL_NAME_GPT_3,
    MODEL_NAME_NANO,
    MODEL_NAME_MINI,
    MODEL_PROVIDER_ANTHROPIC,
    MODEL_PROVIDER_CLAUDE,
)
from Lambda.preprocessing.json_validator import JSONValidator
from common.aws.secrets import SecretsManager
from common.aws.logger import get_logger

logger = get_logger(__name__)

try:
    import tiktoken
    TIKTOKEN_AVAILABLE = True
except ImportError:
    TIKTOKEN_AVAILABLE = False


class LLMClient:
    """
    LLM client matching notebook pattern: uses llm_proxy with manual JSON parsing.
    
    Supports multiple model providers:
    - OpenAI: gpt-5, gpt-5.1, gpt-5-nano, gpt-5-mini, gpt-4o, gpt-4
    - Anthropic Claude: opus-4, opus-4-5, sonnet-4, sonnet-4-5
    - Automatically configures parameters based on model name
    
    Model Examples:
    - OpenAI_gpt-5.1-2025-11-13_LexisAI_US_3363
    - OpenAI_gpt-5-nano-2025-08-07_LexisAI_US_3363_nonprod
    - anthropic-claude-opus-4-5-20251101_LexisPlusAIUS_3363_nonprod
    - anthropic-claude-sonnet-4-5-20250929_LexisPlusAIUS_3363_nonprod
    
    Key differences from OpenAI SDK:
    - llm_proxy returns raw string responses (not structured objects)
    - Manual JSON parsing required
    - Manual Pydantic validation required
    - Token usage tracking not available from llm_proxy responses
    
    Methods:
    - `chat_with_usage`: Returns (parsed_data, usage_dict) tuple
    - `chat`: Returns only the parsed data (no usage)
    """

    def __init__(self, model_name: str):
        self.model_name = model_name
        # llm_proxy client will be created per-call with specific prompts
        self._retry = int(os.environ.get(ENV_LLM_PROXY_RETRY, str(DEFAULT_LLM_RETRY)))
        self._timeout = int(os.environ.get(ENV_LLM_PROXY_TIMEOUT, str(DEFAULT_LLM_TIMEOUT)))
        self._max_tokens = DEFAULT_MAX_TOKENS
        self._encoding = self._get_encoding()
        
        # Fetch tenant from environment variable or AWS Secrets Manager
        self._tenant = os.environ.get(ENV_LLM_PROXY_TENANT)
        if not self._tenant:
            # Fallback to Secrets Manager (production pattern)
            # When deploying via Jenkins pipeline, SECRET_NAME is set from template
            # but when running locally, we need the default
            secret_name = os.environ.get(
                "SECRET_NAME",
                "/AssetID_6253/ddc4c/daylight-re-skills-secrets"
            )
            aws_profile = os.environ.get("AWS_PROFILE")
            logger.info(f"LLM_PROXY_TENANT not in environment, fetching from Secrets Manager: {secret_name}")
            try:
                secrets_mgr = SecretsManager(
                    secret_name=secret_name,
                    region_name=os.environ.get("AWS_DEFAULT_REGION", "us-east-1"),
                    profile=aws_profile
                )
                self._tenant = secrets_mgr.get_secret('LLM_PROXY_TENANT')
                logger.info("Successfully retrieved LLM_PROXY_TENANT from Secrets Manager")
            except Exception as e:
                logger.error(f"Failed to retrieve tenant from Secrets Manager: {e}")
                raise RuntimeError(f"LLM_PROXY_TENANT not found in environment or Secrets Manager: {e}")
    
    def _get_encoding(self):
        """Get tiktoken encoding for the model."""
        if not TIKTOKEN_AVAILABLE:
            return None
        
        try:
            # For OpenAI models, use the appropriate encoding
            model_lower = self.model_name.lower()
            if MODEL_NAME_GPT_5 in model_lower or MODEL_NAME_GPT_4 in model_lower:
                return tiktoken.get_encoding("cl100k_base")
            elif MODEL_NAME_GPT_3 in model_lower:
                return tiktoken.get_encoding("cl100k_base")
            else:
                # For non-OpenAI models (Claude, etc.), use cl100k_base as approximation
                return tiktoken.get_encoding("cl100k_base")
        except Exception:
            return None
    
    def _count_tokens(self, text: str) -> int:
        """Count tokens in text using tiktoken."""
        if not self._encoding:
            # Fallback: estimate characters per token
            return len(text) // CHARS_PER_TOKEN_ESTIMATE
        
        try:
            return len(self._encoding.encode(text))
        except Exception:
            # Fallback on error
            return len(text) // CHARS_PER_TOKEN_ESTIMATE
    
    def _count_message_tokens(self, messages: List[dict]) -> int:
        """Count tokens in a list of messages."""
        total = 0
        for msg in messages:
            # Add tokens for role and content
            total += MESSAGE_OVERHEAD_TOKENS
            total += self._count_tokens(msg.get("content", ""))
        total += CONVERSATION_OVERHEAD_TOKENS
        return total

    def _sanitize_json_string(self, json_str: str) -> str:
        """
        Sanitize JSON string to handle invalid control characters.
        
        LLMs sometimes return JSON with unescaped control characters (newlines, tabs, etc.)
        inside string values, which causes json.loads() to fail. This function attempts
        to fix common issues while preserving valid escape sequences.
        """
        import re
        
        # Remove BOM if present
        json_str = json_str.replace('\ufeff', '')
        
        # Strategy: Find string literals and escape control characters within them
        # This regex finds JSON string values (accounting for escaped quotes)
        def fix_string_value(match):
            """Fix control characters within a JSON string value."""
            string_content = match.group(1)
            # Replace literal control characters with their escaped versions
            # Only fix if not already escaped
            string_content = re.sub(r'(?<!\\)\r\n', r'\\n', string_content)  # Windows newlines
            string_content = re.sub(r'(?<!\\)\n', r'\\n', string_content)     # Unix newlines
            string_content = re.sub(r'(?<!\\)\r', r'\\r', string_content)     # Mac newlines
            string_content = re.sub(r'(?<!\\)\t', r'\\t', string_content)     # Tabs
            return f'"{string_content}"'
        
        # Find and fix all string values in JSON
        # Match strings that aren't already properly escaped
        json_str = re.sub(r'"((?:[^"\\]|\\.)*)\"', fix_string_value, json_str)
        
        return json_str

    def _parse_json_response(self, raw_response: str) -> Dict[str, Any]:
        """
        Parse JSON from LLM response using robust validator.
        
        Handles:
        - Code block markers (```json, ```)
        - Unescaped control characters (newlines, tabs)
        - Incomplete JSON (missing closing braces)
        - Trailing commas
        - Mixed quote styles
        """
        try:
            # Use the new JSON validator with automatic repair
            parsed = JSONValidator.validate_and_repair(raw_response)
            logger.info("JSON parsing successful with JSONValidator")
            return parsed
        except ValueError as e:
            # If JSONValidator fails, raise with context
            raise ValueError(f"Failed to parse JSON from LLM response: {str(e)}") from e

    def _build_prompt_template(self, messages: List[dict]) -> tuple[ChatPromptTemplate, str | None]:
        """
        Convert message list to llm_proxy ChatPromptTemplate.
        
        Returns:
            (ChatPromptTemplate, system_message): For Claude, system message is separate
        """
        prompt_blocks = []
        system_content = None
        model_lower = self.model_name.lower()
        is_claude = MODEL_PROVIDER_ANTHROPIC in model_lower or MODEL_PROVIDER_CLAUDE in model_lower
        
        for msg in messages:
            role = msg["role"].lower()
            content = msg["content"]
            # Escape braces for literal text (no template variables)
            content = content.replace("{", "{{").replace("}", "}}")
            
            if role == "system":
                if is_claude:
                    # Claude: system message goes as separate parameter
                    system_content = content
                else:
                    # OpenAI: system message goes in messages array
                    prompt_blocks.append(SystemMessagePromptTemplate.from_template(content))
            elif role == "user":
                prompt_blocks.append(HumanMessagePromptTemplate.from_template(content))
        
        return ChatPromptTemplate.from_messages(prompt_blocks), system_content

    def _create_tracing_info(self) -> Dict[str, Any]:
        """Build tracing metadata for llm_proxy calls."""
        return {
            "asset_id": os.environ.get(ENV_ASSET_ID, "6253"),
            "trans_id": "deal_points_extraction",
            "user_id": "service_user",
            "user_type": "service",
            "ext_info": {"model": self.model_name},
        }

    def chat(
        self,
        *,
        messages: List[dict],
        response_model: Optional[Any] = None,
    ):
        """
        Execute chat and return parsed response.
        
        Args:
            messages: List of {role, content} dicts
            response_model: Optional Pydantic model for validation
        
        Returns:
            - If response_model: validated Pydantic object
            - If no response_model: raw string
        """
        result, _ = self.chat_with_usage(messages=messages, response_model=response_model)
        return result

    def chat_with_usage(
        self,
        *,
        messages: List[dict],
        response_model: Optional[Any] = None,
    ) -> Tuple[Any, dict]:
        """
        Execute chat completion following notebook pattern.
        
        Flow:
        1. Build prompt template from messages
        2. Create llm_proxy client
        3. Call .chat() -> returns raw string
        4. Parse JSON from string
        5. Validate with Pydantic model
        
        Args:
            messages: List of chat messages (system, user)
            response_model: Optional Pydantic model for structured output
        
        Returns:
            Tuple of (parsed_response, usage_dict)
            - If response_model: returns validated Pydantic object
            - If no response_model: returns raw text
            - usage_dict has estimated tokens (llm_proxy doesn't return usage)
        """
        # Estimate input tokens from messages
        prompt_tokens = self._count_message_tokens(messages)
        
        try:
            # Step 1: Build prompt template
            chat_prompt, system_message = self._build_prompt_template(messages)
            
            # Step 2: Create llm_proxy client
            # Configure parameters based on model type (OpenAI vs Claude vs others)
            proxy_kwargs = {
                "tenant": self._tenant,
                "retry": self._retry,
                "timeout": self._timeout,
            }
            
            # Model-specific parameter configuration
            model_lower = self.model_name.lower()
            
            # Set default temperature (overridden for nano/mini models)
            proxy_kwargs["temperature"] = DEFAULT_TEMPERATURE
            
            # Anthropic Claude models (anthropic-claude-opus, anthropic-claude-sonnet)
            if MODEL_PROVIDER_ANTHROPIC in model_lower or MODEL_PROVIDER_CLAUDE in model_lower:
                proxy_kwargs["max_tokens"] = self._max_tokens
                # Claude requires system message as separate parameter
                if system_message:
                    proxy_kwargs["system"] = system_message
            # OpenAI gpt-5-nano and gpt-5-mini: requires max_completion_tokens and temperature=1 only
            elif MODEL_NAME_NANO in model_lower or MODEL_NAME_MINI in model_lower:
                proxy_kwargs["max_completion_tokens"] = self._max_tokens
                proxy_kwargs["temperature"] = NANO_MINI_TEMPERATURE
            # OpenAI gpt-5, gpt-5.1, and gpt-4o: require max_completion_tokens
            elif MODEL_NAME_GPT_5 in model_lower or "gpt-5.1" in model_lower or "gpt-4o" in model_lower:
                proxy_kwargs["max_completion_tokens"] = self._max_tokens
            # All other OpenAI models (gpt-4, etc.): use max_tokens parameter
            else:
                proxy_kwargs["max_tokens"] = self._max_tokens
            
            llm_client = create_simple_proxy(
                chat_prompt,
                self.model_name,
                **proxy_kwargs
            )
            
            # Step 3: Execute call - returns raw string
            tracing_info = self._create_tracing_info()
            raw_response = llm_client.chat(tracing_info=tracing_info)
            
            # Estimate completion tokens from response
            completion_tokens = self._count_tokens(raw_response)
            total_tokens = prompt_tokens + completion_tokens
            
            usage = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens
            }
            
            # Path 1: No structured output - return raw text
            if response_model is None:
                return raw_response, usage
            
            # Path 2: Structured output - manual JSON parsing and validation
            # Step 4: Parse JSON from raw string
            parsed_json = self._parse_json_response(raw_response)
            
            # Step 5: Validate with Pydantic model
            validated_model = response_model.model_validate(parsed_json)
            
            return validated_model, usage
            
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse JSON from LLM response: {e}\nRaw response: {raw_response[:500]}")
        except Exception as e:
            raise RuntimeError(f"LLM call failed: {e}") from e
