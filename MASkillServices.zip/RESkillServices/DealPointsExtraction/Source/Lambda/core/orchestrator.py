"""
Orchestrates multi-family processing for a single document.

All 5 families enabled with real LLM extraction and summarization.

Flow:
1) Receives XHTML chunks.
2) Spins up a FamilyProcessor per enabled family (parallel execution).
3) Each family executes Stage 1 (evidence) → Stage 2 (summary) pipeline.
4) Aggregates results into final response with token tracking.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List

from Lambda.core.family_processor import FamilyProcessor
from Lambda.core.response_aggregator import ResponseAggregator
from Lambda.core.token_tracker import TokenTracker
from Lambda.config.families import enabled_families
from Lambda.config.constants import DEFAULT_MODEL_NAME
from common.aws.logger import get_logger

logger = get_logger(__name__)


class Orchestrator:
    def __init__(self, family_names: List[str] | None = None, model_name: str | None = None):
        registry = enabled_families()
        if family_names:
            self.family_entries = {k: v for k, v in registry.items() if k in family_names}
        else:
            self.family_entries = registry
        # Set default model if not provided
        self.model_name = model_name or DEFAULT_MODEL_NAME
        self.aggregator = ResponseAggregator()
        self.token_tracker = TokenTracker()

    async def process_document(
        self,
        *,
        xhtml_chunks: List[Dict[str, Any]],
        upload_identifier: str,
        document_name: str,
    ) -> Dict[str, Any]:
        # Create a FamilyProcessor for each enabled family
        # Each processor handles evidence extraction + summarization for one family
        processors = []
        for fam, entry in self.family_entries.items():
            processors.append(
                FamilyProcessor(
                    family_name=fam,  # family_1, family_2, etc.
                    model_name=entry.get("model_name") or self.model_name,
                    token_tracker=self.token_tracker,
                    registry_entry=entry,
                )
            )
        
        logger.info(f"Processing {len(processors)} families in parallel...")
        for fp in processors:
            logger.info(f"[START] {fp.family_name}...")

        async def _run(fp: FamilyProcessor):
            # Each family processor runs independently and calls LLM
            # This is where the actual evidence extraction happens
            # All 5 families call LLM simultaneously via ThreadPoolExecutor
            result = await fp.process(xhtml_chunks=xhtml_chunks, upload_identifier=upload_identifier, document_name=document_name)
            logger.info(f"[DONE] Completed {fp.family_name}")
            return result

        # Run all families concurrently using asyncio.gather
        # With async _llm_extract using thread pool, all 5 LLM calls happen in parallel
        results = await asyncio.gather(*[_run(fp) for fp in processors], return_exceptions=True)

        family_results: List[Dict[str, Any]] = []
        for fam, res in zip(self.family_entries.keys(), results):
            if isinstance(res, Exception):
                family_results.append({"family": fam, "status": "failed", "error": str(res)})
            else:
                family_results.append(res)

        aggregated = self.aggregator.aggregate(
            family_results=family_results,
            xhtml_chunks=xhtml_chunks,
        )
        aggregated["tokens"] = self.token_tracker.get_summary()
        return aggregated
