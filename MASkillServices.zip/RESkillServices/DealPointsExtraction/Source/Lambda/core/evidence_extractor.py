"""
Stage 1 evidence extraction (modular).

Responsibilities:
- Load chunk JSONs (flattened XHTML rows) from a directory.
- For each document, call the LLM-backed extractor.
- Validate to the EvidenceDocument schema (family-specific).
- Persist per-document evidence JSON and a QA CSV.

Runtime entrypoint used by the service:
- `extract_document(...)` is invoked by FamilyProcessor for each family.
- It builds prompts, calls llm_proxy via LLMClient,
  and validates to the correct family-specific Pydantic model.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Callable, Dict, List

from Lambda.config.families import FAMILY_REGISTRY
from Lambda.prompts.prompt_loader import PromptLoader
from Lambda.prompts.prompt_builder import PromptBuilder
from Lambda.llm.client import LLMClient

def chunks_to_rows(chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Normalize XHTMLProcessor chunks to the rows shape expected by the extractor.
    
    Converts XHTML chunks (with xpath/text/offsets) into a simplified format
    where each row represents one text segment with its location in the document.
    Filters out empty text segments.
    """
    rows: List[Dict[str, Any]] = []
    for ch in chunks:
        # Extract and clean the text content
        text = (ch.get("text") or "").strip()
        if not text:
            continue  # Skip empty chunks
        
        # Create row with XPath (location) and text content
        rows.append(
            {
                "path": ch.get("xpath", ""),  # XPath location in document
                "text": text,  # Actual text content
                "seq_id": ch.get("seq_id"),  # Sequence number
                "start_offset": ch.get("start_offset"),  # Character offset start
                "end_offset": ch.get("end_offset"),  # Character offset end
            }
        )
    return rows


async def extract_document(
    *,
    document_name: str,
    rows: List[Dict[str, Any]],
    family_name: str = "family_1",
    model_name: str,
) -> tuple[Dict[str, Any], Dict[str, int]]:
    """
    In-memory evidence extraction for a single document (ASYNC).
    
    This is the main entry point for Stage 1 evidence extraction.
    Uses real LLM extraction via llm_proxy.
    
    Returns: (validated evidence dict with seq_ids, token usage dict)
    """
    # Call LLM extractor which handles validation and returns structured data
    # _llm_extract builds prompts, calls LLM with Pydantic response_model,
    # LLM now returns seq_ids directly instead of source_texts/source_section_paths
    evidence_dict, usage = await _llm_extract(
        document_name=document_name, 
        rows=rows, 
        family_name=family_name, 
        model_name=model_name
    )
    
    # Note: evidence_dict is already validated by LLM client's response_model
    # No need for double validation - trust the Pydantic model from chat_with_usage
    return evidence_dict, usage


def _family_model(family_name: str):
    """Get the evidence model class for a family."""
    entry = FAMILY_REGISTRY.get(family_name)
    if not entry:
        raise ValueError(f"Unknown family: {family_name}")
    return entry["evidence_model"]


async def _llm_extract(
    *,
    document_name: str,
    rows: List[Dict[str, Any]],
    family_name: str,
    model_name: str,
) -> tuple[Dict[str, Any], Dict[str, int]]:
    """
    Real LLM-based evidence extraction for one family (ASYNC for parallelization).
    
    Flow:
    1. Load family-specific prompts and JSON schema
    2. Build user prompt with document text and extraction instructions
    3. Call LLM via llm_proxy with structured output (Pydantic model)
    4. Return parsed evidence + token usage
    
    LLM now outputs seq_ids directly, saving ~3,650 tokens per family.
    """
    import asyncio
    from concurrent.futures import ThreadPoolExecutor
    
    # Step 1: Load family-specific configuration
    schema = PromptLoader.get_evidence_schema(family_name)  # JSON schema for this family
    system_message = PromptLoader.get_evidence_system(family_name)  # System role/persona
    instructions = PromptLoader.get_evidence_instructions(family_name)  # Extraction instructions
    
    # Step 2: Build the user prompt with document chunks and schema
    user_prompt = PromptBuilder.build_evidence_user_prompt(document_name, rows, schema, instructions)
    
    # Step 3: Construct chat messages (system + user)
    messages = [
        {"role": "system", "content": system_message},  # Tells LLM its role
        {"role": "user", "content": user_prompt},  # Contains document + task
    ]
    
    # Step 4: Call LLM via llm_proxy with Pydantic structured output
    # Run in thread pool to avoid blocking other families
    # This enables all 5 families to call LLM simultaneously
    def _sync_call():
        client = LLMClient(model_name=model_name)
        return client.chat_with_usage(messages=messages, response_model=_family_model(family_name))
    
    loop = asyncio.get_event_loop()
    parsed, usage = await loop.run_in_executor(None, _sync_call)
    
    # Step 5: Return parsed evidence and normalized token usage
    # parsed is a validated Pydantic object from chat_with_usage
    # Convert to dict for consistent return type
    evidence_dict = parsed.model_dump()
    
    return evidence_dict, {
        "input_tokens": usage.get("prompt_tokens", 0),
        "output_tokens": usage.get("completion_tokens", 0),
        "total_tokens": usage.get("total_tokens", 0),
    }


# Legacy batch processing and CLI removed - not used in Lambda execution path.
# For local testing, use Lambda.llm.proxy_local_runner instead.
