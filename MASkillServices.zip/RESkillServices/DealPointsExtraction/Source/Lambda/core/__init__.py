# Core business logic package init
