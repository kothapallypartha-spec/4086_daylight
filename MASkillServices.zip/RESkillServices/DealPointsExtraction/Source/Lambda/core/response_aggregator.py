"""
Aggregates family results into a simple response (widget_data handled by wrapper).
"""

from __future__ import annotations

from typing import Any, Dict, List

from Lambda.models.api.response import DealPointExtractionResponse


class ResponseAggregator:
    def aggregate(
        self,
        *,
        family_results: List[Dict[str, Any]],
        xhtml_chunks: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Aggregate family results into flattened deal points structure."""
        all_deal_points = {}
        failed_families = []
        
        # Build xpath lookup for source_texts expansion
        xpath_to_text = {chunk["xpath"]: chunk["text"] for chunk in xhtml_chunks}
        
        for family_result in family_results:
            if family_result.get("status") != "success":
                failed_families.append(self._build_failure_entry(family_result))
                continue
            
            deal_points = family_result.get("summary", {}).get("deal_points", {})
            self._process_deal_points(deal_points, all_deal_points, xpath_to_text)
        
        return self._build_result(all_deal_points, failed_families)
    
    def _build_failure_entry(self, family_result: Dict[str, Any]) -> Dict[str, str]:
        """Build a failure entry for a family that didn't succeed."""
        return {
            "family": family_result.get("family", "unknown"),
            "error": family_result.get("error", "unknown error")
        }
    
    def _process_deal_points(
        self,
        deal_points: Dict[str, Any],
        all_deal_points: Dict[str, Any],
        xpath_to_text: Dict[str, str]
    ) -> None:
        """Process all deal points from a family result."""
        for deal_point_name, deal_point_data in deal_points.items():
            if deal_point_data is None:
                continue
            
            flattened = self._flatten_deal_point(deal_point_name, deal_point_data)
            self._expand_source_texts(flattened, xpath_to_text)
            all_deal_points[deal_point_name] = flattened
    
    def _flatten_deal_point(
        self,
        deal_point_name: str,
        deal_point_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Flatten deal point data to include only necessary fields."""
        flattened = {
            "deal_point_name": deal_point_data.get("deal_point_name", deal_point_name),
            "xpath_mapping": deal_point_data.get("xpath_mapping")
        }
        
        # Add all combined_summary* fields
        for key, value in deal_point_data.items():
            if key.startswith("combined_summary"):
                flattened[key] = value
        
        return flattened
    
    def _expand_source_texts(
        self,
        flattened: Dict[str, Any],
        xpath_to_text: Dict[str, str]
    ) -> None:
        """Expand xpath_mapping to source_texts for downstream use."""
        xpath_mapping = flattened.get("xpath_mapping")
        if not xpath_mapping:
            return
        
        source_texts = []
        for xpath_entry in xpath_mapping:
            xpath_str = self._extract_xpath(xpath_entry)
            if xpath_str:
                text = xpath_to_text.get(xpath_str, "")
                if text:
                    source_texts.append(text)
        
        if source_texts:
            flattened["source_texts"] = source_texts
    
    def _extract_xpath(self, xpath_entry: Any) -> str:
        """Extract xpath string from entry (handles dict or string)."""
        if isinstance(xpath_entry, dict):
            return xpath_entry.get("xpath", "")
        return xpath_entry if isinstance(xpath_entry, str) else ""
    
    def _build_result(
        self,
        all_deal_points: Dict[str, Any],
        failed_families: List[Dict[str, str]]
    ) -> Dict[str, Any]:
        """Build final result dictionary."""
        result = {
            "deal_points": all_deal_points,
            "tokens": {}
        }
        
        if failed_families:
            result["failed_families"] = failed_families
        
        return result
