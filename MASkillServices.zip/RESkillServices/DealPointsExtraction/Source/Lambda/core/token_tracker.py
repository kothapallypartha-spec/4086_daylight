"""
Tracks token usage across families/stages.
"""

from __future__ import annotations

from typing import Dict, Any


class TokenTracker:
    def __init__(self):
        self.tokens: Dict[str, Dict[str, Dict[str, int]]] = {}

    def track_family(self, family_name: str, stage: str, tokens: Dict[str, int]):
        fam = self.tokens.setdefault(family_name, {})
        entry = fam.setdefault(stage, {"input": 0, "output": 0, "total": 0})
        entry["input"] += tokens.get("input_tokens", 0)
        entry["output"] += tokens.get("output_tokens", 0)
        entry["total"] += tokens.get("total_tokens", tokens.get("input_tokens", 0) + tokens.get("output_tokens", 0))

    def get_summary(self) -> Dict[str, Any]:
        stage_agg: Dict[str, Dict[str, int]] = {}
        total_input = 0
        total_output = 0
        for fam_stages in self.tokens.values():
            for stage, vals in fam_stages.items():
                stage_entry = stage_agg.setdefault(stage, {"input": 0, "output": 0, "total": 0})
                stage_entry["input"] += vals.get("input", 0)
                stage_entry["output"] += vals.get("output", 0)
                stage_entry["total"] += vals.get("total", 0)
                total_input += vals.get("input", 0)
                total_output += vals.get("output", 0)
        return {
            "total_tokens": total_input + total_output,
            "total_input_tokens": total_input,
            "total_output_tokens": total_output,
            "stages": stage_agg,
            "families": self.tokens,
        }
