"""
Processes a single family through evidence and summary stages.

Flow:
- Build rows from XHTML chunks.
- Stage 1: Extract evidence via LLM for this family.
- Stage 2: Generate summaries via LLM from extracted evidence.
- Track tokens and return validated results with xpath mappings.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from Lambda.core.evidence_extractor import extract_document, chunks_to_rows
from Lambda.core.summarizer import Summarizer
from Lambda.core.token_tracker import TokenTracker
from Lambda.config.families import FAMILY_REGISTRY


class FamilyProcessor:
    def __init__(
        self,
        family_name: str,
        model_name: str,
        token_tracker: TokenTracker,
        registry_entry: Optional[Dict[str, Any]] = None,
    ):
        self.family_name = family_name
        # Priority: registry_entry model_name > passed model_name
        self.model_name = (registry_entry or {}).get("model_name") or model_name
        self.token_tracker = token_tracker
        self.summarizer = Summarizer(family_name, self.model_name)
        self.registry_entry = registry_entry or {}

    async def process(
        self,
        *,
        xhtml_chunks: List[Dict[str, Any]],
        upload_identifier: str,
        document_name: str,
    ) -> Dict[str, Any]:
        # ===== STAGE 1: EVIDENCE EXTRACTION =====
        # Convert XHTML chunks into row format (path + text pairs)
        rows = chunks_to_rows(xhtml_chunks)
        
        # Call LLM to extract deal point evidence for this family
        # This is the main LLM call - sends prompts and document to llm_proxy
        # Returns structured JSON matching the family's evidence schema
        # Awaited to support async parallel execution
        evidence_json, usage = await extract_document(
            document_name=document_name,
            rows=rows,  # Document chunks with XPath and text
            family_name=self.family_name,  # Which family to extract (family_1, etc.)
            model_name=self.model_name,  # LLM model to use
        )
        
        # Validate extracted evidence against Pydantic schema
        # Ensures LLM output matches expected structure
        evidence_validated = self._evidence_model()(**evidence_json)
        
        # Expand seq_ids to source_texts and source_section_paths for Stage 2
        evidence_expanded, xpath_mapping = self._expand_seq_ids(evidence_validated.model_dump(), xhtml_chunks)
        
        # Track token usage for this family's evidence extraction
        self.token_tracker.track_family(self.family_name, stage="evidence", tokens=usage)

        # ===== STAGE 2: SUMMARIZATION (Streaming Pipeline) =====
        # IMMEDIATELY start summarization after evidence extraction completes
        # No waiting for other families - pipeline per family
        # Takes extracted evidence and generates human-readable summaries
        # LLM receives expanded evidence with source_texts and source_section_paths rebuilt from seq_ids
        # Final output includes all source metadata (xpaths, source_texts, offsets, seq_id)
        try:
            summary_result = await self.summarizer.summarize(evidence_expanded)
            
            # Track summarization tokens
            summary_usage = self.summarizer.get_last_usage()
            self.token_tracker.track_family(
                self.family_name, 
                stage="summary", 
                tokens={
                    "input_tokens": summary_usage.get("prompt_tokens", 0),
                    "output_tokens": summary_usage.get("completion_tokens", 0),
                    "total_tokens": summary_usage.get("total_tokens", 0),
                }
            )
        except Exception as e:
            # Add context and re-raise - orchestrator will handle logging
            raise RuntimeError(f"Summarization failed for {self.family_name}: {str(e)}") from e
        
        summary_validated = self._summary_model()(**summary_result)
        
        # Enrich summary output with additional metadata
        summary_dict = summary_validated.model_dump() if summary_validated else {}
        if "deal_points" in summary_dict and summary_dict["deal_points"]:
            for deal_point_name, deal_point_data in summary_dict["deal_points"].items():
                if deal_point_data is None:
                    continue
                
                # Add metadata fields for API response
                deal_point_data["deal_point_name"] = deal_point_name
                deal_point_data["xpath_mapping"] = xpath_mapping.get(deal_point_name) if xpath_mapping else None
                
                # Note: source_texts and source_section_paths retained for debugging/traceability
                # They'll be removed by response_aggregator for final API output

        return {
            "family": self.family_name,
            "status": "success",
            "evidence": evidence_validated.model_dump(),
            "summary": summary_dict,
            "upload_identifier": upload_identifier,
        }

    def _summary_model(self):
        """Get summary model from registry."""
        entry = FAMILY_REGISTRY.get(self.family_name, {})
        return entry.get("summary_model") or FAMILY_REGISTRY["family_1"]["summary_model"]

    def _evidence_model(self):
        """Get evidence model from registry."""
        entry = FAMILY_REGISTRY.get(self.family_name, {})
        return entry.get("evidence_model") or FAMILY_REGISTRY["family_1"]["evidence_model"]

    def _expand_seq_ids(self, evidence_dict: Dict[str, Any], chunks: List[Dict[str, Any]]) -> tuple[Dict[str, Any], Dict[str, List[Dict[str, Any]]]]:
        """
        Expand seq_ids in evidence to source_texts and source_section_paths for Stage 2.
        
        Also builds xpath_mapping with seq_id included for final output traceability.
        
        Returns: (expanded_evidence_dict, xpath_mapping)
        """
        # Create lookup: seq_id -> chunk
        seq_to_chunk = {chunk.get("seq_id"): chunk for chunk in chunks if chunk.get("seq_id") is not None}
        
        # Get deal_points from evidence
        deal_points = evidence_dict.get("deal_points", {})
        xpath_mapping = {}
        
        for deal_point_name, deal_point_data in deal_points.items():
            if not isinstance(deal_point_data, dict):
                continue
            
            seq_ids = deal_point_data.get("seq_ids", [])
            if not seq_ids:
                continue
            
            # Rebuild source_texts and source_section_paths from seq_ids
            source_texts = []
            source_section_paths = []
            xpath_list = []
            
            for seq_id in seq_ids:
                chunk = seq_to_chunk.get(seq_id)
                if chunk:
                    source_texts.append(chunk.get("text", ""))
                    source_section_paths.append(chunk.get("xpath", ""))
                    
                    # Build xpath_mapping entry with seq_id included
                    xpath_list.append({
                        "xpath": chunk.get("xpath", ""),
                        "seq_id": seq_id,
                        "start_offset": chunk.get("start_offset", -1),
                        "end_offset": chunk.get("end_offset", -1)
                    })
            
            # Update deal point with expanded fields
            deal_point_data["source_texts"] = source_texts
            deal_point_data["source_section_paths"] = source_section_paths
            
            # Add to xpath_mapping
            if xpath_list:
                xpath_mapping[deal_point_name] = xpath_list
        
        return evidence_dict, xpath_mapping
