"""
Stage 2 summarizer (LLM-backed).
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional

from Lambda.prompts.prompt_loader import PromptLoader
from Lambda.prompts.prompt_builder import PromptBuilder
from Lambda.llm.client import LLMClient
from Lambda.models.summary.family_1_summary import Family1SummaryDocument
from Lambda.models.summary.family_2_summary import Family2SummaryDocument
from Lambda.models.summary.family_3_summary import Family3SummaryDocument
from Lambda.models.summary.family_4_summary import Family4SummaryDocument
from Lambda.models.summary.family_5_summary import Family5SummaryDocument


SUMMARY_MODEL_MAP = {
    "family_1": Family1SummaryDocument,
    "family_2": Family2SummaryDocument,
    "family_3": Family3SummaryDocument,
    "family_4": Family4SummaryDocument,
    "family_5": Family5SummaryDocument,
}


class Summarizer:
    def __init__(self, family_name: str, model_name: str):
        self.family_name = family_name
        self.model_name = model_name
        self._last_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

    async def summarize(self, evidence_json: Dict[str, Any]) -> Dict[str, Any]:
        if self.family_name not in SUMMARY_MODEL_MAP:
            raise ValueError(f"Unknown family: {self.family_name}")
        return await self._llm_summary(evidence_json)
    
    def get_last_usage(self) -> Dict[str, int]:
        """Get token usage from last summarization call."""
        return self._last_usage

    async def _llm_summary(self, evidence_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate summaries from evidence using token-optimized LLM call.
        
        Flow: Extract metadata → Strip for LLM → Call LLM → Restore metadata
        Why: Reduce tokens by removing xpaths/texts (LLM doesn't need them for summarization)
        """
        # STEP 1: Extract and preserve source metadata (xpaths, source_texts)
        # We'll add these back after LLM generates summaries
        preserved_metadata = self._extract_source_metadata(evidence_json)
        
        # STEP 2: Create token-optimized input for LLM
        # Remove source_section_paths and source_texts (saves ~30-40% tokens)
        # LLM only needs structured fields to generate summaries
        evidence_for_llm = self._prepare_llm_input(evidence_json)
        
        # STEP 3: Call LLM to generate summaries from structured evidence
        system_message = PromptLoader.get_summary_system(self.family_name)
        instructions = PromptLoader.get_summary_instructions(self.family_name)
        user_prompt = PromptBuilder.build_summary_user_prompt(
            evidence_json.get("document_name", "document"),
            evidence_for_llm,
            instructions,
        )
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_prompt},
        ]
        client = LLMClient(model_name=self.model_name)
        model_cls = SUMMARY_MODEL_MAP[self.family_name]
        
        llm_summaries, usage = await asyncio.get_event_loop().run_in_executor(
            None, lambda: client.chat_with_usage(messages=messages, response_model=model_cls)
        )
        
        # STEP 4: Restore source metadata to complete output
        # Final output: LLM summaries + original xpaths + source_texts
        complete_output = self._merge_source_metadata(llm_summaries.model_dump(), preserved_metadata)
        
        self._last_usage = usage
        return complete_output

    def _extract_source_metadata(self, evidence_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract source metadata (xpaths, offsets, seq_id) from evidence JSON.
        This metadata will be preserved and merged into final summary output.
        """
        metadata = {}
        
        # Navigate to deal_points structure
        deal_points = evidence_json.get("deal_points", {})
        if not deal_points:
            return metadata
        
        # Extract source metadata from each deal point category
        for category_name, category_data in deal_points.items():
            if not isinstance(category_data, dict):
                continue
            
            category_metadata = {}
            
            # Extract source_section_paths (xpaths)
            if "source_section_paths" in category_data:
                category_metadata["source_section_paths"] = category_data["source_section_paths"]
            
            # Extract source_texts (keep for reference, even though sent to LLM)
            if "source_texts" in category_data:
                category_metadata["source_texts"] = category_data["source_texts"]
            
            # Store metadata indexed by category
            if category_metadata:
                metadata[category_name] = category_metadata
        
        return metadata
    
    def _prepare_llm_input(self, evidence_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Prepare evidence JSON for LLM input:
        - Keep all structured fields (dates, parties, amounts, conditions)
        - Remove source_texts (not needed - structured fields have all context)
        - Remove source_section_paths (xpaths not needed by LLM)
        
        This maximizes token reduction while preserving semantic information.
        """
        import copy
        llm_input = copy.deepcopy(evidence_json)
        
        # Navigate to deal_points and remove source metadata from each category
        deal_points = llm_input.get("deal_points", {})
        for category_data in deal_points.values():
            if isinstance(category_data, dict):
                # Remove xpath metadata (not needed for summarization)
                category_data.pop("source_section_paths", None)
                # Remove text snippets (structured fields provide all context)
                category_data.pop("source_texts", None)
        
        return llm_input
    
    def _merge_source_metadata(self, summary_output: Dict[str, Any], source_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge LLM summary output with preserved source metadata.
        Final JSON contains:
        - All combined_summary_* fields (from LLM)
        - source_section_paths (xpaths) - from evidence
        - source_texts - from evidence
        - All structured evidence fields - from evidence
        """
        # Navigate to deal_points in summary output
        deal_points = summary_output.get("deal_points", {})
        
        # Merge source metadata back into each category
        for category_name, category_data in deal_points.items():
            if not isinstance(category_data, dict):
                continue
            
            # Get preserved metadata for this category
            category_metadata = source_metadata.get(category_name, {})
            
            # Merge source_section_paths and source_texts back in
            if "source_section_paths" in category_metadata:
                category_data["source_section_paths"] = category_metadata["source_section_paths"]
            if "source_texts" in category_metadata:
                category_data["source_texts"] = category_metadata["source_texts"]
        
        return summary_output
