"""
Integration tests for GenAI Agent Service - Temporary Upload Flow

Tests the complete integration with GenAI agent service using temporary file upload.
Validates: WAM authentication, file upload, session creation, and agent invocation.

Environment Configuration:
    - Default: local (http://127.0.0.1:8080)
    - Change CURR_ENV to test against cert/dev/staging/prod

Usage:
    pytest Tests/test_agent_service.py -v
    pytest Tests/test_agent_service.py::test_deal_points_extraction_with_temp_upload -v

Prerequisites:
    - For local: GenAI agent service running on localhost:8080
    - For deployed: Network access to agent service and upload endpoints
    - WAM authentication credentials configured
"""

import json
import time
import uuid
from pathlib import Path
from typing import Dict, Any, Optional
import requests
import pytest
from pydantic import BaseModel, Field
import urllib3

# Disable insecure request warnings for local testing
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Import centralized utilities from sp_uploader
from sp_uploader import get_wam_headers, upload_file, ENV_DATA

# ============================================================================
# ENVIRONMENT CONFIGURATION
# ============================================================================

# Change this to test different environments: "local", "cert", "dev", "staging", "prod"
CURR_ENV = "dev"

# ============================================================================
# AGENT SERVICE INTERACTION
# ============================================================================

def create_session(agent_host: str, user_id: str, headers: Optional[Dict[str, str]] = None) -> str:
    """
    Create agent service session for conversation context.
    
    Tries local endpoint first (/api/v1/sessions), falls back to 
    deployed endpoint (/api/v1/proxy/sessions) if that fails.
    
    Returns:
        Session ID for subsequent requests
    """
    # Ensure we have WAM headers
    if headers is None:
        headers = get_wam_headers(CURR_ENV)

    # Try local endpoint first with JSON payload
    payload = {
        "user_id": user_id,
        "session_name": user_id,
        "client_id": "test",
    }
    session_url = f"{agent_host}/api/v1/sessions"
    try:
        response = requests.post(
            session_url,
            json=payload,
            headers={**headers, "Content-Type": "application/json"},
            timeout=10,
            verify=False
        )
        response.raise_for_status()
        data = response.json()
        # Accept either direct or nested data.session_id
        return data.get("session_id") or data.get("data", {}).get("session_id")
    except (requests.HTTPError, KeyError) as e:
        print(f"Local session endpoint failed ({e}), trying deployed endpoint...")

        # Fallback to deployed endpoint
        session_url = f"{agent_host}/api/v1/proxy/sessions"
        response = requests.post(
            session_url,
            json=payload,
            headers={**headers, "Content-Type": "application/json"},
            timeout=10,
            verify=False
        )
        response.raise_for_status()
        data = response.json()
        return data.get("session_id") or data.get("data", {}).get("session_id")


def process_payload(
    agent_host: str,
    session_id: str,
    upload_url: str,
    doc_name: str,
    headers: Dict[str, str],
    user_id: str = "test_user",
    timeout: int = 600,
    doc_model: Optional[Any] = None
) -> Dict[str, Any]:
    """
    Send document to agent service for deal points extraction.
    
    Uses non-streaming endpoint for local testing (/api/v1/messages),
    streaming endpoint for deployed environments (/api/v1/messages_stream).
    
    Args:
        agent_host: Base URL of agent service
        session_id: Active session ID
        upload_url: URL of uploaded document
        doc_name: Name of document
        headers: Authentication headers
        user_id: User identifier
        timeout: Request timeout in seconds
        doc_model: Optional DocFileModel with extra metadata
        
    Returns:
        Agent service response with extracted deal points
    """
    # Determine endpoint based on environment (treat localhost as local)
    is_local = "127.0.0.1" in agent_host or "localhost" in agent_host
    endpoint = "/api/v1/messages" if is_local else "/api/v1/messages_stream"
    url = f"{agent_host}{endpoint}"
    
    payload = {
        "user_id": user_id,
        "session_id": session_id,
        "intent": "re_deal_point_extraction_skill",
        "message": "Extract deal points from this document",
        "streaming": not is_local,
        "headers": headers
    }

    # Most agent endpoints expect a top-level 'docs' list
    if upload_url:
        doc_entry = {
            "document_display_name": doc_name,
            "upload_link": upload_url,
        }
        if doc_model:
            doc_entry["upload_identifier"] = getattr(doc_model, "upload_identifier", None)
            doc_entry["document_page_count"] = getattr(doc_model, "document_page_count", None)
            doc_entry["document_character_count"] = getattr(doc_model, "document_character_count", None)
            
        payload["docs"] = [doc_entry]
    
    print(f"Sending request to {endpoint} (streaming={not is_local})...")
    
    # Ensure content-type
    req_headers = {**headers, "Content-Type": "application/json"}

    if is_local:
        # Non-streaming for local
        response = requests.post(url, json=payload, headers=req_headers, timeout=timeout, verify=False)
        if response.status_code == 422:
            print(f"Error 422: {response.text}")
        response.raise_for_status()
        return response.json()
    else:
        # Streaming for deployed
        response = requests.post(url, json=payload, headers=req_headers, stream=True, timeout=timeout, verify=False)
        if response.status_code == 422:
            print(f"Error 422: {response.text}")
        response.raise_for_status()
        
        # Collect all streaming chunks
        full_response = ""
        for line in response.iter_lines():
            if line:
                decoded = line.decode('utf-8')
                if decoded.startswith('data: '):
                    full_response += decoded[6:]
        
        return json.loads(full_response)


# ============================================================================
# TEST CASES
# ============================================================================

def test_deal_points_extraction_with_temp_upload():
    """
    Test complete flow: upload → create session → extract deal points.
    
    Flow:
        1. Generate WAM authentication tokens
        2. Upload test PSA document to temp storage
        3. Wait for document conversion (XHTML/HTML)
        4. Create agent service session
        5. Send extraction request with document URL
        6. Validate response structure
    
    Validates:
        - Authentication succeeds
        - Document uploads successfully
        - Conversion completes
        - Session creation works
        - Agent service responds with valid structure
    """
    # Setup
    env_config = ENV_DATA[CURR_ENV]
    agent_host = env_config["url"]
    asset_group = env_config["asset_group"]
    user = env_config["user"]
    user_id = env_config["id"]
    
    print(f"\n{'='*80}")
    print(f"Testing GenAI Agent Service Integration - Temp Upload")
    print(f"Environment: {CURR_ENV}")
    print(f"Agent Host: {agent_host}")
    print(f"Asset Group: {asset_group}")
    print(f"{'='*80}\n")
    
    # Get authentication headers
    print("Step 1: Generating WAM authentication tokens...")
    wam_headers = get_wam_headers(CURR_ENV)
    print("✓ Authentication tokens generated\n")
    
    # Upload document
    print("Step 2: Uploading test document...")
    # Use the PDF test document present in the Tests folder
    test_doc_path = Path(__file__).parent / "psa_10.pdf"
    
    if not test_doc_path.exists():
        pytest.skip(f"Test document not found: {test_doc_path}")
    
    doc_model = upload_file(CURR_ENV, test_doc_path)
    upload_url = doc_model.upload_link
    print(f"✓ Document uploaded: {upload_url[:100]}...\n")
    
    # Create session
    print("Step 3: Creating agent service session...")
    session_id = create_session(agent_host, user_id)
    print(f"✓ Session created: {session_id}\n")
    
    # Process document
    print("Step 4: Sending extraction request to agent service...")
    response = process_payload(
        agent_host=agent_host,
        session_id=session_id,
        upload_url=upload_url,
        doc_name=test_doc_path.name,
        headers=wam_headers,
        user_id=user_id,
        timeout=600,
        doc_model=doc_model
    )
    print("✓ Response received\n")
    
    # Validate response
    print("Step 5: Validating response structure...")
    assert isinstance(response, dict), "Response should be a dictionary"
    
    # Save response for inspection
    output_file = Path(__file__).parent / "agent_service_temp_response.json"
    with open(output_file, 'w') as f:
        json.dump(response, f, indent=2)
    print(f"✓ Response saved to: {output_file}")
    
    print(f"\n{'='*80}")
    print("TEST PASSED - Agent service integration working!")
    print(f"{'='*80}\n")
