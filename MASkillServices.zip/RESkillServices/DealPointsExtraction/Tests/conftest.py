import os


def pytest_configure(config):
    """Set environment variables needed for local tests.

    Ensures code that attempts to read LLM tenant from Secrets Manager
    falls back to this test tenant instead of attempting AWS calls.
    """
    os.environ.setdefault("LLM_PROXY_TENANT", "test-tenant")
"""Test configuration."""
import sys
from pathlib import Path

# Add Source directory to sys.path for test imports
source_dir = Path(__file__).parent.parent / "Source"
sys.path.insert(0, str(source_dir))
