"""
Test error handling and improved features in main.py
"""

import pytest
from fastapi.testclient import TestClient
import sys
from pathlib import Path

# Add Lambda source to path
# Navigate from tests/integration -> DealPointsExtraction/Source
lambda_path = Path(__file__).resolve().parents[2] / "DealPointsExtraction" / "Source"
sys.path.insert(0, str(lambda_path))

from Lambda.main import app


class TestImprovedFeatures:
    """Test improved error handling and features."""
    
    @pytest.fixture
    def client(self):
        """Create test client."""
        return TestClient(app)
    
    def test_error_response_format(self, client):
        """Test that errors return proper ErrorResponse format with traceback."""
        # Send request with missing required fields
        response = client.post("/deal-points-extraction/", json={
            "user_id": "test",
            "session_id": "test",
            "message": "test",
            "intent": "re_deal_point_extraction_skill",
            "docs": [
                {
                    "document_display_name": "test.html",
                    "upload_identifier": "test123"
                    # Missing both content and upload_link - should error
                }
            ]
        })
        
        # Should return 400 with error details
        assert response.status_code == 400
        data = response.json()
        assert "detail" in data
        assert "error" in data["detail"]
    
    def test_content_or_url_validation(self, client):
        """Test that either content or upload_link is required."""
        # Test with neither
        response = client.post("/deal-points-extraction/", json={
            "user_id": "test",
            "session_id": "test",
            "message": "test",
            "intent": "re_deal_point_extraction_skill",
            "docs": [
                {
                    "document_display_name": "test.html",
                    "upload_identifier": "test123"
                }
            ]
        })
        assert response.status_code == 400
        
    def test_inline_content_processing(self, client):
        """Test that inline HTML content is processed correctly."""
        response = client.post("/deal-points-extraction/", json={
            "user_id": "test",
            "session_id": "test",
            "message": "Extract deal points",
            "intent": "re_deal_point_extraction_skill",
            "docs": [
                {
                    "document_display_name": "test.html",
                    "upload_identifier": "test123",
                    "content": "<html><body><h1>Purchase Agreement</h1><p>Purchase price is $5,000,000</p></body></html>"
                }
            ]
        })
        
        # Should process successfully (or fail with auth error, not validation error)
        assert response.status_code in [200, 500]  # 200=success, 500=LLM auth issue
        if response.status_code == 500:
            # If it fails, should be LLM-related, not validation
            data = response.json()
            assert "detail" in data
    
    def test_model_name_override(self, client):
        """Test that model_name can be overridden in request."""
        response = client.post("/deal-points-extraction/", json={
            "user_id": "test",
            "session_id": "test",
            "message": "Extract deal points",
            "intent": "re_deal_point_extraction_skill",
            "model_name": "OpenAI_gpt-4o-2024-05-13_LexisAI_US_3363",
            "docs": [
                {
                    "document_display_name": "test.html",
                    "upload_identifier": "test123",
                    "content": "<html><body><p>Test content</p></body></html>"
                }
            ]
        })
        
        # Should accept the request (may fail on LLM call but not validation)
        assert response.status_code in [200, 500]
    
    def test_logging_initialization(self, client):
        """Test that logger initialization message appears."""
        # Just making a request should trigger the logger
        response = client.get("/deal-points-extraction/healthcheck")
        assert response.status_code == 200
        # Logger should have been initialized (check via logs if needed)
    
    def test_health_check_format(self, client):
        """Test health check returns proper format."""
        response = client.get("/deal-points-extraction/healthcheck")
        assert response.status_code == 200
        data = response.json()
        
        # Should have all required fields
        assert "status" in data
        assert "git_commit" in data
        assert "release_unit" in data
        assert data["status"] == "healthy"
