"""
Unit tests for TokenTracker.

Tests token tracking functionality including:
- Single family tracking
- Multiple family aggregation
- Stage tracking (evidence vs summary)
- Summary generation
"""

import pytest
from Lambda.core.token_tracker import TokenTracker


class TestTokenTracker:
    """Test suite for TokenTracker class."""

    def test_init(self):
        """Test TokenTracker initialization."""
        tracker = TokenTracker()
        assert tracker.tokens == {}

    def test_track_single_usage(self):
        """Test tracking usage for single family."""
        tracker = TokenTracker()
        
        tracker.track_family(
            family_name="family_1",
            stage="evidence",
            tokens={"input_tokens": 100, "output_tokens": 50}
        )
        
        summary = tracker.get_summary()
        assert "family_1" in summary["families"]
        assert "evidence" in summary["families"]["family_1"]
        assert summary["families"]["family_1"]["evidence"]["input"] == 100
        assert summary["families"]["family_1"]["evidence"]["output"] == 50
        assert summary["families"]["family_1"]["evidence"]["total"] == 150

    def test_track_multiple_stages(self):
        """Test tracking both evidence and summary stages."""
        tracker = TokenTracker()
        
        tracker.track_family("family_1", "evidence", {"input_tokens": 100, "output_tokens": 50})
        tracker.track_family("family_1", "summary", {"input_tokens": 200, "output_tokens": 75})
        
        summary = tracker.get_summary()
        assert "evidence" in summary["families"]["family_1"]
        assert "summary" in summary["families"]["family_1"]
        assert summary["families"]["family_1"]["evidence"]["total"] == 150
        assert summary["families"]["family_1"]["summary"]["total"] == 275

    def test_track_multiple_families(self):
        """Test tracking multiple families."""
        tracker = TokenTracker()
        
        tracker.track_family("family_1", "evidence", {"input_tokens": 100, "output_tokens": 50})
        tracker.track_family("family_2", "evidence", {"input_tokens": 200, "output_tokens": 75})
        tracker.track_family("family_3", "evidence", {"input_tokens": 150, "output_tokens": 60})
        
        summary = tracker.get_summary()
        assert len(summary["families"]) == 3
        assert "family_1" in summary["families"]
        assert "family_2" in summary["families"]
        assert "family_3" in summary["families"]

    def test_accumulate_tokens(self):
        """Test accumulating tokens for same family/stage."""
        tracker = TokenTracker()
        
        tracker.track_family("family_1", "evidence", {"input_tokens": 100, "output_tokens": 50})
        tracker.track_family("family_1", "evidence", {"input_tokens": 50, "output_tokens": 25})
        
        summary = tracker.get_summary()
        # Should accumulate
        assert summary["families"]["family_1"]["evidence"]["input"] == 150
        assert summary["families"]["family_1"]["evidence"]["output"] == 75

    def test_zero_tokens(self):
        """Test handling of zero token usage."""
        tracker = TokenTracker()
        
        tracker.track_family("family_1", "evidence", {"input_tokens": 0, "output_tokens": 0})
        
        summary = tracker.get_summary()
        assert summary["families"]["family_1"]["evidence"]["total"] == 0

    def test_empty_tracker_summary(self):
        """Test summary of empty tracker."""
        tracker = TokenTracker()
        summary = tracker.get_summary()
        assert summary["total_tokens"] == 0
        assert summary["families"] == {}
        assert summary["stages"] == {}


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
