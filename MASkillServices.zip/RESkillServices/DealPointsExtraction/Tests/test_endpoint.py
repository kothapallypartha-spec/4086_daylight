"""
Test script for DealPointsExtraction endpoint (deployed or local).

Usage:
    # Test deployed dev endpoint
    python Tests/test_endpoint.py

    # Test deployed cert endpoint
    ASSET_GROUP=cdc1c python Tests/test_endpoint.py

    # Test local endpoint
    python Tests/test_endpoint.py local

    # Healthcheck only
    python Tests/test_endpoint.py health
"""
import os
import sys
import logging
import requests
import json
import pytest
from pathlib import Path

DEBUG = True
logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger()

# Determine base URL
if "local" in sys.argv:
    BASE_URL = "http://localhost:8888"
else:
    grp = os.environ.get('ASSET_GROUP', 'ddc1c')  # default to dev
    if grp[0] in ['d', 'c']:
        BASE_URL = f"https://{grp}-lplus-ai-services.route53.lexis.com"
    else:
        BASE_URL = f"https://{grp}-ai-plus-services.route53.lexis.com"


def test_healthcheck_endpoint():
    """Test the healthcheck endpoint."""
    url = f"{BASE_URL}/deal-points-extraction/healthcheck"
    logger.info(f"Testing healthcheck: {url}")
    
    response = requests.get(url, timeout=10)
    logger.info(f"Status: {response.status_code}")
    assert response.status_code == 200
    logger.info(f"Response: {response.text}")
    
    if response.status_code == 200:
        logger.info("✅ Healthcheck passed!")
    else:
        logger.error(f"❌ Healthcheck failed: {response.status_code}")


def _test_extract_inline(html_file: str = "Tests/psa_10.html"):
    """
    Test the extract endpoint with inline HTML.
    
    Args:
        html_file: Path to HTML file to send inline
    """
    url = f"{BASE_URL}/deal-points-extraction/extract/"
    logger.info(f"Testing extract endpoint: {url}")
    
    # Read HTML file
    html_path = Path(html_file)
    if not html_path.exists():
        logger.error(f"HTML file not found: {html_file}")
        return None
    
    html_content = html_path.read_text(encoding='utf-8')
    
    payload = {
        "user_id": "test_user",
        "session_id": "test_session_" + str(hash(html_content))[:8],
        "message": "Extract deal points from the provided document",
        "streaming": False,
        "intent": "re_deal_point_extraction_skill",
        "docs": [
            {
                "document_display_name": html_path.name,
                "upload_identifier": html_path.stem,
                "content": html_content
            }
        ],
        "headers": {}
    }
    
    logger.info(f"Payload: intent={payload['intent']}, docs[0].document_display_name={payload['docs'][0]['document_display_name']}, content_length={len(html_content)}")
    
    minute = 60
    response = requests.post(
        url,
        headers={"Content-Type": "application/json"},
        json=payload,
        timeout=5 * minute
    )
    
    logger.info(f"Response status: {response.status_code}")
    
    if response.status_code == 200:
        result = response.json()
        logger.info(f"✅ Success! Result keys: {result.keys()}")
        logger.info(f"Full result:\n{json.dumps(result, indent=2)}")
        return result
    else:
        logger.error(f"❌ Error response: {response.text}")
        try:
            error_data = response.json()
            if 'traceback' in error_data:
                logger.error(f"Traceback:\n{error_data['traceback']}")
        except:
            pass
        return None


def _test_extract_url(doc_url: str, doc_name: str = "test_doc"):
    """
    Test the extract endpoint with a URL.
    
    Args:
        doc_url: URL to the document (presigned S3 URL or agent-service vault URL)
        doc_name: Document name for the request
    """
    url = f"{BASE_URL}/deal-points-extraction/extract/"
    logger.info(f"Testing extract endpoint with URL: {url}")
    
    payload = {
        "user_id": "test_user",
        "session_id": "test_session_url",
        "message": "Extract deal points from the provided document",
        "streaming": False,
        "intent": "re_deal_point_extraction_skill",
        "docs": [
            {
                "document_display_name": doc_name,
                "upload_identifier": doc_name,
                "upload_link": doc_url
            }
        ],
        "headers": {}
    }
    
    logger.info(f"Payload: intent={payload['intent']}, docs[0].document_display_name={doc_name}, upload_link={doc_url}")
    
    minute = 60
    response = requests.post(
        url,
        headers={"Content-Type": "application/json"},
        json=payload,
        timeout=5 * minute
    )
    
    logger.info(f"Response status: {response.status_code}")
    
    if response.status_code == 200:
        result = response.json()
        logger.info(f"✅ Success! Result keys: {result.keys()}")
        logger.info(f"Full result:\n{json.dumps(result, indent=2)}")
        return result
    else:
        logger.error(f"❌ Error response: {response.text}")
        try:
            error_data = response.json()
            if 'traceback' in error_data:
                logger.error(f"Traceback:\n{error_data['traceback']}")
        except:
            pass
        return None


def test_extract_inline_smoke():
    """Smoke test for inline extraction."""
    # Only run if local
    if "localhost" not in BASE_URL:
        pytest.skip("Skipping smoke test for non-local environment")
    
    html_file = "Tests/psa_10.html"
    if not Path(html_file).exists():
        pytest.skip(f"Test file {html_file} not found")
        
    result = _test_extract_inline(html_file)
    assert result is not None
    assert "deal_points" in result or "data" in result


if __name__ == "__main__":
    if "health" in sys.argv:
        # Only test healthcheck
        test_healthcheck_endpoint()
    elif "--url" in sys.argv:
        # Test with URL argument
        idx = sys.argv.index("--url")
        if idx + 1 < len(sys.argv):
            doc_url = sys.argv[idx + 1]
            doc_name = sys.argv[idx + 2] if idx + 2 < len(sys.argv) else "test_doc"
            _test_extract_url(doc_url, doc_name)
        else:
            logger.error("Usage: python test_endpoint.py --url <url> [doc_name]")
    else:
        # Default: test healthcheck + inline HTML extraction
        logger.info("=" * 80)
        logger.info("Testing DealPointsExtraction endpoints")
        logger.info(f"Base URL: {BASE_URL}")
        logger.info("=" * 80)
        
        # 1. Healthcheck
        test_healthcheck_endpoint()
        
        # 2. Extract with inline HTML
        logger.info("\n" + "=" * 80)
        _test_extract_inline("Tests/psa_10.html")
