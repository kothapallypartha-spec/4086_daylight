"""
Integration tests for GenAI Agent Service - Vault Document Flow

Tests agent service integration using vault document access.
Validates: WAM authentication, vault configuration, session creation, and agent invocation.

Environment Configuration:
    - Default: local (http://127.0.0.1:8080)
    - Change CURR_ENV to test against cert/dev/staging/prod

Usage:
    pytest Tests/test_agent_service_vault.py -v
    pytest Tests/test_agent_service_vault.py::test_deal_points_extraction_with_vault -v

Prerequisites:
    - For local: GenAI agent service running on localhost:8080
    - For deployed: Network access to agent service
    - Valid vault and document IDs (update vault_config below)
    - WAM authentication credentials configured
"""

import json
import uuid
from pathlib import Path
from typing import Dict, Any
import requests
import pytest

# Import WAM authentication and environment data from sp_uploader
from sp_uploader import get_wam_headers, ENV_DATA

# ============================================================================
# ENVIRONMENT CONFIGURATION
# ============================================================================

# Change this to test different environments: "local", "cert", "dev", "staging", "prod"
CURR_ENV = "local"

# ============================================================================
# VAULT CONFIGURATION
# ============================================================================

# Vault document configuration for testing
# Using the same IDs as DueDiligence since the input file is the same
vault_config = [
    {
        "type": "dbotf",
        "content_type": "",
        "document_type_filter": [],
        "corpus": [
            "bc542a55-7225-4103-a0d9-3e5693ac93e6/cbd01714-0eea-4f23-9877-0691951f7822/cfeec98f-0c3a-4bd8-bb9b-a414ffdd6fba"
        ],
        "documents": [
            "579923b9-d988-433b-9e1d-f171d8c6ac22"
        ],
        "vault_public_id": "d5b38771-f3f1-4d89-8623-1fe1dfe1fbd2",
        "subvault_public_id": ""
    }
]

# ============================================================================
# AGENT SERVICE INTERACTION
# ============================================================================

def create_session(agent_host: str, user_id: str) -> str:
    """
    Create agent service session for conversation context.
    """
    payload = {
        "user_id": user_id,
        "session_name": user_id,
        "client_id": "test",
    }
    headers = {"Content-Type": "application/json"}
    
    # Try local endpoint first
    session_url = f"{agent_host}/api/v1/sessions"
    try:
        response = requests.post(session_url, json=payload, headers=headers, timeout=10)
        if response.status_code == 404:
            raise requests.HTTPError("Not Found")
        response.raise_for_status()
        return response.json().get('session_id') or response.json().get('data', {}).get('session_id')
    except (requests.HTTPError, KeyError, requests.ConnectionError):
        # Fallback to proxy endpoint
        session_url = f"{agent_host}/api/v1/proxy/sessions"
        response = requests.post(session_url, json=payload, headers=headers, timeout=10)
        response.raise_for_status()
        return response.json().get('session_id') or response.json().get('data', {}).get('session_id')


def process_payload(
    agent_host: str,
    user_id: str,
    session_id: str,
    vault_config: list,
    headers: Dict[str, str],
    timeout: int = 600
) -> Dict[str, Any]:
    """
    Send vault document reference to agent service for deal points extraction.
    """
    # Determine endpoint based on environment
    is_local = "127.0.0.1" in agent_host or "localhost" in agent_host
    endpoint = "/api/v1/messages" if is_local else "/api/v1/messages_stream"
    url = f"{agent_host}{endpoint}"
    
    payload = {
        "user_id": user_id,
        "session_id": session_id,
        "intent": "re_deal_point_extraction_skill",
        "message": "Perform the following skill service: Real Estate Deal Points Extraction",
        "data_source": vault_config,
        "streaming": not is_local
    }
    
    print(f"Sending request to {url}...")
    
    if is_local:
        response = requests.post(url, json=payload, headers=headers, timeout=timeout)
        response.raise_for_status()
        return response.json()
    else:
        # Streaming for deployed
        response = requests.post(url, json=payload, headers=headers, stream=True, timeout=timeout)
        response.raise_for_status()
        
        last_chunk = {}
        for line in response.iter_lines():
            if line:
                decoded = line.decode('utf-8')
                if decoded.startswith('data: '):
                    chunk = json.loads(decoded[6:])
                    last_chunk = chunk
                    if chunk.get("detail-type") == "conversational-manager-message-finished":
                        return chunk
        return last_chunk


# ============================================================================
# TEST CASES
# ============================================================================

def test_deal_points_extraction_with_vault():
    """
    Test vault document access flow: create session → extract from vault.
    
    Flow:
        1. Check if using placeholder vault IDs (skip if so)
        2. Generate WAM authentication tokens
        3. Create agent service session
        4. Send extraction request with vault document references
        5. Validate response structure
    
    Validates:
        - Authentication succeeds
        - Session creation works
        - Vault document access authorized
        - Agent service responds with valid structure
    """
    # Check for placeholder IDs
    if vault_config[0]["documents"][0] == "579923b9-d988-433b-9e1d-f171d8c6ac22":
        pytest.skip("Using placeholder vault/document IDs. Update vault_config with real IDs to run this test.")
    
    # Setup
    env_config = ENV_DATA[CURR_ENV]
    agent_host = env_config["url"]
    asset_group = env_config["asset_group"]
    user = env_config["user"]
    user_id = env_config["id"]
    
    print(f"\n{'='*80}")
    print(f"Testing GenAI Agent Service Integration - Vault Document")
    print(f"Environment: {CURR_ENV}")
    print(f"Agent Host: {agent_host}")
    print(f"Asset Group: {asset_group}")
    print(f"Vault ID: {vault_config[0]['vault_public_id']}")
    print(f"Document ID: {vault_config[0]['documents'][0]}")
    print(f"{'='*80}\n")
    
    # Get authentication headers
    print("Step 1: Generating WAM authentication tokens...")
    wam_headers = get_wam_headers(CURR_ENV)
    print("✓ Authentication tokens generated\n")
    
    # Create session
    print("Step 2: Creating agent service session...")
    session_id = create_session(agent_host, user_id)
    print(f"✓ Session created: {session_id}\n")
    
    # Process vault document
    print("Step 3: Sending extraction request to agent service...")
    response = process_payload(
        agent_host=agent_host,
        user_id=user_id,
        session_id=session_id,
        vault_config=vault_config,
        headers=wam_headers,
        timeout=600
    )
    
    print("✓ Response received\n")
    
    # Validate response
    print("Step 4: Validating response structure...")
    assert isinstance(response, dict), "Response should be a dictionary"
    
    # Save response for inspection
    output_file = Path(__file__).parent / "agent_service_vault_response.json"
    with open(output_file, 'w') as f:
        json.dump(response, f, indent=2)
    print(f"✓ Response saved to: {output_file}")
    
    print(f"\n{'='*80}")
    print("TEST PASSED - Vault document access working!")
    print(f"{'='*80}\n")


def test_deal_points_extraction_multiple_vault_documents():
    """
    Test extraction from multiple vault documents in single request.
    
    Similar to single document test but validates handling of multiple
    document references from vault.
    """
    # Check for placeholder IDs
    if vault_config[0]["documents"][0] == "579923b9-d988-433b-9e1d-f171d8c6ac22":
        pytest.skip("Using placeholder vault/document IDs. Update vault_config with real IDs to run this test.")
    
    # Setup
    env_config = ENV_DATA[CURR_ENV]
    agent_host = env_config["url"]
    asset_group = env_config["asset_group"]
    user = env_config["user"]
    user_id = env_config["id"]
    
    print(f"\n{'='*80}")
    print(f"Testing GenAI Agent Service Integration - Multiple Vault Documents")
    print(f"Environment: {CURR_ENV}")
    print(f"Agent Host: {agent_host}")
    print(f"Document Count: {len(vault_config[0]['documents'])}")
    print(f"{'='*80}\n")
    
    # Get authentication headers
    wam_headers = get_wam_headers(CURR_ENV)
    
    # Create session
    session_id = create_session(agent_host, user_id)
    
    # Process vault documents
    response = process_payload(
        agent_host=agent_host,
        user_id=user_id,
        session_id=session_id,
        vault_config=vault_config,
        headers=wam_headers,
        timeout=600
    )
    
    # Validate response
    assert isinstance(response, dict), "Response should be a dictionary"
    
    # Save response
    output_file = Path(__file__).parent / "agent_service_vault_multi_response.json"
    with open(output_file, 'w') as f:
        json.dump(response, f, indent=2)
    
    print(f"\n{'='*80}")
    print("TEST PASSED - Multiple vault documents working!")
    print(f"{'='*80}\n")
