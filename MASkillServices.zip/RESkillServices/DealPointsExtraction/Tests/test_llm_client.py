"""
Unit tests for LLM client and response parsing.

Tests the flow from llm_proxy response -> Pydantic validation.
"""
import json
import pytest
from pathlib import Path
import sys

# Add Source to path for imports
# Navigate from tests/unit -> DealPointsExtraction/Source
project_root = Path(__file__).parent.parent / "Source"
sys.path.insert(0, str(project_root))

from Lambda.llm.client import LLMClient
from Lambda.models.evidence.family_1_evidence import EvidenceDocumentPE


def test_json_string_parsing():
    """Test that JSON strings are correctly parsed to dicts."""
    # Simulate LLM returning a JSON string
    json_string = """{
        "document_name": "test.html",
        "deal_points": {
            "purchase_price_and_payment_method": {
                "purchase_price_text": "test",
                "payment_method_summary": null,
                "seq_ids": []
            },
            "earnest_money": {
                "earnest_money_amount_text": null,
                "timing_and_disposition": null,
                "seq_ids": []
            },
            "closing_adjustments": {
                "cutover_datetime_text": null,
                "items_prorated": [],
                "price_adjustment_events": [],
                "post_closing_readjustment": null,
                "seq_ids": []
            },
            "closing_costs": {
                "key_cost_allocations": [],
                "seq_ids": []
            },
            "brokerage_commissions": {
                "key_brokerage_terms": [],
                "seq_ids": []
            }
        }
    }"""
    
    # Parse it
    parsed_dict = json.loads(json_string)
    
    # Validate with Pydantic
    evidence = EvidenceDocumentPE(**parsed_dict)
    
    assert evidence.document_name == "test.html"
    assert evidence.deal_points is not None


def test_pydantic_validation_with_dict():
    """Test Pydantic model can be instantiated with a dict."""
    data = {
        "document_name": "test.html",
        "deal_points": {
            "purchase_price_and_payment_method": {
                "purchase_price_text": "test",
                "payment_method_summary": None,
                "source_section_paths": [],
                "source_texts": []
            },
            "earnest_money": {
                "earnest_money_amount_text": None,
                "timing_and_disposition": None,
                "source_section_paths": [],
                "source_texts": []
            },
            "closing_adjustments": {
                "cutover_datetime_text": None,
                "items_prorated": [],
                "price_adjustment_events": [],
                "post_closing_readjustment": None,
                "source_section_paths": [],
                "source_texts": []
            },
            "closing_costs": {
                "key_cost_allocations": [],
                "source_section_paths": [],
                "source_texts": []
            },
            "brokerage_commissions": {
                "key_brokerage_terms": [],
                "source_section_paths": [],
                "source_texts": []
            }
        }
    }
    
    # Should work with dict
    evidence = EvidenceDocumentPE(**data)
    assert evidence.document_name == "test.html"


def test_pydantic_validation_with_json_string_fails():
    """Test that passing JSON string to Pydantic fails (this is the bug)."""
    json_string = '{"document_name": "test.html", "deal_points": {}}'
    
    # This should FAIL - Pydantic expects dict, not string
    with pytest.raises(Exception):
        evidence = EvidenceDocumentPE(json_string)


def test_model_dump_returns_dict():
    """Test that model_dump() returns a dictionary."""
    data = {
        "document_name": "test.html",
        "deal_points": {
            "purchase_price_and_payment_method": {
                "purchase_price_text": "test",
                "payment_method_summary": None,
                "seq_ids": []
            },
            "earnest_money": {
                "earnest_money_amount_text": None,
                "timing_and_disposition": None,
                "seq_ids": []
            },
            "closing_adjustments": {
                "cutover_datetime_text": None,
                "items_prorated": [],
                "price_adjustment_events": [],
                "post_closing_readjustment": None,
                "seq_ids": []
            },
            "closing_costs": {
                "key_cost_allocations": [],
                "seq_ids": []
            },
            "brokerage_commissions": {
                "key_brokerage_terms": [],
                "seq_ids": []
            }
        }
    }
    
    evidence = EvidenceDocumentPE(**data)
    dumped = evidence.model_dump()
    
    assert isinstance(dumped, dict)
    assert dumped["document_name"] == "test.html"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
