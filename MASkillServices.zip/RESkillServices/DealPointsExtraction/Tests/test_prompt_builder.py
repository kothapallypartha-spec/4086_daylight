import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2] / "Source"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Lambda.prompts.prompt_builder import PromptBuilder
from Lambda.prompts.evidence_schemas import EVIDENCE_SCHEMA_FAMILY_1


def test_build_evidence_user_prompt_limits_chunks():
    chunks = [{"path": f"/p[{i}]", "text": f"text {i}"} for i in range(5)]
    prompt = PromptBuilder.build_evidence_user_prompt(
        document_name="doc",
        xhtml_chunks=chunks,
        schema_json=EVIDENCE_SCHEMA_FAMILY_1,
        instructions="do it",
        max_chunks=2,
    )
    assert "[1] PATH: /p[0]" in prompt
    assert "[3]" not in prompt
