import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2] / "Source"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Lambda.prompts.prompt_loader import PromptLoader
from Lambda.prompts.evidence_schemas import (
    EVIDENCE_SCHEMA_FAMILY_1,
    EVIDENCE_SCHEMA_FAMILY_2,
    EVIDENCE_SCHEMA_FAMILY_3,
    EVIDENCE_SCHEMA_FAMILY_4,
    EVIDENCE_SCHEMA_FAMILY_5,
)


@pytest.mark.parametrize(
    "family,expected_keys",
    [
        ("family_1", EVIDENCE_SCHEMA_FAMILY_1["deal_points"].keys()),
        ("family_2", EVIDENCE_SCHEMA_FAMILY_2["deal_points"].keys()),
        ("family_3", EVIDENCE_SCHEMA_FAMILY_3["deal_points"].keys()),
        ("family_4", EVIDENCE_SCHEMA_FAMILY_4["deal_points"].keys()),
        ("family_5", EVIDENCE_SCHEMA_FAMILY_5["deal_points"].keys()),
    ],
)
def test_evidence_schema_exists(family, expected_keys):
    schema = PromptLoader.get_evidence_schema(family)
    assert schema, f"Schema missing for {family}"
    assert "deal_points" in schema
    assert set(schema["deal_points"].keys()) == set(expected_keys)


@pytest.mark.parametrize("family", ["family_1", "family_2", "family_3", "family_4", "family_5"])
def test_system_and_instructions_present(family):
    system = PromptLoader.get_evidence_system(family)
    instr = PromptLoader.get_evidence_instructions(family)
    assert system is not None
    assert instr is not None
