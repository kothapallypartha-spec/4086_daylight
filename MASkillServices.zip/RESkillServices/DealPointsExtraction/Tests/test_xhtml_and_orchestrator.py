import sys
import asyncio
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2] / "Source"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Lambda.preprocessing.xhtml_processor import XHTMLProcessor
from Lambda.core.orchestrator import Orchestrator
from Lambda.config.families import enabled_families


def test_xhtml_processor_single_paragraph():
    html = "<html><body><p id='p1'>Hello world.</p></body></html>"
    chunks = XHTMLProcessor.process(html)
    # Should produce exactly one chunk with matching text and offsets starting at 0
    assert len(chunks) == 1
    ch = chunks[0]
    assert ch["text"] == "Hello world."
    # Offsets should be non-negative and show a positive span
    assert ch["start_offset"] >= 0
    assert ch["end_offset"] > ch["start_offset"]
    assert "/p" in ch["xpath"]


def test_orchestrator_stub_all_families(monkeypatch):
    """Test orchestrator processes all families successfully with mocked LLM."""
    from unittest.mock import patch, AsyncMock, Mock
    
    # Set mock tenant key to prevent AWS Secrets Manager lookup
    monkeypatch.setenv("LLM_PROXY_TENANT", "test-tenant-key")
    
    # Mock extract_document to return family-specific data (2-tuple: evidence, usage)
    async def mock_extract_side_effect(*, document_name, rows, family_name, model_name):
            family_data_map = {
                "family_1": {
                    "purchase_price_and_payment_method": {},
                    "earnest_money": {},
                    "closing_adjustments": {},
                    "closing_costs": {},
                    "brokerage_commissions": {}
                },
                "family_2": {
                    "access_and_inspection": {},
                    "title": {},
                    "survey": {},
                    "environmental_assessments": {}
                },
                "family_3": {
                    "closing_mechanics": {},
                    "proceedings_at_closing": {},
                    "conditions_to_closing": {},
                    "possession_at_closing": {}
                },
                "family_4": {
                    "affirmative_covenants": {},
                    "seller_warranties_reps_covenants": {},
                    "buyer_warranties_reps_covenants": {}
                },
                "family_5": {
                    "risk_of_loss_and_insurance": {},
                    "condemnation": {},
                    "remedies_default": {},
                    "indemnity": {}
                }
            }
            mock_evidence = {
                "document_name": document_name,
                "deal_points": family_data_map.get(family_name, {})
            }
            mock_usage = {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150}
            return (mock_evidence, mock_usage)
    
    # Mock the LLM proxy client to prevent real API calls
    # Return a universal summary with ALL family fields (Pydantic models use extra="ignore")
    import json
    universal_summary = {
        "document_name": "doc.html",
        "deal_points": {
            # Family 1 fields
            "purchase_price_and_payment_method": {},
            "earnest_money": {},
            "closing_adjustments": {},
            "closing_costs": {},
            "brokerage_commissions": {},
            # Family 2 fields
            "access_and_inspection": {},
            "title": {},
            "survey": {},
            "environmental_assessments": {},
            # Family 3 fields
            "closing_mechanics": {},
            "proceedings_at_closing": {},
            "conditions_to_closing": {},
            "possession_at_closing": {},
            # Family 4 fields
            "affirmative_covenants": {},
            "seller_warranties_reps_covenants": {},
            "buyer_warranties_reps_covenants": {},
            # Family 5 fields
            "risk_of_loss_and_insurance": {},
            "condemnation": {},
            "remedies_default": {},
            "indemnity": {}
        }
    }
    
    mock_llm_client = Mock()
    mock_llm_client.chat = Mock(return_value=json.dumps(universal_summary))
    
    with patch("Lambda.core.family_processor.extract_document", new_callable=AsyncMock) as mock_extract, \
         patch("Lambda.llm.client.create_simple_proxy", return_value=mock_llm_client):
        mock_extract.side_effect = mock_extract_side_effect

        html = "<html><body><p>Sample text for stub</p></body></html>"
        chunks = XHTMLProcessor.process(html)
        orch = Orchestrator(model_name="OpenAI_gpt-5.1-2025-11-13_LexisAI_US_3363")
        
        result = asyncio.run(
            orch.process_document(
                xhtml_chunks=chunks,
                upload_identifier="uid-123",
                document_name="doc.html",
            )
        )
        
        # Verify flattened structure with all deal points
        deal_points = result.get("deal_points", {})
        assert len(deal_points) > 0, "Should have deal points"
        
        # All 5 families processed successfully - should have around 22 deal points
        # (Some may be missing if they have no summary fields)
        assert len(deal_points) >= 20, f"Expected at least 20 deal points, got {len(deal_points)}"
        
        # Verify we got deal points from all families
        expected_deal_points = [
            "purchase_price_and_payment_method", "earnest_money",  # family_1
            "access_and_inspection", "title",  # family_2
            "closing_mechanics", "proceedings_at_closing",  # family_3
            "affirmative_covenants",  # family_4
            "risk_of_loss_and_insurance", "condemnation"  # family_5
        ]
        for expected_dp in expected_deal_points:
            assert expected_dp in deal_points, f"Missing expected deal point: {expected_dp}"
        
        # Tokens should be present
        tokens = result.get("tokens", {})
        assert "total_tokens" in tokens
