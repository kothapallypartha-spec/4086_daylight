"""
Complex integration tests with multiple LLM providers.

Tests:
- Cross-provider comparison (OpenAI vs Claude)
- Model performance benchmarking
- Output quality validation
- Error recovery across providers
- Cost analysis
"""

import pytest
import json
import time
from pathlib import Path
from Lambda.core.orchestrator import Orchestrator


class TestMultiProviderIntegration:
    """Complex multi-provider integration test suite."""

    @pytest.fixture
    def arkansas_html_path(self):
        """Path to Arkansas test document."""
        return Path("c:/RE_SKILLS_IMPLEMENTATION/4086-daylight-skill-services/RESkillServices/DealPointsExtraction/tests/data/ar_document.html")

    @pytest.fixture
    def arkansas_chunks(self, arkansas_html_path):
        """Load Arkansas document chunks."""
        if not arkansas_html_path.exists():
            pytest.skip(f"Test document not found: {arkansas_html_path}")
        
        from Lambda.preprocessing.xhtml_processor import XHTMLProcessor
        html_content = arkansas_html_path.read_text(encoding="utf-8")
        return XHTMLProcessor.process(html_content)

    @pytest.fixture
    def output_dir(self):
        """Create output directory for test results."""
        output_path = Path("c:/RE_SKILLS_IMPLEMENTATION/4086-daylight-skill-services/RESkillServices/DealPointsExtraction/tests/test_output")
        output_path.mkdir(parents=True, exist_ok=True)
        return output_path

    @pytest.fixture
    def openai_models(self):
        """List of OpenAI models to test."""
        return [
            "OpenAI_gpt-5.1-2025-11-13_LexisPlusAIUS_3363_nonprod",
            "OpenAI_gpt-5-mini-2025-11-13_LexisPlusAIUS_3363_nonprod",
        ]

    @pytest.fixture
    def claude_models(self):
        """List of Claude models to test."""
        return [
            "anthropic-claude-sonnet-4-5-20250929_LexisPlusAIUS_3363_nonprod",
            "anthropic-claude-opus-4-5-20250523_LexisPlusAIUS_3363_nonprod",
        ]

    @pytest.mark.skip(reason="Real LLM test - run manually")
    @pytest.mark.asyncio
    async def test_compare_openai_vs_claude(self, arkansas_chunks, output_dir):
        """Compare extraction quality between OpenAI and Claude."""
        models = {
            "gpt-5.1": "OpenAI_gpt-5.1-2025-11-13_LexisPlusAIUS_3363_nonprod",
            "claude-sonnet": "anthropic-claude-sonnet-4-5-20250929_LexisPlusAIUS_3363_nonprod",
        }
        
        results = {}
        
        for name, model in models.items():
            print(f"\n{'='*60}")
            print(f"Testing {name}: {model}")
            print(f"{'='*60}")
            
            orchestrator = Orchestrator(
                model_name=model,
                family_names=["family_1"],
            )
            
            start_time = time.time()
            result = await orchestrator.process_document(
                xhtml_chunks=arkansas_chunks,
                upload_identifier=f"compare-{name}",
                document_name="arkansas.html",
            )
            elapsed = time.time() - start_time
            
            results[name] = {
                "model": model,
                "elapsed_seconds": elapsed,
                "extraction": result,
            }
            
            # Save individual results
            output_file = output_dir / f"comparison_{name}_{int(time.time())}.json"
            with open(output_file, "w") as f:
                json.dump(results[name], f, indent=2)
            
            print(f"[TIME] {name}: {elapsed:.2f}s")
            print(f"[TOKENS] {result['tokens']}")
        
        # Save comparison
        comparison_file = output_dir / f"provider_comparison_{int(time.time())}.json"
        with open(comparison_file, "w") as f:
            json.dump(results, f, indent=2)
        
        print(f"\n[SAVED] Comparison results: {comparison_file}")

    @pytest.mark.skip(reason="Real LLM test - run manually")
    @pytest.mark.asyncio
    async def test_benchmark_all_openai_models(self, arkansas_chunks, output_dir, openai_models):
        """Benchmark all OpenAI models."""
        results = {}
        
        for model in openai_models:
            model_short = model.split("_")[1]
            print(f"\n[START] Benchmarking {model_short}")
            
            orchestrator = Orchestrator(
                model_name=model,
                family_names=["family_1", "family_2"],
            )
            
            start_time = time.time()
            result = await orchestrator.process_document(
                xhtml_chunks=arkansas_chunks,
                upload_identifier=f"bench-{model_short}",
                document_name="arkansas.html",
            )
            elapsed = time.time() - start_time
            
            results[model_short] = {
                "model": model,
                "elapsed_seconds": elapsed,
                "families_processed": len(result["families"]),
                "tokens": result["tokens"],
            }
            
            print(f"[DONE] {model_short}: {elapsed:.2f}s")
        
        # Save benchmark results
        benchmark_file = output_dir / f"openai_benchmark_{int(time.time())}.json"
        with open(benchmark_file, "w") as f:
            json.dump(results, f, indent=2)
        
        print(f"\n[SAVED] OpenAI benchmark: {benchmark_file}")

    @pytest.mark.skip(reason="Real LLM test - run manually")
    @pytest.mark.asyncio
    async def test_error_recovery_model_fallback(self, arkansas_chunks):
        """Test error recovery when primary model fails."""
        # Try with invalid model first (should fail)
        # Then fallback to valid model
        
        primary_model = "invalid_model_that_does_not_exist"
        fallback_model = "OpenAI_gpt-5.1-2025-11-13_LexisPlusAIUS_3363_nonprod"
        
        orchestrator = Orchestrator(
            model_name=primary_model,
            family_names=["family_1"],
        )
        
        try:
            await orchestrator.process_document(
                xhtml_chunks=arkansas_chunks[:50],  # Use subset for speed
                upload_identifier="test-fallback",
                document_name="arkansas.html",
            )
            assert False, "Should have raised error for invalid model"
        except Exception as e:
            print(f"[EXPECTED ERROR] {e}")
            
            # Now try with fallback
            orchestrator.model_name = fallback_model
            result = await orchestrator.process_document(
                xhtml_chunks=arkansas_chunks[:50],
                upload_identifier="test-fallback-success",
                document_name="arkansas.html",
            )
            
            assert len(result["families"]) == 1
            print("[SUCCESS] Fallback model worked")

    @pytest.mark.skip(reason="Real LLM test - run manually")
    @pytest.mark.asyncio
    async def test_parallel_families_different_models(self, arkansas_chunks):
        """Test processing different families with different models."""
        # This tests if we can dynamically switch models per family
        # Currently not supported but could be future enhancement
        
        family_model_map = {
            "family_1": "OpenAI_gpt-5.1-2025-11-13_LexisPlusAIUS_3363_nonprod",
            "family_2": "anthropic-claude-sonnet-4-5-20250929_LexisPlusAIUS_3363_nonprod",
        }
        
        # For now, test each family with its model separately
        results = {}
        
        for family, model in family_model_map.items():
            orchestrator = Orchestrator(
                model_name=model,
                family_names=[family],
            )
            
            result = await orchestrator.process_document(
                xhtml_chunks=arkansas_chunks[:100],  # Subset for speed
                upload_identifier=f"multi-{family}",
                document_name="arkansas.html",
            )
            
            results[family] = result
        
        assert len(results) == 2
        print(f"[SUCCESS] Processed 2 families with 2 different models")

    @pytest.mark.skip(reason="Real LLM test - run manually")
    @pytest.mark.asyncio
    async def test_output_quality_validation(self, arkansas_chunks):
        """Test output quality across models."""
        model = "OpenAI_gpt-5.1-2025-11-13_LexisPlusAIUS_3363_nonprod"
        
        orchestrator = Orchestrator(
            model_name=model,
            family_names=["family_1"],
        )
        
        result = await orchestrator.process_document(
            xhtml_chunks=arkansas_chunks,
            upload_identifier="quality-test",
            document_name="arkansas.html",
        )
        
        family_result = result["families"][0]
        evidence = family_result["evidence"]
        
        # Quality checks
        deal_points = evidence["deal_points"]
        assert len(deal_points) > 0, "Should extract at least one deal point"
        
        # Check purchase price extraction
        if "purchase_price_and_payment_method" in deal_points:
            pp = deal_points["purchase_price_and_payment_method"]
            assert pp is not None
            
            # Should have extracted text or paths
            has_content = (
                pp.get("purchase_price_text") or
                pp.get("source_texts") or
                pp.get("source_section_paths")
            )
            assert has_content, "Purchase price should have some content"
        
        print("[SUCCESS] Output quality validation passed")

    @pytest.mark.skip(reason="Real LLM test - run manually")
    @pytest.mark.asyncio
    async def test_cost_analysis_token_usage(self, arkansas_chunks):
        """Analyze token costs across models."""
        models = {
            "gpt-5.1": "OpenAI_gpt-5.1-2025-11-13_LexisPlusAIUS_3363_nonprod",
            "claude-sonnet": "anthropic-claude-sonnet-4-5-20250929_LexisPlusAIUS_3363_nonprod",
        }
        
        # Approximate costs per 1M tokens (example rates)
        costs = {
            "gpt-5.1": {"input": 2.50, "output": 10.00},
            "claude-sonnet": {"input": 3.00, "output": 15.00},
        }
        
        results = {}
        
        for name, model in models.items():
            orchestrator = Orchestrator(
                model_name=model,
                family_names=["family_1"],
            )
            
            result = await orchestrator.process_document(
                xhtml_chunks=arkansas_chunks,
                upload_identifier=f"cost-{name}",
                document_name="arkansas.html",
            )
            
            tokens = result["tokens"]["family_1"]["evidence"]
            input_tokens = tokens["input_tokens"]
            output_tokens = tokens["output_tokens"]
            
            # Calculate cost
            cost = (
                (input_tokens / 1_000_000) * costs[name]["input"] +
                (output_tokens / 1_000_000) * costs[name]["output"]
            )
            
            results[name] = {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": tokens["total_tokens"],
                "estimated_cost_usd": round(cost, 4),
            }
            
            print(f"[COST] {name}: ${cost:.4f} USD")
            print(f"  - Input: {input_tokens:,} tokens")
            print(f"  - Output: {output_tokens:,} tokens")
        
        # Compare costs
        cost_diff = abs(results["gpt-5.1"]["estimated_cost_usd"] - results["claude-sonnet"]["estimated_cost_usd"])
        print(f"\n[DIFF] Cost difference: ${cost_diff:.4f} USD")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])

