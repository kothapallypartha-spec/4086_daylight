"""
Unit tests for FamilyProcessor.

Tests the single family processing logic including:
- Evidence extraction coordination
- Summarization coordination
- Token tracking
- Error handling
- Model selection from registry
"""

import sys
from pathlib import Path

# Add Source to path for imports
# Navigate from tests/unit -> DealPointsExtraction/Source
project_root = Path(__file__).parent.parent / "Source"
sys.path.insert(0, str(project_root))

import pytest
from unittest.mock import Mock, AsyncMock, patch
from Lambda.core.family_processor import FamilyProcessor
from Lambda.core.token_tracker import TokenTracker


class TestFamilyProcessor:
    """Test suite for FamilyProcessor class."""

    @pytest.fixture
    def token_tracker(self):
        """Create a token tracker for tests."""
        return TokenTracker()

    @pytest.fixture
    def sample_chunks(self):
        """Sample XHTML chunks for testing."""
        return [
            {"xpath": "/html/body/p[1]", "text": "Purchase price is $1,000,000", "seq_id": 1},
            {"xpath": "/html/body/p[2]", "text": "Earnest money is $50,000", "seq_id": 2},
            {"xpath": "/html/body/p[3]", "text": "Closing date is December 31, 2025", "seq_id": 3},
        ]

    def test_init_family_processor(self, token_tracker):
        """Test FamilyProcessor initialization."""
        processor = FamilyProcessor(
            family_name="family_1",
            model_name="test_model",
            token_tracker=token_tracker,
        )
        
        assert processor.family_name == "family_1"
        assert processor.model_name == "test_model"
        assert processor.token_tracker is token_tracker

    def test_init_with_registry_entry(self, token_tracker):
        """Test initialization with registry entry for model fallback."""
        registry_entry = {"model_name": "registry_model"}
        
        processor = FamilyProcessor(
            family_name="family_2",
            model_name="OpenAI_gpt-5.1-2025-11-13_LexisAI_US_3363",
            token_tracker=token_tracker,
            registry_entry=registry_entry,
        )
        
        assert processor.model_name == "registry_model"

    def test_evidence_model_mapping(self, token_tracker):
        """Test that evidence model is correctly retrieved from registry."""
        processor = FamilyProcessor(
            family_name="family_1",
            model_name="test",
            token_tracker=token_tracker,
        )
        
        model_cls = processor._evidence_model()
        assert model_cls.__name__ == "EvidenceDocumentPE"

    def test_summary_model_mapping(self, token_tracker):
        """Test that summary model is correctly retrieved from registry."""
        processor = FamilyProcessor(
            family_name="family_2",
            model_name="test",
            token_tracker=token_tracker,
        )
        
        model_cls = processor._summary_model()
        assert model_cls.__name__ == "Family2SummaryDocument"

    def test_evidence_model_fallback(self, token_tracker):
        """Test fallback to family_1 model for unknown family."""
        processor = FamilyProcessor(
            family_name="unknown_family",
            model_name="test",
            token_tracker=token_tracker,
        )
        
        model_cls = processor._evidence_model()
        assert model_cls.__name__ == "EvidenceDocumentPE"  # Falls back to family_1

    @pytest.mark.asyncio
    async def test_process_with_stub(self, token_tracker, sample_chunks):
        """Test full processing with stubbed extraction."""
        # Mock extract_document with minimal valid Pydantic data for family_1
        mock_evidence = {
            "document_name": "test.html",
            "deal_points": {
                "purchase_price_and_payment_method": {},
                "earnest_money": {},
                "closing_adjustments": {},
                "closing_costs": {},
                "brokerage_commissions": {}
            }
        }
        mock_usage = {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150}

        with patch("Lambda.core.family_processor.extract_document", new_callable=AsyncMock) as mock_extract:
            mock_extract.return_value = (mock_evidence, mock_usage)
            
            processor = FamilyProcessor(
                family_name="family_1",
                model_name="test_model",
                token_tracker=token_tracker,
            )
            
            # Mock summarizer to avoid real LLM calls
            processor.summarizer.summarize = AsyncMock(return_value={"summary": "test"})
            
            result = await processor.process(
                xhtml_chunks=sample_chunks,
                upload_identifier="test-upload",
                document_name="test.html",
            )
            
            assert result["family"] == "family_1"
            assert result["status"] == "success"
            assert "evidence" in result
            assert "summary" in result
            assert result["upload_identifier"] == "test-upload"

    @pytest.mark.asyncio
    async def test_process_tracks_tokens(self, token_tracker, sample_chunks):
        """Test that token usage is tracked correctly."""
        # Mock extract_document with minimal valid Pydantic data for family_1
        mock_evidence = {
            "document_name": "test.html",
            "deal_points": {
                "purchase_price_and_payment_method": {},
                "earnest_money": {},
                "closing_adjustments": {},
                "closing_costs": {},
                "brokerage_commissions": {}
            }
        }
        mock_usage = {"input_tokens": 200, "output_tokens": 100, "total_tokens": 300}

        with patch("Lambda.core.family_processor.extract_document", new_callable=AsyncMock) as mock_extract:
            mock_extract.return_value = (mock_evidence, mock_usage)

            processor = FamilyProcessor(
                family_name="family_1",
                model_name="test_model",
                token_tracker=token_tracker,
            )

            # Mock summarizer to avoid real LLM calls
            processor.summarizer.summarize = AsyncMock(return_value={"summary": "test"})
            # Mock get_last_usage to return token info for tracking
            processor.summarizer.get_last_usage = Mock(return_value={"prompt_tokens": 50, "completion_tokens": 25, "total_tokens": 75})

            await processor.process(
                xhtml_chunks=sample_chunks,
                upload_identifier="test-upload",
                document_name="test.html",
            )
            
            summary = token_tracker.get_summary()
            assert "family_1" in summary["families"]
            assert "evidence" in summary["families"]["family_1"]
            assert "summary" in summary["families"]["family_1"]
            # Verify token counts were tracked
            assert summary["families"]["family_1"]["evidence"]["total"] == 300

    @pytest.mark.asyncio
    async def test_process_handles_summarization_error(self, token_tracker, sample_chunks):
        """Test that summarization errors are propagated correctly."""
        # Mock extract_document with minimal valid Pydantic data for family_1
        mock_evidence = {
            "document_name": "test.html",
            "deal_points": {
                "purchase_price_and_payment_method": {},
                "earnest_money": {},
                "closing_adjustments": {},
                "closing_costs": {},
                "brokerage_commissions": {}
            }
        }
        mock_usage = {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150}

        with patch("Lambda.core.family_processor.extract_document", new_callable=AsyncMock) as mock_extract:
            mock_extract.return_value = (mock_evidence, mock_usage)

            processor = FamilyProcessor(
                family_name="family_1",
                model_name="test_model",
                token_tracker=token_tracker,
            )

            # Mock summarizer to raise error
            processor.summarizer.summarize = AsyncMock(side_effect=ValueError("Summarization failed"))
            
            with pytest.raises(RuntimeError, match="Summarization failed for family_1"):
                await processor.process(
                    xhtml_chunks=sample_chunks,
                    upload_identifier="test-upload",
                    document_name="test.html",
                )

    @pytest.mark.asyncio
    async def test_process_validates_evidence(self, token_tracker, sample_chunks):
        """Test that evidence is validated against Pydantic schema."""
        # Mock extract_document with minimal valid Pydantic data for family_1
        mock_evidence = {
            "document_name": "test.html",
            "deal_points": {
                "purchase_price_and_payment_method": {},
                "earnest_money": {},
                "closing_adjustments": {},
                "closing_costs": {},
                "brokerage_commissions": {}
            }
        }
        mock_usage = {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150}

        with patch("Lambda.core.family_processor.extract_document", new_callable=AsyncMock) as mock_extract:
            mock_extract.return_value = (mock_evidence, mock_usage)
            
            processor = FamilyProcessor(
                family_name="family_1",
                model_name="test_model",
                token_tracker=token_tracker,
            )
            
            # Mock summarizer to avoid real LLM calls
            processor.summarizer.summarize = AsyncMock(return_value={"summary": "test"})
            
            result = await processor.process(
                xhtml_chunks=sample_chunks,
                upload_identifier="test-upload",
                document_name="test.html",
            )
            
            # Check evidence has expected structure
            evidence = result["evidence"]
            assert "document_name" in evidence
            assert "deal_points" in evidence
            assert isinstance(evidence["deal_points"], dict)

    @pytest.mark.asyncio
    async def test_process_all_families(self, token_tracker, sample_chunks):
        """Test processing with all 5 family types."""
        families = ["family_1", "family_2", "family_3", "family_4", "family_5"]

        # Different families have different required fields
        family_mock_data = {
            "family_1": {
                "purchase_price_and_payment_method": {},
                "earnest_money": {},
                "closing_adjustments": {},
                "closing_costs": {},
                "brokerage_commissions": {}
            },
            "family_2": {
                "access_and_inspection": {},
                "title": {},
                "survey": {},
                "environmental_assessments": {}
            },
            "family_3": {
                "closing_mechanics": {},
                "proceedings_at_closing": {},
                "conditions_to_closing": {},
                "possession_at_closing": {}
            },
            "family_4": {
                "affirmative_covenants": {},
                "seller_warranties_reps_covenants": {},
                "buyer_warranties_reps_covenants": {}
            },
            "family_5": {
                "risk_of_loss_and_insurance": {},
                "condemnation": {},
                "remedies_default": {},
                "indemnity": {}
            }
        }

        mock_usage = {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150}

        for family in families:
            mock_evidence = {
                "document_name": "test.html",
                "deal_points": family_mock_data[family]
            }

            with patch("Lambda.core.family_processor.extract_document", new_callable=AsyncMock) as mock_extract:
                mock_extract.return_value = (mock_evidence, mock_usage)

                processor = FamilyProcessor(
                    family_name=family,
                    model_name="test_model",
                    token_tracker=token_tracker,
                )

                # Mock summarizer to avoid real LLM calls
                processor.summarizer.summarize = AsyncMock(return_value={"summary": "test"})

                result = await processor.process(
                    xhtml_chunks=sample_chunks,
                    upload_identifier="test-upload",
                    document_name="test.html",
                )
                
                assert result["family"] == family
                assert result["status"] == "success"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])



