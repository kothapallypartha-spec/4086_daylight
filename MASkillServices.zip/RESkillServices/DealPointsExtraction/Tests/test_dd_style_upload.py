import requests
import json
from pathlib import Path
from sp_uploader import FileUploader, ENV_DATA
import uuid

def create_session(platform_base_url, user_id, headers):
    """Create a session in the Gen AI Platform"""
    url = f"{platform_base_url}/api/v1/proxy/sessions"
    payload = {
        "user_id": user_id,
        "session_name": user_id,
        "client_id": "test"
    }
    try:
        response = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=5)
        if response.status_code == 200:
            session_id = response.json()["data"]["session_id"]
            print(f"[OK] Session created: {session_id}")
            return session_id
        else:
            print(f"[WARN] Failed to create session: {response.text}")
            return str(uuid.uuid4())
    except Exception as e:
        print(f"[WARN] Could not connect to platform at {platform_base_url}: {e}")
        return str(uuid.uuid4())

def test_due_diligence_style_upload():
    CURR_ENV = "local"
    platform_base_url = "http://localhost:8080"
    platform_stream_url = f"{platform_base_url}/api/v1/messages_stream"
    
    # 1. Upload document using the DueDiligence style FileUploader
    print("Step 1: Uploading document to Search Platform...")
    uploader = FileUploader(CURR_ENV)
    test_doc_path = Path(__file__).parent / "psa_10.pdf"
    
    if not test_doc_path.exists():
        print(f"Error: Test document not found at {test_doc_path}")
        return

    document, skill_headers = uploader.upload_file(test_doc_path)
    # Normalize headers: decode bytes, strip newlines, and canonicalize header names
    def _normalize_headers(hdrs: dict) -> dict:
        out = {}
        for k, v in (hdrs or {}).items():
            # canonicalize header name to expected casing
            key = k
            if isinstance(key, str):
                # ensure common X-LN-* casing
                if key.lower().startswith('x-ln-'):
                    parts = key.split('-')
                    key = '-'.join([p.upper() if i == 1 else p.capitalize() if i > 1 else p for i, p in enumerate(parts)])
            # decode bytes
            if isinstance(v, (bytes, bytearray)):
                try:
                    val = v.decode('utf-8')
                except Exception:
                    val = str(v)
            else:
                val = str(v)
            # remove newlines and excessive whitespace
            val = val.replace('\n', '').replace('\r', '').strip()
            out[key] = val
        return out

    skill_headers = _normalize_headers(skill_headers)
    # Convert /docx to /docxhtml like DueDiligence does
    document.upload_link = document.upload_link.replace("/docx", "/docxhtml")
    print(f"[OK] Document uploaded. Link: {document.upload_link}")
    # Dump upload link and headers for external fetch checks
    try:
        upload_info = {
            "upload_link": document.upload_link,
            "upload_identifier": document.upload_identifier,
            "skill_headers": skill_headers
        }
        with open(r"C:\RE_SKILLS_IMPLEMENTATION\skill_upload_info.json", "w", encoding="utf-8") as fh:
            json.dump(upload_info, fh)
        print("[OK] Wrote upload info to C:\\RE_SKILLS_IMPLEMENTATION\\skill_upload_info.json")
    except Exception as e:
        print(f"[WARN] Could not write upload info: {e}")
    
    # 2. Create a session in the Gen AI Platform
    print("\nStep 2: Creating session in Gen AI Platform...")
    session_id = create_session(platform_base_url, ENV_DATA[CURR_ENV]["id"], skill_headers)

    # 2.5 Direct Skill Call (for debugging)
    print("\nStep 2.5: Calling Skill directly (bypass platform, using inline content)...")
    
    # Fetch content first so we can send it inline
    print("Fetching content from Search Platform for inline test...")
    try:
        # Use the uploader's session/headers to fetch the content
        # We need to use the same URL manipulation the skill does
        fetch_url = document.upload_link
        if "artifacts" not in fetch_url:
            fetch_url = fetch_url.replace("upload/", "upload/artifacts/")
        
        resp = requests.get(fetch_url, headers=skill_headers, timeout=30)
        if resp.status_code == 200:
            try:
                content = resp.json().get("documentXhtml", resp.text)
            except:
                content = resp.text
            print(f"[OK] Content fetched ({len(content)} bytes)")
        else:
            print(f"[WARN] Could not fetch content for inline test: {resp.status_code}")
            content = """<html>
  <head><title>PSA 10 - Test</title></head>
  <body>
    <h1>Test PSA Document</h1>
    <p>This is a Purchase and Sale Agreement (PSA) for a commercial property.</p>
    <p>The Purchase Price is $10,000,000.</p>
    <p>The Closing Date is December 31, 2025.</p>
    <p>The Seller is ABC Corp and the Buyer is XYZ LLC.</p>
  </body>
</html>"""
    except Exception as e:
        print(f"[WARN] Error fetching content: {e}")
        content = """<html>
  <head><title>PSA 10 - Test</title></head>
  <body>
    <h1>Test PSA Document</h1>
    <p>This is a Purchase and Sale Agreement (PSA) for a commercial property.</p>
    <p>The Purchase Price is $10,000,000.</p>
    <p>The Closing Date is December 31, 2025.</p>
    <p>The Seller is ABC Corp and the Buyer is XYZ LLC.</p>
  </body>
</html>"""

    skill_url = "http://localhost:8888/deal-points-extraction/extract/"
    skill_payload = {
        "user_id": ENV_DATA[CURR_ENV]["id"],
        "session_id": session_id,
        "message": "Perform the following skill service: Real Estate Deal Point Extraction",
        "streaming": False,
        "intent": "re_deal_point_extraction_skill",
        "headers": skill_headers,
        "docs": [
            {
                "document_display_name": document.document_display_name,
                "upload_identifier": document.upload_identifier,
                "content": content, # Send content INLINE
                "headers": skill_headers,
                "document_page_count": document.document_page_count,
                "document_character_count": document.document_character_count
            }
        ]
    }
    try:
        print("Sending request to skill...")
        skill_response = requests.post(skill_url, json=skill_payload, timeout=300)
        print(f"Skill Status Code: {skill_response.status_code}")
        if skill_response.status_code == 200:
            print("[OK] Skill responded successfully!")
            # print(json.dumps(skill_response.json(), indent=2))
        else:
            print(f"[ERROR] Skill failed: {skill_response.text}")
    except Exception as e:
        print(f"[ERROR] Could not reach skill: {e}")

    # 3. Call the Gen AI Platform with the upload_link
    # The platform will fetch the document and then call our skill
    print("\nStep 3: Calling Gen AI Platform orchestrator...")
    
    payload = {
        "user_id": ENV_DATA[CURR_ENV]["id"],
        "session_id": session_id,
        "message": "Perform the following skill service: Real Estate Deal Point Extraction",
        "streaming": True,
        "intent": "re_deal_point_extraction_skill",
        "headers": skill_headers,
        "docs": [
            {
                "document_display_name": document.document_display_name,
                "upload_identifier": document.upload_identifier,
                "upload_link": document.upload_link,
                "headers": skill_headers,
                "document_page_count": document.document_page_count,
                "document_character_count": document.document_character_count
            }
        ]
    }
    
    try:
        # Stream response like DueDiligence does
        with requests.Session() as session:
            with session.post(platform_stream_url, json=payload, headers=skill_headers, stream=True, timeout=300) as response:
                print(f"Status Code: {response.status_code}")
                
                if response.status_code == 200:
                    print("\n=== Streaming Response ===")
                    final_result = None
                    event_count = 0
                    for line in response.iter_lines():
                        if line:
                            line = line.decode("utf-8")
                            if line.startswith(": ping"):
                                continue
                            if line.startswith("data: "):
                                line = line[len("data: "):]
                            try:
                                draft_dict = json.loads(line)
                                event_type = draft_dict.get('detail-type', 'unknown')
                                event_count += 1
                                print(f"Event {event_count}: {event_type}")
                                
                                # Print ALL event details for debugging
                                print(f"  Full event: {json.dumps(draft_dict, indent=4)}")
                                
                                if event_type == "conversational-manager-message-finished":
                                    final_result = draft_dict
                                    print("\n[OK] Received final result!")
                                    break
                                elif event_type == "conversational-manager-message-exceptional":
                                    print(f"\n[ERROR] Exceptional event - processing failed")
                                    final_result = draft_dict
                                    break
                            except json.JSONDecodeError as e:
                                print(f"JSON decode error: {e}, line: {line[:100]}")
                                continue
                    
                    if final_result:
                        print("\n[OK] Test completed successfully!")
                        print(json.dumps(final_result, indent=2))
                    else:
                        print("\n[WARN] No final result received")
                else:
                    print(f"Error: {response.text}")
    except Exception as e:
        print(f"Exception occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_due_diligence_style_upload()
