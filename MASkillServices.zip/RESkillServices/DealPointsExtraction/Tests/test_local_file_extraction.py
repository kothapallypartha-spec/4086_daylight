import requests
import json
from pathlib import Path

def test_local_file_extraction():
    # Server URL
    url = "http://127.0.0.1:8888/deal-points-extraction/extract/"
    
    # Load the HTML file
    html_path = Path(__file__).parent / "psa_10.html"
    with open(html_path, "r", encoding="utf-8") as f:
        html_content = f.read()
    
    # Prepare payload
    payload = {
        "user_id": "test_user",
        "session_id": "test_session",
        "message": "Extract deal points from this document",
        "docs": [
            {
                "document_display_name": "psa_10.html",
                "content": html_content
            }
        ]
    }
    
    print(f"Sending request to {url}...")
    response = requests.post(url, json=payload)
    
    print(f"Status Code: {response.status_code}")
    if response.status_code == 200:
        result = response.json()
        print("Extraction successful!")
        # Print a summary of families found
        families = result.get("families", [])
        print(f"Found {len(families)} families.")
        for family in families:
            print(f"- {family.get('family_name')}: {len(family.get('deal_points', []))} deal points")
    else:
        print(f"Error: {response.text}")

if __name__ == "__main__":
    test_local_file_extraction()
