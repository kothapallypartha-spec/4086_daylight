import os

import pytest
import requests


def _join_url(base_url: str, path: str) -> str:
    base_url = (base_url or "").strip()
    path = (path or "").strip()
    if not base_url:
        return path
    if not path:
        return base_url
    return base_url.rstrip("/") + "/" + path.lstrip("/")


def _base_url_from_asset_group(asset_group: str) -> str:
    grp = (asset_group or "").strip()
    if not grp:
        return ""

    # Matches the convention used by other services' test helpers.
    if grp[0].lower() in {"d", "c"}:
        return f"https://{grp}-lplus-ai-services.route53.lexis.com"
    return f"https://{grp}-ai-plus-services.route53.lexis.com"


@pytest.mark.integration
def test_deployed_lambda_healthcheck():
    """Smoke test for the deployed ALB->Lambda.

    Opt-in: set `DEPLOYED_DEALPOINTS_BASE_URL` to your ALB base URL, e.g.
    `https://<alb-dns-name>.elb.amazonaws.com`.
    """

    base_url = os.environ.get("DEPLOYED_DEALPOINTS_BASE_URL")
    if not base_url:
        base_url = _base_url_from_asset_group(os.environ.get("DEPLOYED_ASSET_GROUP", ""))

    if not base_url:
        pytest.skip(
            "Set DEPLOYED_DEALPOINTS_BASE_URL (preferred) or DEPLOYED_ASSET_GROUP to run deployed Lambda smoke test"
        )

    health_path = os.environ.get("DEPLOYED_DEALPOINTS_HEALTHCHECK_PATH", "/deal-points-extraction/healthcheck")
    timeout_seconds = float(os.environ.get("DEPLOYED_TIMEOUT_SECONDS", "15"))
    verify_tls = os.environ.get("DEPLOYED_VERIFY_TLS", "1") not in {"0", "false", "False", "no", "NO"}

    url = _join_url(base_url, health_path)
    resp = requests.get(url, timeout=timeout_seconds, verify=verify_tls)
    assert resp.status_code == 200, f"Unexpected status {resp.status_code}: {resp.text[:500]}"

    data = resp.json()
    assert data.get("status") == "healthy"
