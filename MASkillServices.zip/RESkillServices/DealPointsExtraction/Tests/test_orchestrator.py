"""
Unit tests for Orchestrator.

Tests the multi-family orchestration logic including:
- Family processor creation
- Parallel execution
- Error handling across families
- Response aggregation
- Token tracking
"""

import json
import pytest
from unittest.mock import Mock, AsyncMock, patch
from Lambda.core.orchestrator import Orchestrator


class TestOrchestrator:
    """Test suite for Orchestrator class."""

    @pytest.fixture
    def sample_chunks(self):
        """Sample XHTML chunks for testing."""
        return [
            {"xpath": "/html/body/p[1]", "text": "Sample text 1", "seq_id": 1},
            {"xpath": "/html/body/p[2]", "text": "Sample text 2", "seq_id": 2},
        ]

    def test_init_default_families(self):
        """Test that all enabled families are loaded by default."""
        orchestrator = Orchestrator()
        
        # Should have all 5 enabled families
        assert len(orchestrator.family_entries) == 5
        assert "family_1" in orchestrator.family_entries
        assert "family_5" in orchestrator.family_entries

    def test_init_specific_families(self):
        """Test initialization with specific family subset."""
        orchestrator = Orchestrator(
            family_names=["family_1", "family_2"],
        )
        
        assert len(orchestrator.family_entries) == 2
        assert "family_1" in orchestrator.family_entries
        assert "family_2" in orchestrator.family_entries
        assert "family_3" not in orchestrator.family_entries

    def test_init_with_model_name(self):
        """Test initialization with custom model name."""
        orchestrator = Orchestrator(
            model_name="custom_model",
        )
        
        assert orchestrator.model_name == "custom_model"

    @pytest.mark.asyncio
    async def test_process_document_all_families(self, sample_chunks):
        """Test processing document with all families."""
        orchestrator = Orchestrator()
        
        result = await orchestrator.process_document(
            xhtml_chunks=sample_chunks,
            upload_identifier="test-123",
            document_name="test.html",
        )
        
        # New structure: flat deal_points dict, not families array
        assert "deal_points" in result
        assert "tokens" in result
        # Note: token families may be empty in stub/unit test mode

    @pytest.mark.asyncio
    async def test_process_document_single_family(self, sample_chunks):
        """Test processing with single family."""
        orchestrator = Orchestrator(
            family_names=["family_1"],
        )
        
        result = await orchestrator.process_document(
            xhtml_chunks=sample_chunks,
            upload_identifier="test-123",
            document_name="test.html",
        )
        
        # New structure: flat deal_points dict
        assert "deal_points" in result
        assert "tokens" in result
        # Note: token families may be empty in stub/unit test mode

    @pytest.mark.asyncio
    async def test_process_handles_family_failure(self, sample_chunks):
        """Test that orchestrator handles individual family failures gracefully."""
        orchestrator = Orchestrator(
            family_names=["family_1", "family_2"],
        )
        
        result = await orchestrator.process_document(
            xhtml_chunks=sample_chunks,
            upload_identifier="test-123",
            document_name="test.html",
        )
        
        # New structure: may have failed_families key if failures occurred
        assert "deal_points" in result
        assert "tokens" in result
        # Note: token families may be empty in stub/unit test mode

    @pytest.mark.asyncio
    async def test_process_aggregates_tokens(self, sample_chunks, monkeypatch):
        """Test that token usage is aggregated correctly."""
        # Set mock tenant key to prevent AWS Secrets Manager lookup
        monkeypatch.setenv("LLM_PROXY_TENANT", "test-tenant-key")
        
        # Mock extract_document to return family-specific data
        def mock_extract_side_effect(*, document_name, rows, family_name, model_name):
            # Return different mock data based on family
            family_data_map = {
                "family_1": {
                    "purchase_price_and_payment_method": {},
                    "earnest_money": {},
                    "closing_adjustments": {},
                    "closing_costs": {},
                    "brokerage_commissions": {}
                },
                "family_2": {
                    "access_and_inspection": {},
                    "title": {},
                    "survey": {},
                    "environmental_assessments": {}
                }
            }
            mock_evidence = {
                "document_name": document_name,
                "deal_points": family_data_map.get(family_name, {})
            }
            mock_usage = {"input_tokens": 200, "output_tokens": 100, "total_tokens": 300}
            return (mock_evidence, mock_usage)
        
        # Mock the LLM proxy client to prevent real API calls
        # Return family-specific summary structures
        family_summaries = {
            "family_1": {
                "document_name": "test.html",
                "deal_points": {
                    "purchase_price_and_payment_method": {},
                    "earnest_money": {},
                    "closing_adjustments": {},
                    "closing_costs": {},
                    "brokerage_commissions": {}
                }
            },
            "family_2": {
                "document_name": "test.html",
                "deal_points": {
                    "access_and_inspection": {},
                    "title": {},
                    "survey": {},
                    "environmental_assessments": {}
                }
            }
        }
        call_count = [0]
        families = ["family_1", "family_2"]
        
        def mock_chat_response(*args, **kwargs):
            family_key = families[call_count[0] % 2]
            call_count[0] += 1
            return json.dumps(family_summaries[family_key])
        
        mock_llm_client = Mock()
        mock_llm_client.chat = Mock(side_effect=mock_chat_response)
        
        with patch("Lambda.core.evidence_extractor.extract_document", new_callable=AsyncMock) as mock_extract, \
             patch("Lambda.llm.client.create_simple_proxy", return_value=mock_llm_client):
            mock_extract.side_effect = mock_extract_side_effect

            orchestrator = Orchestrator(
                family_names=["family_1", "family_2"],
            )

            result = await orchestrator.process_document(
                xhtml_chunks=sample_chunks,
                upload_identifier="test-123",
                document_name="test.html",
            )
            
            tokens = result["tokens"]
            assert "family_1" in tokens["families"]
            assert "family_2" in tokens["families"]
            assert "evidence" in tokens["families"]["family_1"]

    @pytest.mark.asyncio
    async def test_parallel_execution(self, sample_chunks, monkeypatch):
        """Test that families are processed in parallel."""
        import time
        from Lambda.llm.client import LLMClient
        from Lambda.core.summarizer import Summarizer
        
        # Set mock tenant key to prevent AWS Secrets Manager lookup
        monkeypatch.setenv("LLM_PROXY_TENANT", "test-tenant-key")
        
        # Mock LLMClient.chat_with_usage to return immediately with stub data
        # This is used by Stage 1 (evidence extraction)
        mock_parsed = Mock()
        mock_parsed.model_dump.return_value = {"deal_points": {}}
        
        # Mock Summarizer.summarize to return immediately
        # This is used by Stage 2 (summarization)
        async def mock_summarize(*args, **kwargs):
            return {"deal_points": {}}
            
        with patch.object(LLMClient, 'chat_with_usage', return_value=(mock_parsed, {"total_tokens": 100})):
            with patch.object(Summarizer, 'summarize', side_effect=mock_summarize):
                orchestrator = Orchestrator(
                    family_names=["family_1", "family_2", "family_3"],
                )
                
                start_time = time.time()
                await orchestrator.process_document(
                    xhtml_chunks=sample_chunks,
                    upload_identifier="test-123",
                    document_name="test.html",
                )
                elapsed = time.time() - start_time
                
                # With parallel execution and mocked LLM, should be very fast
                assert elapsed < 1.0  # Should complete almost instantly with mocks

    @pytest.mark.asyncio
    async def test_process_preserves_family_order(self, sample_chunks):
        """Test that family results maintain consistent ordering."""
        orchestrator = Orchestrator(
            family_names=["family_3", "family_1", "family_2"],
        )
        
        result = await orchestrator.process_document(
            xhtml_chunks=sample_chunks,
            upload_identifier="test-123",
            document_name="test.html",
        )
        
        # New structure: flat deal_points dict, tokens have families
        assert "deal_points" in result
        assert "tokens" in result
        # Note: token families may be empty in stub/unit test mode

    @pytest.mark.asyncio
    async def test_empty_chunks_handling(self):
        """Test handling of empty document chunks."""
        orchestrator = Orchestrator(
            family_names=["family_1"],
        )
        
        result = await orchestrator.process_document(
            xhtml_chunks=[],
            upload_identifier="test-123",
            document_name="empty.html",
        )
        
        # New structure: flat deal_points dict
        assert "deal_points" in result
        assert "tokens" in result
        # Should still return results even with empty chunks

    @pytest.mark.asyncio
    async def test_aggregator_integration(self, sample_chunks):
        """Test that ResponseAggregator is called correctly."""
        orchestrator = Orchestrator(
            family_names=["family_1"],
        )
        
        result = await orchestrator.process_document(
            xhtml_chunks=sample_chunks,
            upload_identifier="test-123",
            document_name="test.html",
        )
        
        # Check aggregated response structure - new flat deal_points dict
        assert "deal_points" in result
        assert "tokens" in result
        assert isinstance(result["deal_points"], dict)  # Flat dict, not array
        assert isinstance(result["tokens"], dict)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

