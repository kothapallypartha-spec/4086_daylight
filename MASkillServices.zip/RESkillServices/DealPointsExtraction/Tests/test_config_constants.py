"""
Test that configuration constants are properly used and fallback messages work.
"""
import sys
import os

# Set up path
# Navigate from tests -> DealPointsExtraction/Source
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "Source"))

from Lambda.config.constants import (
    DEFAULT_MODEL_NAME,
    DEFAULT_MAX_TOKENS,
    DEFAULT_LLM_TIMEOUT,
    DEFAULT_LLM_RETRY,
    FALLBACK_NOT_FOUND,
    SENTENCE_LIMIT_EARNEST_MONEY,
)
from Lambda.llm.client import LLMClient
from Lambda.core.orchestrator import Orchestrator
from Lambda.models.summary.base_summary import BaseSummaryDealPoint


def test_constants_imported():
    """Test that all constants are properly defined."""
    assert DEFAULT_MODEL_NAME == "OpenAI_gpt-5.1-2025-11-13_Daylight-RE_nonprod"
    assert DEFAULT_MAX_TOKENS == 32000
    assert DEFAULT_LLM_TIMEOUT == 420
    assert DEFAULT_LLM_RETRY == 3
    assert FALLBACK_NOT_FOUND == "Information not available in the reviewed document."
    assert SENTENCE_LIMIT_EARNEST_MONEY == 3
    print("✅ All constants properly defined")


def test_llm_client_uses_constants():
    """Test that LLMClient uses constants from config."""
    client = LLMClient(model_name=DEFAULT_MODEL_NAME)
    assert client._max_tokens == DEFAULT_MAX_TOKENS
    assert client._retry == DEFAULT_LLM_RETRY
    assert client._timeout == DEFAULT_LLM_TIMEOUT
    print("✅ LLMClient uses constants correctly")


def test_orchestrator_uses_default_model():
    """Test that Orchestrator uses DEFAULT_MODEL_NAME."""
    orchestrator = Orchestrator()
    assert orchestrator.model_name == DEFAULT_MODEL_NAME
    print("✅ Orchestrator uses DEFAULT_MODEL_NAME")


def test_fallback_message_validator():
    """Test that BaseSummaryDealPoint adds fallback messages."""
    # Create a mock deal point with source_texts but NULL combined_summary
    # Note: The validator checks source_texts, not seq_ids (seq_ids are only in evidence stage)
    class TestDealPoint(BaseSummaryDealPoint):
        combined_summary_test: str | None = None
    
    # Case 1: Has source_texts but NULL combined_summary → should add fallback
    dp1 = TestDealPoint(
        source_texts=["Some evidence text"],
        combined_summary_test=None
    )
    assert dp1.combined_summary_test == FALLBACK_NOT_FOUND
    print("✅ Fallback message added when evidence exists but summary is NULL")
    
    # Case 2: No source_texts and NULL combined_summary → should stay NULL
    dp2 = TestDealPoint(
        source_texts=None,
        combined_summary_test=None
    )
    assert dp2.combined_summary_test is None
    print("✅ No fallback when no evidence exists")
    
    # Case 3: Has combined_summary → should not change
    dp3 = TestDealPoint(
        source_texts=["Some evidence"],
        combined_summary_test="Actual summary"
    )
    assert dp3.combined_summary_test == "Actual summary"
    print("✅ Existing summary preserved")


if __name__ == "__main__":
    print("\n" + "="*80)
    print("TESTING CONFIGURATION CONSTANTS AND FALLBACK MESSAGES")
    print("="*80 + "\n")
    
    test_constants_imported()
    test_llm_client_uses_constants()
    test_orchestrator_uses_default_model()
    test_fallback_message_validator()
    
    print("\n" + "="*80)
    print("✅ ALL TESTS PASSED - Configuration constants working correctly!")
    print("="*80 + "\n")
