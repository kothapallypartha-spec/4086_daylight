import requests
import json
import os

def test_vault_enrichment():
    # The endpoint for deal points extraction
    url = "http://localhost:8888/deal-points-extraction/extract/"
    
    # The input provided by the user (simulating the Gen AI platform output)
    vault_data = {
      "detail-type": "conversational-manager-message-finished",
      "utc_timestamp": 1765221509.948,
      "detail": {
        "type": "Skills",
        "message": "{\"content\": \"[widget:80477548-8726-4913-95eb-b330809666d4]\", \"widget_data\": {\"80477548-8726-4913-95eb-b330809666d4\": {\"widget_type\": \"re_deal_point_extraction_skill\", \"data\": [{\"deal_point_name\": \"Purchase Price & Method of Payment\", \"summary\": \"The purchase price is $2,100,000, payable by Buyer to Seller at Closing via wire transfer of immediately available funds.\", \"anchor_key\": \"pid-00001\"}, {\"deal_point_name\": \"Earnest Money\", \"summary\": \"Buyer must deposit $100,000 earnest money by wire within three business days of the Effective Date; if not timely deposited, Seller may terminate and refund any amount deposited. The earnest money is non-refundable except as provided in Paragraph 17 and is held in a non-interest bearing account and disbursed per the agreement.\", \"anchor_key\": \"pid-00002\"}, {\"deal_point_name\": \"Closing Adjustments (Prorations)\", \"summary\": \"Ad valorem taxes and assessments for the closing year are prorated as of the Closing Date based on the most recent tax bill. Refunds of taxes after Closing are allocated between Seller and Buyer according to their respective periods. Any net balance from apportionments is settled at Closing, and Buyer is responsible for additional taxes due to changes in assessment from ownership or use.\", \"anchor_key\": \"pid-00003\"}, {\"deal_point_name\": \"Closing Costs (Allocation)\", \"summary\": \"Buyer pays for its inspections, survey, appraisals, environmental and geotechnical reports, deed recording, and deed or transfer taxes. Seller and Buyer split the costs for the Title Commitment, related search and copying, and Owner's Title Policy. Buyer pays for title endorsements and any Mortgagee's Title Policy.\", \"anchor_key\": \"pid-00004\"}, {\"deal_point_name\": \"Broker and Commission\", \"summary\": \"Both parties represent they have not used any broker or sales agent and agree to indemnify each other against any claims for brokerage commissions or similar fees. These obligations survive Closing and termination.\", \"anchor_key\": \"pid-00005\"}, {\"deal_point_name\": \"Access and Inspection\", \"summary\": \"Buyer has already been given the right to inspect the Property and is responsible for all costs related to prior inspections, surveys, appraisals, environmental audits, and geotechnical surveys. Within ten business days after the Effective Date, Seller must provide Buyer with any available recent surveys and environmental or engineering reports in Seller's possession. No seller duties, seller rights, or buyer termination terms are specified.\", \"anchor_key\": \"pid-00006\"}, {\"deal_point_name\": \"Title\", \"summary\": \"Seller must provide Buyer with a title insurance commitment and related documents within twenty days of the Effective Date. If the commitment reveals liens or judgments against similarly named parties, Seller must provide affidavits confirming these are not against Seller. Seller is only required to clear title exceptions that are existing mortgages, liens, or encumbrances created by Seller and removable by payment; other exceptions remain permitted.\", \"anchor_key\": \"pid-00007\"}, {\"deal_point_name\": \"Survey\", \"summary\": \"Buyer may obtain a survey of the Property at its own expense. Buyer is responsible for all costs related to the survey. Any encroachments, overlaps, boundary disputes, or other issues revealed by the survey or inspection, as well as standard title exceptions and matters in the Deed or public record, are addressed as survey defects.\", \"anchor_key\": \"pid-00008\"}, {\"deal_point_name\": \"Environmental Assessments\", \"summary\": \"Buyer has conducted or had the opportunity to conduct environmental site assessments and other investigations of the Property. Buyer and its successors are solely responsible for all costs and must indemnify Seller and related parties against any damages, liabilities, or expenses arising from the physical or environmental condition of the Property, including issues related to hazardous substances.\", \"anchor_key\": \"pid-00009\"}, {\"deal_point_name\": \"Closing (Date, Place, Mechanics)\", \"summary\": \"The closing is scheduled to occur at 10:00 a.m. Birmingham, Alabama time, on September 7, 2022, or on another date mutually agreed upon in writing by the parties. The location for closing is the offices of the Title Company, unless the parties agree in writing to an alternative venue. The date on which the closing actually occurs is defined as the 'Closing Date,' and time is expressly made of the essence with respect to this date.\", \"anchor_key\": \"pid-00010\"}, {\"deal_point_name\": \"Proceedings at Closing (Deliverables)\", \"summary\": \"At closing, each Seller is required to deliver to the Buyer a deed (in the form of Exhibit C) conveying the Seller's portion of the property, subject to permitted encumbrances, along with a lien waiver and possession affidavit (Exhibit D), a FIRPTA certificate of non-foreign status (Exhibit E), a closing statement, documentation evidencing the authority of the signatory, an IRS Form 1099-S information reporting form, an affidavit regarding Alabama residency or exemption (Exhibit F), a broker's lien affidavit (Exhibit G), a real estate sales validation acceptable to the Title Company, and any additional documents the Title Company may reasonably require to evidence the transfer.\", \"anchor_key\": \"pid-00011\"}, {\"deal_point_name\": \"Conditions to Closing (Buyer/Seller)\", \"summary\": \"No relevant provisions identified.\", \"anchor_key\": \"\"}, {\"deal_point_name\": \"Possession at Closing\", \"summary\": \"Possession of the property is to be delivered by the Seller to the Buyer on the Closing Date. No additional terms regarding the condition of the property at possession, post-closing occupancy, or early access are specified in the provided evidence.\", \"anchor_key\": \"pid-00013\"}, {\"deal_point_name\": \"Affirmative Covenants\", \"summary\": \"Seller covenants to avoid active or intentional waste and not to alter the condition or appearance of the Property, or convey any rights in the Property, without Buyer's written consent from signing until Closing. Seller must notify Buyer of any material damage, destruction, or eminent domain proceedings affecting the Property prior to Closing, with either party having the right to terminate the Agreement in such events.\", \"anchor_key\": \"pid-00014\"}, {\"deal_point_name\": \"Seller Warranties / Representations / Covenants\", \"summary\": \"Seller represents that neither party has used a broker or sales agent in the transaction, and covenants to deliver good and marketable fee simple title to the Property by Statutory Warranty Deed, subject only to specified permitted encumbrances. At Closing, Seller will provide all required documents, including title, affidavits, certifications, and tax compliance forms, as well as any additional documentation reasonably required by the Title Company.\", \"anchor_key\": \"pid-00015\"}, {\"deal_point_name\": \"Buyer Warranties / Representations / Covenants\", \"summary\": \"Buyer represents that neither party has engaged a broker or sales agent in connection with the transaction, and agrees to cooperate with Seller in facilitating a Section 1031 like-kind exchange, including executing any reasonably requested documents necessary to effect such exchange for Seller's benefit.\", \"anchor_key\": \"pid-00016\"}, {\"deal_point_name\": \"Remedies (Default)\", \"summary\": \"If Buyer defaults, Seller may terminate the agreement and keep the Earnest Money as its sole remedy. If Seller defaults (other than due to Buyer default), Buyer may either terminate and recover the Earnest Money or seek specific performance. Neither party may seek monetary damages except for indemnification obligations, and both waive claims for consequential, special, punitive, or exemplary damages.\", \"anchor_key\": \"pid-00017\"}, {\"deal_point_name\": \"Risk of Loss & Insurance\", \"summary\": \"Seller bears the risk of loss or damage to the property until title is conveyed to Buyer. If the property is materially damaged or destroyed before closing, Seller must notify Buyer, and either party may terminate the agreement, with Seller refunding the Earnest Money. If neither party terminates, Seller assigns all insurance proceeds to Buyer. No pre-closing insurance maintenance obligations are specified.\", \"anchor_key\": \"pid-00018\"}, {\"deal_point_name\": \"Condemnation (Eminent Domain)\", \"summary\": \"If any part of the property is subject to a pending or contemplated eminent domain taking before closing, Seller must notify Buyer. Either party may terminate the agreement, and if so, Seller refunds the Earnest Money. If neither party terminates, Seller assigns all condemnation awards to Buyer. No distinction is made between minor and major takings.\", \"anchor_key\": \"pid-00019\"}, {\"deal_point_name\": \"Indemnity\", \"summary\": \"Buyer must indemnify, defend, and hold Seller and related parties harmless from all losses and liabilities related to the physical or environmental condition of the property, including hazardous substances, and waives claims against Seller for such matters. Both Seller and Buyer agree to indemnify each other for any broker-related claims. Indemnity provisions survive closing and termination. No seller-to-buyer indemnity or access/inspection indemnity is specified.\", \"anchor_key\": \"pid-00020\"}]}}}",
        "mappings": {
          "pid-00001": [{"xpaths": ["//p[20]"], "offsets": [[0, 1000]]}],
          "pid-00002": [{"xpaths": ["//p[22]"], "offsets": [[0, 1000]]}]
        },
        "session_id": "8d552955-a225-4a90-ad3c-b7768cdd740a",
        "user_id": "urn:user:CB204094827"
      }
    }

    vault_config = [
        {
            "type": "dbotf",
            "content_type": "",
            "document_type_filter": [],
            "corpus": [
                "bc542a55-7225-4103-a0d9-3e5693ac93e6/b66175c3-68ac-4e63-ba71-223a6dc1d11b/aa7d3a04-83fe-4264-9128-7741d129a56f"
                ],
            "documents": [
                "9d45121e-802a-4dfc-b112-b9412a2ff770"
                ],
            "vault_public_id": "d5b38771-f3f1-4d89-8623-1fe1dfe1fbd2",
            "subvault_public_id": ""
            }
        ]

    # Extract the actual deal points from the nested message string
    message_json = json.loads(vault_data["detail"]["message"])
    widget_id = list(message_json["widget_data"].keys())[0]
    extracted_deal_points = message_json["widget_data"][widget_id]["data"]
    
    print(f"Simulating post-processing for {len(extracted_deal_points)} deal points...")
    
    # Example Post-Processing: Filter for specific deal points or format them
    processed_results = []
    for dp in extracted_deal_points:
        if dp["anchor_key"]: # Only keep those with anchors
            processed_results.append({
                "name": dp["deal_point_name"],
                "summary": dp["summary"],
                "anchor": dp["anchor_key"]
            })
            
    print(f"Post-processed {len(processed_results)} valid deal points.")
    
    # Now call the actual service with the HTML to see if it produces similar results
    html_path = r"C:\RE_SKILLS_IMPLEMENTATION\4086-daylight-skill-services\RESkillServices\DealPointsExtraction\Tests\psa_10.html"
    with open(html_path, "r", encoding="utf-8") as f:
        html_content = f.read()
        
    payload = {
        "user_id": vault_data["detail"]["user_id"],
        "session_id": vault_data["detail"]["session_id"],
        "message": "Extract deal points from this document",
        "intent": "re_deal_point_extraction_skill",
        "vault_config": vault_config,
        "docs": [
            {
                "document_display_name": "psa_10.html",
                "upload_identifier": "test-upload-id",
                "content": html_content
            }
        ]
    }
    
    print(f"Calling service at {url}...")
    try:
        response = requests.post(url, json=payload, timeout=600)
        if response.status_code == 200:
            service_result = response.json()
            print("Service call successful.")
            
            # Compare or enrich
            print("\n--- Comparison ---")
            print(f"Vault Deal Points: {len(processed_results)}")
            print(f"Service Deal Points: {len(service_result.get('deal_points', []))}")
            
            with open("vault_test_results.json", "w") as f:
                json.dump({
                    "vault_config": vault_config,
                    "vault_processed": processed_results,
                    "service_output": service_result
                }, f, indent=2)
            print("\nResults saved to vault_test_results.json")
        else:
            print(f"Service Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Failed to call service: {e}")

if __name__ == "__main__":
    test_vault_enrichment()
