"""
Unit test to isolate the LLM client Pydantic parsing bug.

This test directly tests the chat_parse method to see where the string->object conversion fails.
"""
from __future__ import annotations

import pytest
import json
from pydantic import BaseModel
from typing import List


class MockDealPoint(BaseModel):
    """Simple test Pydantic model"""
    name: str
    value: str
    sources: List[str] = []


class MockEvidenceDocument(BaseModel):
    """Mock evidence document for testing"""
    document_name: str
    deal_points: dict[str, MockDealPoint]


@pytest.fixture
def mock_llm_json_response() -> str:
    """Valid JSON that LLM would return"""
    return json.dumps({
        "document_name": "test.html",
        "deal_points": {
            "purchase_price": {
                "name": "Purchase Price",
                "value": "$1,000,000",
                "sources": ["Section 2.1", "Section 3.4"]
            },
            "closing_date": {
                "name": "Closing Date",
                "value": "December 31, 2025",
                "sources": ["Section 5.1"]
            }
        }
    })


class TestLLMClientParsing:
    """Test suite to isolate Pydantic parsing issue in LLM client"""
    
    def test_pydantic_model_validate_json_directly(self, mock_llm_json_response: str):
        """Test that Pydantic can parse the JSON string directly"""
        print(f"\n[TEST 1] Testing Pydantic model_validate_json directly")
        print(f"JSON length: {len(mock_llm_json_response)}")
        print(f"JSON preview: {mock_llm_json_response[:100]}")
        
        # This should work - Pydantic parsing JSON string
        parsed = MockEvidenceDocument.model_validate_json(mock_llm_json_response)
        
        print(f"Parsed type: {type(parsed)}")
        print(f"Is BaseModel: {isinstance(parsed, BaseModel)}")
        print(f"Document name: {parsed.document_name}")
        print(f"Deal points count: {len(parsed.deal_points)}")
        
        assert isinstance(parsed, MockEvidenceDocument)
        assert parsed.document_name == "test.html"
        assert len(parsed.deal_points) == 2
        assert "purchase_price" in parsed.deal_points
        
        print("[PASS] Direct Pydantic validation works")
    
    
    def test_pydantic_model_validate_with_dict(self, mock_llm_json_response: str):
        """Test Pydantic validation with pre-parsed dict"""
        print(f"\n[TEST 2] Testing Pydantic with pre-parsed dict")
        
        # Parse JSON to dict first
        data_dict = json.loads(mock_llm_json_response)
        print(f"Dict type: {type(data_dict)}")
        print(f"Dict keys: {list(data_dict.keys())}")
        
        # Validate from dict
        parsed = MockEvidenceDocument.model_validate(data_dict)
        
        print(f"Parsed type: {type(parsed)}")
        print(f"Document name: {parsed.document_name}")
        
        assert isinstance(parsed, MockEvidenceDocument)
        assert parsed.document_name == "test.html"
        
        print("[PASS] Pydantic validation from dict works")
    
    
    def test_pydantic_model_kwargs_unpacking(self, mock_llm_json_response: str):
        """Test Pydantic instantiation with **kwargs (like family_processor does)"""
        print(f"\n[TEST 3] Testing Pydantic with **kwargs unpacking")
        
        # Parse to dict
        data_dict = json.loads(mock_llm_json_response)
        
        # Instantiate with **kwargs (this is what family_processor line 81 does)
        parsed = MockEvidenceDocument(**data_dict)
        
        print(f"Parsed type: {type(parsed)}")
        print(f"Document name: {parsed.document_name}")
        
        assert isinstance(parsed, MockEvidenceDocument)
        assert parsed.document_name == "test.html"
        
        print("[PASS] Pydantic **kwargs unpacking works")
    
    
    def test_pydantic_fails_with_string_kwargs(self, mock_llm_json_response: str):
        """Test that Pydantic FAILS when given a string via **kwargs"""
        print(f"\n[TEST 4] Testing Pydantic failure with string in **kwargs")
        
        # This should FAIL - can't unpack a string
        with pytest.raises(TypeError) as exc_info:
            parsed = MockEvidenceDocument(**mock_llm_json_response)
        
        print(f"Expected error: {exc_info.value}")
        print("[PASS] Confirmed: **string fails as expected")
    
    
    def test_openai_like_chat_parse_simulation(self, mock_llm_json_response: str):
        """Simulate what OpenAI_Like.chat_parse does"""
        print(f"\n[TEST 5] Simulating OpenAI_Like.chat_parse flow")
        
        # Simulate llm_proxy returning a response dict
        mock_llm_response = {
            "choices": [{
                "message": {
                    "content": mock_llm_json_response,  # LLM returns JSON as string
                    "role": "assistant"
                }
            }],
            "usage": {
                "prompt_tokens": 100,
                "completion_tokens": 50,
                "total_tokens": 150
            }
        }
        
        # Extract content (this is what chat_parse does)
        raw_text = mock_llm_response["choices"][0]["message"]["content"]
        print(f"Extracted content type: {type(raw_text)}")
        print(f"Extracted content preview: {raw_text[:100]}")
        
        # Parse with Pydantic (this is line 232 in llm_proxy_openai.py)
        parsed_obj = MockEvidenceDocument.model_validate_json(raw_text)
        print(f"Parsed object type: {type(parsed_obj)}")
        print(f"Is Pydantic model: {isinstance(parsed_obj, BaseModel)}")
        
        # Package in response (simulate _to_response)
        from dataclasses import dataclass
        
        @dataclass
        class _Message:
            content: str
            parsed: MockEvidenceDocument
        
        @dataclass  
        class _Choice:
            message: _Message
        
        @dataclass
        class _ChatResponse:
            choices: List[_Choice]
        
        # This is what _to_response does on line 129
        msg = _Message(content=raw_text, parsed=parsed_obj)
        response = _ChatResponse(choices=[_Choice(message=msg)])
        
        # Access parsed (this is what client.py line 99 does)
        result = response.choices[0].message.parsed
        print(f"Accessed .parsed type: {type(result)}")
        print(f"Accessed .parsed value: {result.document_name}")
        
        assert isinstance(result, MockEvidenceDocument)
        assert result.document_name == "test.html"
        
        print("[PASS] Full flow simulation works correctly")
    
    
    def test_llm_client_integration(self, mock_llm_json_response: str, monkeypatch):
        """Test actual LLMClient.chat_with_usage with properly mocked llm_proxy"""
        print(f"\n[TEST 6] Testing real LLMClient with mock")
        
        from unittest.mock import Mock, patch
        from Lambda.llm.client import LLMClient
        
        # Set mock tenant key to prevent AWS Secrets Manager lookup
        monkeypatch.setenv("LLM_PROXY_TENANT", "test-tenant-key")
        
        # Mock the llm_proxy.create_simple_proxy function that LLMClient uses
        with patch('Lambda.llm.client.create_simple_proxy') as mock_create_proxy:
            # Create mock LLM instance that returns JSON string (like llm_proxy does)
            mock_llm = Mock()
            mock_llm.chat.return_value = mock_llm_json_response
            mock_create_proxy.return_value = mock_llm
            
            # Create real LLMClient and call it
            client = LLMClient(model_name="test-model")
            
            messages = [
                {"role": "system", "content": "You are a test assistant"},
                {"role": "user", "content": "Extract data"}
            ]
            
            result, usage = client.chat_with_usage(
                messages=messages,
                response_model=MockEvidenceDocument
            )
            
            print(f"Result type: {type(result)}")
            print(f"Result document_name: {result.document_name if hasattr(result, 'document_name') else 'N/A'}")
            print(f"Deal points: {list(result.deal_points.keys()) if hasattr(result, 'deal_points') else 'N/A'}")
            print(f"Usage: {usage}")
            
            # Verify that LLMClient properly parsed the JSON string into Pydantic object
            assert isinstance(result, MockEvidenceDocument), f"Expected MockEvidenceDocument, got {type(result)}"
            assert result.document_name == "test.html"
            assert len(result.deal_points) == 2
            assert "purchase_price" in result.deal_points
            assert "closing_date" in result.deal_points
            
            # Verify deal point structure
            assert result.deal_points["purchase_price"].name == "Purchase Price"
            assert result.deal_points["purchase_price"].value == "$1,000,000"
            assert len(result.deal_points["purchase_price"].sources) == 2
            
            # Verify usage tracking (llm_proxy doesn't return usage, so it should be 0)
            assert "prompt_tokens" in usage
            assert "completion_tokens" in usage
            assert "total_tokens" in usage
            
            print("[PASS] LLMClient integration test - successfully parsed JSON to Pydantic object")
    
    
    def test_json_validator_repair_control_chars(self):
        """Test that JSONValidator repairs unescaped control characters."""
        from Lambda.preprocessing.json_validator import JSONValidator
        
        # JSON with unescaped newline inside a string (invalid JSON)
        malformed_json = '{"text": "Line 1\nLine 2"}'
        
        # Standard json.loads should fail
        with pytest.raises(json.JSONDecodeError):
            json.loads(malformed_json)
            
        # JSONValidator should repair it
        repaired = JSONValidator.validate_and_repair(malformed_json)
        assert repaired is not None
        assert repaired["text"] == "Line 1\\nLine 2" or repaired["text"] == "Line 1\nLine 2"
        # Note: Depending on implementation, it might escape it or just make it valid
    
    
    def test_json_validator_repair_incomplete(self):
        """Test that JSONValidator repairs incomplete JSON."""
        from Lambda.preprocessing.json_validator import JSONValidator
        
        # Incomplete JSON (missing closing braces)
        incomplete_json = '{"a": {"b": 1'
        
        repaired = JSONValidator.validate_and_repair(incomplete_json)
        assert repaired is not None
        assert repaired["a"]["b"] == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
