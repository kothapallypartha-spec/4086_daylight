"""
Pydantic data models for the Clause Skill API with request/response validation.
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field, HttpUrl, field_validator, model_validator
from traceback import format_stack


class Headers(BaseModel):
    ContentType: str = Field("application/json", description="Content type of the response.", alias="Content-Type")
    AccessControlAllowOrigin: str = Field("*", description="CORS header to allow all origins.", alias="Access-Control-Allow-Origin")
    AccessControlAllowMethods: str = Field("OPTIONS,POST", description="CORS header to allow specific methods.", alias="Access-Control-Allow-Methods")
    AccessControlAllowHeaders: str = Field("*", description="CORS header to allow all headers.", alias="Access-Control-Allow-Headers")

    # Custom __init__ added to address Pylance type-checking issues, otherwise VSCode shows errors
    def __init__(self, **data):
        super().__init__(**data)


class ErrorResponse(BaseModel):
    body: str = Field(..., description="Error message")
    headers: Headers = Field(default_factory=lambda: Headers(), description="HTTP headers for the response.")
    traceback: str = Field(..., description="Traceback of the error")
    statusCode: int = Field(500, description="HTTP status code")

    # Custom __init__ added to address Pylance type-checking issues, otherwise VSCode shows errors
    def __init__(self, body: str, traceback: str | None = None, **data):
        if traceback is None:
            traceback = "".join(format_stack())
        super().__init__(body=body, traceback=traceback, **data)

    @classmethod
    def from_exception(cls, e: Exception, statusCode=500) -> "ErrorResponse":
        import traceback
        tb = traceback.format_exception(type(e), e, e.__traceback__)
        return cls(body=str(e), traceback="".join(tb), statusCode=statusCode)

    @classmethod
    def from_error_message(cls, error: str, statusCode: int = 500) -> "ErrorResponse":
        return cls(body=error, traceback="", statusCode=statusCode)


class ClauseSection(BaseModel):
    """Model for individual clause sections in the analysis output."""

    # Required fields
    title: str = Field(..., description="Section title")
    start_index: int = Field(..., ge=0, alias="startIndex", description="Start index in document")
    end_index: int = Field(..., ge=0, alias="endIndex", description="End index in document")
    clean_clause_text: str = Field(..., description="Cleaned clause text")
    document_title: str = Field(..., description="Document title")

    # Optional fields
    hierarchical_path: Optional[str] = Field(
        default=None, description="Hierarchical path of the section"
    )
    nesting_level: Optional[int] = Field(
        default=None, ge=0, description="Nesting level in document structure"
    )
    section_number: Optional[str] = Field(
        default=None, description="Section number if available"
    )
    type_name: Optional[str] = Field(default=None, description="Clause type name")
    type_id: Optional[int] = Field(default=None, ge=0, description="Clause type ID")
    level: Optional[int] = Field(default=None, ge=0, description="Section level")
    is_definition: Optional[bool] = Field(
        default=False, description="Whether this is a definition section"
    )
    parent_path: Optional[str] = Field(default=None, description="Parent section path")
    section_index_at_level: Optional[int] = Field(
        default=None, ge=0, description="Index at current level"
    )
    clause_xpath: Optional[str] = Field(
        default=None, description="XPath to the clause in HTML"
    )
    clause_text: Optional[str] = Field(default=None, description="Full clause text")
    source_file: Optional[str] = Field(default=None, description="Source filename")

    @model_validator(mode='before')
    @classmethod
    def validate_data(cls, data):
        v = data.get("clause_type") or data.get("typeName") or data.get("type_name")
        if v is not None:
            data["type_name"] = v
        v = data.get("typeID") or data.get("type_id")
        if v is not None:
            data["type_id"] = v
        return data

    @field_validator("end_index")
    @classmethod
    def validate_end_after_start(cls, v, info):
        start_index = info.data.get("start_index")
        if start_index is not None and v <= start_index:
            raise ValueError("End index must be greater than start index")
        return v

    @field_validator("clean_clause_text")
    @classmethod
    def validate_clean_text_not_empty(cls, v):
        if not v or not v.strip():
            raise ValueError("Clean clause text cannot be empty")
        return v

    @field_validator("clause_text")
    @classmethod
    def validate_clause_text_not_empty(cls, v):
        if v is not None and (not v or not v.strip()):
            raise ValueError("Clause text cannot be empty when provided")
        return v


class AnalysisResult(BaseModel):
    """Model for the complete analysis result."""

    success: bool = Field(..., description="Whether the analysis was successful")
    message: str = Field(..., description="Status message")
    sections: List[ClauseSection] = Field(
        default_factory=list, description="Analyzed clause sections"
    )
    total_sections: int = Field(..., ge=0, description="Total number of sections found")
    processing_time_ms: Optional[int] = Field(
        default=None, ge=0, description="Processing time in milliseconds"
    )
    document_info: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="Additional document metadata"
    )

    @model_validator(mode="before")
    @classmethod
    def set_total_sections(cls, values):
        if isinstance(values, dict) and "sections" in values:
            values["total_sections"] = len(values["sections"])
        return values

    @field_validator("sections")
    @classmethod
    def validate_sections_not_empty_on_success(cls, v, info):
        # For now allowing successful analysis with zero sections (e.g., after filtering). Need to check with product though.
        # The 'message' field can explain why no sections were found
        return v


# Request/Response Models for API
class AnalysisRequest(BaseModel):
    """Request model for document analysis."""
    url: HttpUrl = Field(..., description="Pre-signed URL to the document")
    model_name: str = Field(
        "anthropic-claude-3-7-sonnet-20250219_Daylight_3363_nonprod",
        description="The name of the model to use for processing"
    )
    filename_stem: str = Field(..., description="The document identifier (no file extension)")
    headers: dict | None = Field({}, description="Optional headers for HTTP requests")
    include_metadata: bool = Field(
        default=True, description="Whether to include document metadata"
    )
    filter_clause_types: Optional[List[str]] = Field(
        default=None, description="Filter by specific clause types"
    )
