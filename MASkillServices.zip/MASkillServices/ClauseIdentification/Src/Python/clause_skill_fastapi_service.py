from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import tempfile
import sys
import os
from pathlib import Path

# Add the src/python directory to the Python path
project_root = Path(
    __file__
).parent.parent  # Go up two levels: clause_skill -> python -> src
sys.path.insert(0, str(project_root))

# Import clause analysis functions
from data_models import ClauseSection
from clause_type_intelligize import (
    call_contract_analysis_api,
    process_api_response,
)

app = FastAPI(title="Clause Skill API", version="1.0.0")


# Pydantic Models
class HTMLAnalysisRequest(BaseModel):
    html_content: str


class AnalysisResponse(BaseModel):
    success: bool
    message: str
    sections: List[ClauseSection]
    total_sections: int


@app.post("/analyze-html", response_model=AnalysisResponse)
async def analyze_html_content(request: HTMLAnalysisRequest):
    """
    Analyze HTML content directly using the contract analysis API.
    """
    try:
        # Call the contract analysis API
        api_response, processed_documentxhtml = call_contract_analysis_api(
            request.html_content
        )

        if api_response is None:
            raise HTTPException(status_code=500, detail="Contract analysis API failed")

        # Process the API response
        sections = process_api_response(
            api_response, "direct_html_input", processed_documentxhtml
        )

        return AnalysisResponse(
            success=True,
            message="HTML content analyzed successfully",
            sections=sections,
            total_sections=len(sections),
        )

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error analyzing HTML content: {str(e)}"
        )


@app.post("/analyze-document", response_model=AnalysisResponse)
async def analyze_document(file: UploadFile = File(...)):
    """
    Analyze a document (PDF or DOCX) by first converting to HTML, then analyzing.
    """
    # Validate file type
    allowed_extensions = {".pdf", ".docx", ".doc"}
    filename = file.filename
    assert filename is not None
    safe_filename = Path(os.path.basename(filename)).name
    if not safe_filename or safe_filename in ('.', '..'):
        raise HTTPException(
            status_code=400,
            detail="Invalid filename"
        )
    file_extension = Path(safe_filename).suffix.lower()
    if file_extension not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type: {file_extension}. Supported types: {', '.join(allowed_extensions)}"
        )
    try:
        # Create temporary directory for processing
        with tempfile.TemporaryDirectory() as temp_dir:
            # Save uploaded file temporarily
            temp_file_path = os.path.join(temp_dir, safe_filename)
            with open(temp_file_path, "wb") as temp_file:
                content = await file.read()
                temp_file.write(content)

            # Read the converted HTML content
            with open(temp_file_path, "r", encoding="utf-8") as html_file:
                html_content = html_file.read()

            # Call the contract analysis API
            api_response, processed_documentxhtml = call_contract_analysis_api(
                html_content
            )

            if api_response is None:
                raise HTTPException(
                    status_code=500, detail="Contract analysis API failed"
                )

            # Process the API response
            sections = process_api_response(
                api_response, filename, processed_documentxhtml
            )

            return AnalysisResponse(
                success=True,
                message=f"Document {filename} analyzed successfully",
                sections=sections,
                total_sections=len(sections),
            )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error analyzing document: {str(e)}"
        )


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "Clause Skill API"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
