import re
import html
import logging
from lxml import etree  # type: ignore
from bs4 import BeautifulSoup  # type: ignore

logger = logging.getLogger()

def extract_xpath_for_text(html_content: str, start_index: int, end_index: int) -> str:
    """
    Simplified XPath extraction using the most effective strategy.

    Args:
        html_content (str): The HTML content to analyze
        start_index (int): Start character index of the target text
        end_index (int): End character index of the target text

    Returns:
        str: XPath or error message if extraction fails
    """
    if not html_content or start_index >= end_index:
        return "ERROR: Invalid input parameters"

    if BeautifulSoup is None or etree is None:
        return "ERROR: Required libraries not available (lxml, beautifulsoup4) for XPath extraction"

    # Get the target text content
    target_text = html_content[start_index:end_index].strip()
    if not target_text:
        return "ERROR: Empty target text"

    # Parse HTML with BeautifulSoup for robustness, then convert to lxml
    soup = BeautifulSoup(html_content, "html.parser")
    html_str = str(soup)

    # Parse with lxml etree for XPath functionality
    try:
        doc = etree.fromstring(html_str.encode("utf-8"), etree.HTMLParser())
    except Exception:
        try:
            # Clean up and try again if initial parsing fails
            html_str_fixed = re.sub(r"<\?xml[^>]*\?>", "", html_str)
            html_str_fixed = re.sub(r"<!DOCTYPE[^>]*>", "", html_str_fixed)
            doc = etree.fromstring(
                html_str_fixed.encode("utf-8"), etree.HTMLParser()
            )
        except Exception as e:
            return f"ERROR parsing HTML: {str(e)}"

    # Text normalization for better matching
    def normalize_text(text):
        if not text:
            return ""
        normalized = html.unescape(text)
        normalized = re.sub(r"\s+", " ", normalized).strip()
        return normalized

    # Simple text similarity calculation
    def text_similarity(text1, text2):
        if not text1 or not text2:
            return 0.0
        set1 = set(text1.lower().split())
        set2 = set(text2.lower().split())
        if not set1 or not set2:
            return 0.0
        intersection = len(set1 & set2)
        union = len(set1 | set2)
        return intersection / union if union > 0 else 0.0

    # XPath generation function
    def get_xpath(element):
        if element is None or element.tag is None:
            return ""

        path_parts = []
        current = element

        while current is not None and current.tag is not None:
            parent = current.getparent()
            if parent is not None:
                siblings = [child for child in parent if child.tag == current.tag]
                if len(siblings) > 1:
                    try:
                        position = siblings.index(current) + 1
                        path_parts.append(f"{current.tag}[{position}]")
                    except ValueError:
                        path_parts.append(current.tag)
                else:
                    path_parts.append(current.tag)
            else:
                path_parts.append(current.tag)
            current = parent

        path_parts.reverse()
        return "/" + "/".join(path_parts) if path_parts else ""

    target_clean = normalize_text(target_text)
    best_xpath = None
    best_score = 0.0

    # Strategy: Full element text content (including nested elements)
    all_elements = doc.xpath("//*")
    for element in all_elements:
        try:
            # Get full text content including nested elements
            element_full_text = etree.tostring(
                element, method="text", encoding="unicode"
            )
            element_full_text_clean = normalize_text(element_full_text)

            if not element_full_text_clean:
                continue

            # Check for exact match first
            if target_clean == element_full_text_clean:
                xpath = get_xpath(element)
                if xpath:
                    return xpath  # Return immediately on exact match

            # Check for high similarity
            similarity = text_similarity(target_clean, element_full_text_clean)

            # Only consider elements with reasonable similarity and length
            if (
                similarity > 0.7
                and len(element_full_text_clean) <= len(target_clean) * 3
            ):  # Avoid overly broad matches
                xpath = get_xpath(element)
                if xpath and similarity > best_score:
                    best_xpath = xpath
                    best_score = similarity

            # Also check if target is contained within element (for partial matches)
            elif (
                len(target_clean) > 10
                and target_clean in element_full_text_clean
                and len(element_full_text_clean) <= len(target_clean) * 2
            ):  # Stricter length check
                xpath = get_xpath(element)
                if xpath:
                    # Score based on length ratio to prefer more precise matches
                    length_ratio = len(target_clean) / len(element_full_text_clean)
                    adjusted_score = similarity * length_ratio
                    if adjusted_score > best_score:
                        best_xpath = xpath
                        best_score = adjusted_score

        except Exception:
            continue

    if (
        best_xpath and best_score > 0.5
    ):  # Only return if we have reasonable confidence
        return best_xpath
    else:
        return f"ERROR: Could not locate reliable XPath for text at positions {start_index}-{end_index}"


def filter_xml_tags(xml_text: str) -> str:
    no_tag_text = re.sub(r'<[^<]+>', lambda m: " " * len(m.group()), xml_text)
    return no_tag_text

def custom_tokenizer(sentence: str):
    tokenization_chars = set(re.sub(r"[\sA-Za-z0-9\u00C0-\u017F]+", "", sentence))
    if type(sentence) == float: return []
    if len(sentence) == 0: return []
    split_regex = r'|'.join(['(' + re.escape(x) + ')' for x in tokenization_chars])
    if split_regex:
        split_regex += '|'
    split_regex += '(\s+)'
    splits = re.split(split_regex, sentence)
    tokens = [y for y in splits if y and y.strip()]

    return tokens

def get_all_xpaths(html_content, filter_tag="//*"):
    """
    Extract non-overlapping (outermost) XPaths from an HTML document

    Args:
        html_content: HTML content as string

    Returns:
        List of non-overlapping XPaths
    """
    # Parse the HTML content
    parser = etree.HTMLParser()
    tree = etree.fromstring(html_content, parser)

    # Create ElementTree to use getpath
    tree_with_getpath = etree.ElementTree(tree)

    # Get all elements
    all_elements = tree.xpath(filter_tag)

    distinct_elements = []
    for element in all_elements:
        # Get the direct text content of this element (excluding child element text)
        element_text = ' '.join(element.itertext())

        if element_text.strip() and (element_text not in distinct_elements):
            distinct_elements.append((element_text, tree_with_getpath.getpath(element)))

    return distinct_elements

def match_clauses_to_xpaths(clauses, all_xpaths_info):
    for clause in clauses:
        overlapping = [
            x for x in all_xpaths_info
            if not (clause["endIndex"] < x[2] or clause["startIndex"] > x[3])
            ]
        if not overlapping:
            logger.warning(f"No matching XPath found for clause: {clause['textHead']}")
        clause["xpaths"] = [x[1] for x in overlapping]

def get_token_positions(tokens, text):
    alignments = []
    current_offset = 0
    for token in tokens:
        try:
            word_offset = text.index(token, current_offset)
            start_position = word_offset
            end_position = start_position + len(token) - 1
            alignments.append((token, start_position, end_position))
            current_offset = word_offset + len(token)
        except ValueError:
            continue
    return alignments

def get_start_end_positions(sentences, ref_sentence, ref_alignments=None):
    # First pass: Align ref_sentence with itself
    if not ref_alignments:
        ref_sentence_tokens = custom_tokenizer(ref_sentence)
        ref_alignments = get_token_positions(ref_sentence_tokens, ref_sentence)


    # Second pass: Iterate over sentence_tokens to pick the right slice from ref_alignments
    alignments = [None] * len(sentences)
    sub_alignments = []
    current_offset = 0
    previous_word_offset = -1
    previous_token = None
    ref_tokens = [t for t, _, _ in ref_alignments]

    for i, sentence in enumerate(sentences):
        last_sentence_start = len(sub_alignments)
        sentence_tokens = custom_tokenizer(sentence)

        for token in sentence_tokens:
            try:
                word_offset = ref_tokens.index(token, current_offset)

            except ValueError:
                word_offset = previous_word_offset + 1

            try:
                start_position = ref_alignments[word_offset][1]
            except Exception:
                start_position = ref_alignments[previous_word_offset + 1][1] if previous_word_offset + 1 < len(ref_alignments) else -1
            if token:
                sub_alignments.append((token, start_position, start_position + len(token) - 1, True))

            if (previous_token is not None) and word_offset - 1 == previous_word_offset:
                sub_alignments[-2] = (sub_alignments[-2][0], sub_alignments[-2][1], sub_alignments[-2][2], False)

            current_offset = word_offset + 1
            previous_word_offset = current_offset - 1
            previous_token = token

            if len(sentence.strip()) > 0:
                sub_alignments[-1] = (sub_alignments[-1][0], sub_alignments[-1][1], sub_alignments[-1][2], True)

        if sub_alignments[last_sentence_start][1] > sub_alignments[-1][2]:
            logger.warning("Something went wrong in alignment detection.")
        alignments[i] = (sub_alignments[last_sentence_start][1] if sub_alignments else -1, sub_alignments[-1][2] if sub_alignments else -1)

    return alignments


def deduce_matching_xpaths(html_content, clauses):

    #logger.info("Filtering XML tags from the content...")
    cleaned_content = filter_xml_tags(html_content)

    ref_sentence_tokens = custom_tokenizer(cleaned_content)
    ref_alignments = get_token_positions(ref_sentence_tokens, cleaned_content)

    all_xpaths = get_all_xpaths(html_content, filter_tag="/html/body//p | /html/body//ol")
    alignments = get_start_end_positions([text for text, _ in all_xpaths], cleaned_content, ref_alignments)
    match_clauses_to_xpaths(clauses, [(s, xpath, st, en) for (s, xpath), (st, en) in zip(all_xpaths, alignments)])
