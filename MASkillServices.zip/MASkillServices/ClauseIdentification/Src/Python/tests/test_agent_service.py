import json
import os
from pathlib import Path

import requests
from botocore.config import Config
import boto3

from sp_uploader import ENV_DATA, FileUploader


def create_session(agent_host, user_id):
    payload = {
        "user_id": user_id,
        "session_name": user_id,
        "client_id": "test",
        }
    payload = json.dumps(payload)
    headers = {"Content-Type": "application/json"}
    response = requests.request("POST", agent_host + "/api/v1/proxy/sessions", headers=headers, data=payload)
    session_id = response.json()["data"]["session_id"]
    print(f"Session ID: {session_id}")
    return session_id

def process_payload(agent_host, user_id, session_id, message, intent, documents, headers, highlighted_section=""):
    output_html_path = Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_output.html"


    payload = {
        "user_id": user_id,
        "session_id": session_id,
        "message": message,
        "streaming": True,
        "intent": intent,
        "headers": headers,
        }

    if documents:
        payload["docs"] = [
            {
                "document_display_name": document.document_display_name,
                "upload_identifier": document.upload_identifier,
                "upload_link": document.upload_link,
                "document_page_count": document.document_page_count,
                "document_character_count": document.document_character_count,
                }
            for document in documents
            ]

    if highlighted_section:
        payload["highlighted_section"] = highlighted_section

    payload = json.dumps(payload)
    with open(Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_request.json", "w") as f:
        f.write(payload)
    url = agent_host + "/api/v1/messages_stream"

    with requests.Session() as session:
        with session.post(url, headers=headers, data=payload, stream=True) as response:
            with open(output_html_path, "w", encoding="utf-8") as html_file:
                for line in response.iter_lines():
                    if line:  # filter out keep-alive new chunks
                        line = line.decode("utf-8")
                        if line.startswith(": ping"):
                            continue
                        line = line[len("data: ") :]
                        draft_dict = json.loads(line)
                        html_file.write(f"<p>{json.dumps(draft_dict)}</p>\n")
                        print(draft_dict)
                        if draft_dict["detail-type"] == "conversational-manager-message-finished":
                            return draft_dict

def main():
    CURR_ENV = "dev"
    user_id = ENV_DATA[CURR_ENV]["id"]
    agent_host = ENV_DATA[CURR_ENV]["url"]
    message = "Perform the following skill service: Issue Analysis"
    intent = "ma_clause_identification_skill"
    file_paths = [
        Path("/Users/elayadim/projects/llm/upload_analyze/data/transactional_silver_set/docx/A2-Stock Purchase Agreement_10-08-2021.docx"),
        Path("/Users/elayadim/projects/llm/upload_analyze/data/transactional_silver_set/docx/B3-Stock Purchase Agreement_10-07-2021.docx")
        ]
    # Create a session
    session_id = create_session(agent_host, user_id)

    # Upload the document
    uploader = FileUploader(CURR_ENV)
    documents = []
    for file_path in file_paths:
        document, headers = uploader.upload_file(file_path)
        document.upload_link = document.upload_link.replace("/docx", "/docxhtml")
        documents.append(document)
        print(document.upload_link)
    headers["x-ln-output-format"] = "json"


    output = process_payload(agent_host, user_id, session_id, message, intent, documents, headers, highlighted_section="")
    with open(Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_output.json", "w") as f:
        json.dump(output, f, indent=2)

    return output


if __name__ == "__main__":
    print(main())
