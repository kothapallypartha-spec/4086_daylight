import requests
import json
from pathlib import Path


def test_html_analysis():
    """Test the FastAPI service with HTML content."""

    # Read the HTML file
    html_file_path = (
        Path(__file__).parent
        / "data"
        / "First Modification to Business Financing Agreement Western Alliance Bank and ChromaDex.xhtml"
    )

    with open(html_file_path, "r", encoding="utf-8") as file:
        html_content = file.read()

    # API endpoint
    url = "http://localhost:8000/analyze-html"

    # Request payload
    payload = {"html_content": html_content}

    # Make the request
    print("Sending HTML content for analysis...")
    print(f"HTML content length: {len(html_content)} characters")

    try:
        response = requests.post(url, json=payload, timeout=900)

        if response.status_code == 200:
            result = response.json()
            print(f"\nSuccess! Analysis completed.")
            print(f"Total sections found: {result['total_sections']}")
            print(f"Message: {result['message']}")

            # Display first few sections as examples
            if result["sections"]:
                print(f"\nFirst 3 sections (out of {len(result['sections'])}):")
                for i, section in enumerate(result["sections"][:3]):
                    print(f"\n--- Section {i+1} ---")
                    print(f"Title: {section['title']}")
                    print(f"Type: {section['typeName']} (ID: {section['typeID']})")
                    print(f"Hierarchical Path: {section['hierarchical_path']}")
                    print(f"Nesting Level: {section['nesting_level']}")
                    print(f"Section Number: {section['sectionNumber']}")
                    print(
                        f"Clause Text (first 200 chars): {section['clause_text'][:200]}..."
                    )
                    print(
                        f"Clean Text (first 200 chars): {section['clean_clause_text'][:200]}..."
                    )

            # Save full response to file for inspection
            output_file = Path(__file__).parent / "output" / "html_analysis_result.json"
            output_file.parent.mkdir(exist_ok=True)

            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)

            print(f"\nFull results saved to: {output_file}")

        else:
            print(f"Error: {response.status_code}")
            print(f"Response: {response.text}")

    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")


if __name__ == "__main__":
    test_html_analysis()
