import base64
import json
import os
import time
import xml
from copy import copy
from pathlib import Path
from typing import Tuple, Optional, Dict
import xml.dom.minidom
import grequests

import requests
from lxml import etree
from pydantic import BaseModel
from botocore.config import Config
import boto3
from requests.auth import HTTPBasicAuth

PROD_URL = "https://agent-svc.us.3363-rag-us-prod.sk8s.aws.lexis.com"
STAGING_URL = "https://agent-svc.us.3363-rag-us-staging.sk8s.aws.lexis.com"
CERT_URL = "https://cert-agent-svc.rag-us.use1.dev-searchplatform.nl.lexis.com"
DEV_URL = "http://agent-svc.rag-us.use1.dev-searchplatform.nl.lexis.com"
LOCAL_URL = "http://127.0.0.1:8080"

VIEW_MORE = "https://agent-svc.rag.us.sk8s.aws.lexis.com/api/v1/proxy/documents/snippets?message_id=9b33a3ed-a5d0-4957-a735-c01f83a33101&content_type=analytical-materials&page=1&size=20"

ENV_DATA = {
    "prod": {"url": PROD_URL, "id": "urn:user:PA195739221", "asset_group": "pdc1c", "user": "protegeuser_1"},
    "staging": {"url": STAGING_URL, "id": "urn:user:PA195739219", "asset_group": "pdc2c", "user": "protegeuser_2"},
    "cert": {"url": CERT_URL, "id": "urn:user:CA200433345", "asset_group": "cdc1c", "user": "LPlusAI0"},  # LPlusAI0 - cert1
    "dev": {"url": DEV_URL, "id": "urn:user:CB204094827", "asset_group": "cdc7c", "user": "LPlusAI0"},  # LPlusAI0 - cert7
    "local": {"url": LOCAL_URL, "id": "urn:user:CB204094827", "asset_group": "cdc7c", "user": "LPlusAI0"}  # LPlusAI0 - cert7
    }
COMMOM_SERVER_ENDPOINT = "-i-services.route53.lexis.com"

LONG_HEADER = """<experimentList><experiment treatment="23fea810-0fca-42fa-b40e-240a257b6874" featEval="csr.ContentEntitlementsServicePeerUsed" featEvalComp="csr" featEvalName="ContentEntitlementsServicePeerUsed" featureEnabled="true" csrfeature="search">6fd35187-48c3-46bb-bf41-42742534ec1f</experiment><experiment treatment="0e2db336-1501-41ba-ba2d-8b92618c6e9d" featEval="searchresults.Docketstakedown" featEvalComp="searchresults" featEvalName="Docketstakedown" featureEnabled="true">ddba3c8d-24b4-459d-ba3a-2e7446a28b11</experiment><experiment treatment="12aa7ccd-3de5-4807-a7ad-7e9dc2f61703" featEval="csr.QuerySuggestion" featEvalComp="csr" featEvalName="QuerySuggestion" featureEnabled="true">92f9d508-0351-4d75-a22b-79616274ff99</experiment><experiment treatment="9032b829-70ba-4734-8a1f-64f2e3a062dc" featEval="csr.ContentEntitlementsProductRestrictions" featEvalComp="csr" featEvalName="ContentEntitlementsProductRestrictions" featureEnabled="true" csrfeature="search">82e04ba4-3831-4a8a-bc56-20d8e86df11f</experiment><experiment treatment="72b03f86-6475-48ea-a7c7-92d01460abcc" featEval="searchbox.Oldwordwheelstyle" featEvalComp="searchbox" featEvalName="Oldwordwheelstyle" featureEnabled="false">ca98e88c-57f0-46a9-87d9-59df2a4247d2</experiment><experiment treatment="ec401210-9d1b-47a6-8db0-972e8bdea3b5" featEval="navigation.Agentic Workflow 2.5" featEvalComp="navigation" featEvalName="Agentic Workflow 2.5" featureEnabled="true">545caa23-aab6-4054-bdfa-af3ed8c8598f</experiment><experiment treatment="b0b47f96-bb0a-437f-a523-e1c275185d42" featEval="navigation.Agentic Workflow V2" featEvalComp="navigation" featEvalName="Agentic Workflow V2" featureEnabled="true">8bd321b0-fa38-4829-b97f-ae2b9c14ed6c</experiment><experiment treatment="96a63b20-f5ee-4cf9-a18f-1d4c86d46409" featEval="aiassistant.ASK_LEGAL_NEWS" featEvalComp="aiassistant" featEvalName="ASK_LEGAL_NEWS" featureEnabled="true">aec5bd82-caaa-4c15-a894-11df1d0662a5</experiment><experiment treatment="cef8cfa2-a9bd-4d74-866e-c9b1cb863125" featEval="navigation.SSE" featEvalComp="navigation" featEvalName="SSE" featureEnabled="true">57eea710-1a58-4b32-acf7-c94e20715fe2</experiment><experiment treatment="4c3ea005-7986-4c72-89b4-249eede374c8" featEval="aiassistant.draftingriskmeter" featEvalComp="aiassistant" featEvalName="draftingriskmeter" featureEnabled="true">fd234ed5-1f7b-4950-af32-1b15ae1377f3</experiment><experiment treatment="71f47b26-fe98-4a8c-9ea3-0c38ebba934a" featEval="N/A.BACharacterCountIncrease" featEvalComp="N/A" featEvalName="BACharacterCountIncrease" featureEnabled="true">6d99dbcf-e834-4860-a5ab-76067e25f36e</experiment><experiment treatment="a254cb15-df76-41ad-8774-add52d3d99fb" featEval="briefanalyzerreport.BARedraftingArguments" featEvalComp="briefanalyzerreport" featEvalName="BARedraftingArguments" featureEnabled="false">56fde51e-12b4-469b-8128-c614662ab116</experiment><experiment treatment="314471d1-5e08-437f-85cb-bebeb91a48fc" featEval="navigation.SnapshotCasesEnabled" featEvalComp="navigation" featEvalName="SnapshotCasesEnabled" featureEnabled="true">4732270f-cbd2-4cd8-8822-c779926b0a3e</experiment><experiment treatment="c15dfb91-a66b-4156-b790-45782aa08e9c" featEval="aiassistant.ASK_50_STATES_DYNAMIC_COLUMNS" featEvalComp="aiassistant" featEvalName="ASK_50_STATES_DYNAMIC_COLUMNS" featureEnabled="true">f3d0edb5-9335-43aa-bf77-9ef0c6a56052</experiment><experiment treatment="bd5f1312-3da6-4963-b41c-109c283d7da8" featEval="aiassistant.EnableMATasks" featEvalComp="aiassistant" featEvalName="EnableMATasks" featureEnabled="true">aef6d189-d2b2-465d-97a8-a77696411ebf</experiment><experiment treatment="138e3e4a-9d2f-4c9a-b2e0-90095e03b430" featEval="navigation.IncludeStatutesAndAdminCodesInAuthoritySummaries" featEvalComp="navigation" featEvalName="IncludeStatutesAndAdminCodesInAuthoritySummaries" featureEnabled="true">cf9e8b74-4c80-46f7-ab4a-9728226f50fa</experiment><experiment treatment="39962973-e4a3-46ba-ab78-978581163e4c" featEval="navigation.NonStreamingSummarize" featEvalComp="navigation" featEvalName="NonStreamingSummarize" featureEnabled="false">f9a6587e-2657-4d0b-8694-8a9b0c35edab</experiment><experiment treatment="493ffbb9-9b09-489e-b631-82ead8f88384" featEval="aiassistant.ASK_RELEASE_HYPERLINKCITATIONS" featEvalComp="aiassistant" featEvalName="ASK_RELEASE_HYPERLINKCITATIONS" featureEnabled="true">578af019-5095-46d2-a321-1f6ae2a1e402</experiment><experiment treatment="7f001e02-f322-4add-9c28-be3069db412e" featEval="navigation.SSE" featEvalComp="navigation" featEvalName="SSE" featureEnabled="true">60f33d99-379a-4bb9-b393-c6e29f5271c3</experiment><experiment treatment="5a633ae7-2cbe-4939-98cd-fb0e22ec5cbd" featEval="N/A.BaMultiUploadMillionCharacterLimit" featEvalComp="N/A" featEvalName="BaMultiUploadMillionCharacterLimit" featureEnabled="true">ed12afb3-bb2d-4974-b8b1-a8e37d4c2b1d</experiment><experiment treatment="43c76134-bfb7-44d1-af47-c1ff3883e7ac" featEval="briefanalyzerreport.LexisPlusAiShepardsPod" featEvalComp="briefanalyzerreport" featEvalName="LexisPlusAiShepardsPod" featureEnabled="true">038e3349-cb61-4715-8245-45848e057417</experiment><experiment treatment="30db3bc1-b058-49ed-b903-2a6d4c8bcea4" featEval="aiassistant.Access to LawSurvey" featEvalComp="aiassistant" featEvalName="Access to LawSurvey" featureEnabled="true">c7b76bdf-366e-4cbb-a3c3-72294f1e9186</experiment><experiment treatment="024a732f-3118-425f-8462-92edd156e694" featEval="navigation.HenchmanDMSEnabled" featEvalComp="navigation" featEvalName="HenchmanDMSEnabled" featureEnabled="true">dc152804-5a47-4492-a1be-2a9291d6fa76</experiment><experiment treatment="4cc4b7b4-7a80-4958-989a-e5cab5562480" featEval="briefanalyzerreport.LexisPlusAiUploadAndAnalyzeQuoteCheck" featEvalComp="briefanalyzerreport" featEvalName="LexisPlusAiUploadAndAnalyzeQuoteCheck" featureEnabled="true">3637decc-204f-47d7-a1ca-5f9f1b4762a9</experiment><experiment treatment="5760989e-b2f3-4e70-bf66-2427884438d9" featEval="navigation.aiservicepeerupload" featEvalComp="navigation" featEvalName="aiservicepeerupload" featureEnabled="true">886b040b-b277-49b1-bf89-156301db76b7</experiment><experiment treatment="bf6126a2-f4b1-4c2d-b6a4-601f04dc9dda" featEval="Navigation.Protege_Settings" featEvalComp="Navigation" featEvalName="Protege_Settings" featureEnabled="true">bb45af28-628d-49b9-82a3-883af44d5572</experiment><experiment treatment="bda5a215-71f8-4d1f-99a0-573723e590f7" featEval="aiassistant.OneCharacterUploadMinimumCharacterLimit" featEvalComp="aiassistant" featEvalName="OneCharacterUploadMinimumCharacterLimit" featureEnabled="true">159b9335-4bbf-4c27-942f-7cd081d23d76</experiment><experiment treatment="5959b464-3a69-4b2e-9094-ab8a977a5f38" featEval="navigation.MultiJurisdictionEnabled" featEvalComp="navigation" featEvalName="MultiJurisdictionEnabled" featureEnabled="true">6a237275-eeaf-491b-bf77-bb568227ff43</experiment><experiment treatment="62afef9f-ba65-48c1-8fde-2587a8ade1bf" featEval="aiassistant.ASK_ENABLE_REFACTOR_AGENTIC_FIFTY_STATES" featEvalComp="aiassistant" featEvalName="ASK_ENABLE_REFACTOR_AGENTIC_FIFTY_STATES" featureEnabled="true">6d2b831d-07e0-4549-a928-c399fb7c2d4a</experiment><experiment treatment="9cfdfa76-3bb4-458a-a8a6-5b545b5d1b7d" featEval="navigation.Agentic Workflow V1" featEvalComp="navigation" featEvalName="Agentic Workflow V1" featureEnabled="true">53990613-3251-46d8-94a9-60f6c6ffaeae</experiment><experiment treatment="c7610413-e6f1-4a5f-9b2c-8cf0644f7b59" featEval="N/A.MultiUploadPresignedUrls" featEvalComp="N/A" featEvalName="MultiUploadPresignedUrls" featureEnabled="true">69058752-9620-4166-839e-ce9c486d9d13</experiment><experiment treatment="7957bfdb-eee6-4eba-9527-63e49faad87f" featEval="aiassistant.showtreatisespct" featEvalComp="aiassistant" featEvalName="showtreatisespct" featureEnabled="true">0d9424ba-8386-482a-a5bf-3dd81caa8f09</experiment><experiment treatment="dd90ed19-cd8a-4cf5-9c61-7f0e2c3fcbfc" featEval="aiassistant.ASK_50_STATES_OVERALL_SUMMARY" featEvalComp="aiassistant" featEvalName="ASK_50_STATES_OVERALL_SUMMARY" featureEnabled="true">6cb7691a-fb52-4621-9840-677ff9faffa4</experiment><experiment treatment="b15b186f-4349-495d-b08a-5b7a34fab92a" featEval="navigation.isDefaultJurisdictionEnabled" featEvalComp="navigation" featEvalName="isDefaultJurisdictionEnabled" featureEnabled="true">641c5a21-b9b6-4b56-b455-46e3686f9645</experiment><experiment treatment="0bcbbecd-34aa-424d-b76e-d1a664bd6211" featEval="aiassistant.ASK_PROMPT_STRENGTHENING" featEvalComp="aiassistant" featEvalName="ASK_PROMPT_STRENGTHENING" featureEnabled="true">b9ef192f-93c7-4dd4-950f-6420bde57fd3</experiment><experiment treatment="272477f6-523d-47fc-9303-f92a6e9daee2" featEval="briefanalyzerreport.LexisPlusAiUploadAndAnalyze" featEvalComp="briefanalyzerreport" featEvalName="LexisPlusAiUploadAndAnalyze" featureEnabled="true">713701e1-4122-44a4-a1cc-99a6bc637aef</experiment><experiment treatment="0de52c01-1185-408d-9513-0057bda4c007" featEval="aiassistant.ProtegePreview" featEvalComp="aiassistant" featEvalName="ProtegePreview" featureEnabled="true">9fd71322-59e1-44db-a3ed-c3053591a567</experiment></experimentList>"""

def get_auth_tokens(username, password, server):

    request_header = """<rt:requestToken xmlns:rt="http://services.lexisnexis.com/xmlschema/request-token/1"><transactionID>00db4725-1c04-8f59-4fc1-4efca6a765c3</transactionID><sequence>1</sequence><featurePermID/><clientID>test client</clientID><cpmFeatureCode/><billBackString>test</billBackString><contextualFeaturePermID>1000516</contextualFeaturePermID><other><priceToken>Demo</priceToken></other></rt:requestToken>"""
    # According to Brian Rambacher application tokens never expire so hard coding it, ratherthan generating it again

    application_token = """<ns2:applicationToken xmlns:ns2="http://services.lexisnexis.com/xmlschema/application-token/1"><applicationPermID>1000202</applicationPermID><issued>2023-05-14T15:49:03.849Z</issued><signature>v1-29e7a301a1ff3dbbb3552fb00daef426</signature></ns2:applicationToken>"""

    headers = {"Content-Type": "application/xml", "Accept": "application/xml", "X-LN-Request": request_header}

    sso_post_data = (
            "<CreateSSOTokenRequest "
            'xmlns="http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            'xmlns:xsd="http://www.w3.org/2001/XMLSchema"> '
            "<userId>" + username + "</userId><password>" + password + "</password></CreateSSOTokenRequest>"
    )

    headers["X-LN-Application"] = application_token
    tokenUrlSSO = "http://" + server +  COMMOM_SERVER_ENDPOINT + "/identity/accesstoken/sso"

    print("Session call: " + tokenUrlSSO)
    sso_resp_data = requests.post(
        tokenUrlSSO, headers=headers, data=sso_post_data, auth=HTTPBasicAuth("internalsvcs", "3uF6ezaC")
        )

    sso_value = sso_resp_data.text
    xm = xml.dom.minidom.parseString(sso_value)
    sso_token = xm.documentElement.firstChild.firstChild.toxml()
    sso_tag = xm.documentElement.firstChild.toxml()

    # ----------------------- session ------------------------------

    tokenUrlSession = "http://" + server + COMMOM_SERVER_ENDPOINT + "/identity/accesstoken/session"

    session_post_data = (
            "<CreateSessionTokenRequest "
            'xmlns="http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            'xmlns:xsd="http://www.w3.org/2001/XMLSchema"><ssoCookieValue>'
            + sso_token
            + "</ssoCookieValue><lnSessionId>generate</lnSessionId></CreateSessionTokenRequest>"
    )

    print("Session call: " + tokenUrlSession)
    session_resp_data = requests.post(
        tokenUrlSession, headers=headers, data=session_post_data, auth=HTTPBasicAuth("internalsvcs", "3uF6ezaC")
        )
    session_value = session_resp_data.text
    xm = xml.dom.minidom.parseString(session_value)
    session_token = xm.documentElement.toxml()
    print("\n")
    print("X-LN-Session: " + session_token)
    print("--------------------------------------------------------")

    print("X-LN-Application: " + application_token)
    print("--------------------------------------------------------")

    print("X-LN-Request: " + request_header)
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Session: " + session_token.replace('"', '\\"'))
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Application: " + application_token.replace('"', '\\"'))
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Request: " + request_header.replace('"', '\\"'))
    print("--------------------------------------------------------")

    return request_header, application_token, session_token

def get_wam_headers(env):
    asset_group= ENV_DATA[env]["asset_group"]
    user = ENV_DATA[env]["user"]
    request_header, application_token, session_token = get_auth_tokens(user, "Testing99", server=asset_group)
    return {
        "X-LN-Validate-Output": "true",
        "X-LN-Application": application_token,
        "X-LN-Request": request_header,
        "X-LN-Session": session_token,
        }

class DocFileModel(BaseModel):
    document_display_name: str
    upload_identifier: str
    session_identifier: str
    upload_link: str
    document_page_count: Optional[int] = None
    document_character_count: Optional[int] = None


def create_session(agent_host, user_id):
    payload = {
        "user_id": user_id,
        "session_name": user_id,
        "client_id": "test",
        }
    payload = json.dumps(payload)
    headers = {"Content-Type": "application/json"}
    response = requests.request("POST", agent_host + "/api/v1/proxy/sessions", headers=headers, data=payload)
    session_id = response.json()["data"]["session_id"]
    print(f"Session ID: {session_id}")
    return session_id

def process_payload(agent_host, user_id, session_id, message, intent, vault_config, headers, highlighted_section=""):
    output_html_path = Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_output.html"


    payload = {
        "user_id": user_id,
        "session_id": session_id,
        "message": message,
        "streaming": True,
        "intent": intent,
        "headers": headers,
        }

    if vault_config:
        payload["data_source"] = vault_config

    if highlighted_section:
        payload["highlighted_section"] = highlighted_section

    payload = json.dumps(payload)
    with open(Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_request.json", "w") as f:
        f.write(payload)
    url = agent_host + "/api/v1/messages_stream"

    with requests.Session() as session:
        with session.post(url, headers=headers, data=payload, stream=True) as response:
            with open(output_html_path, "w", encoding="utf-8") as html_file:
                for line in response.iter_lines():
                    if line:  # filter out keep-alive new chunks
                        line = line.decode("utf-8")
                        if line.startswith(": ping"):
                            continue
                        line = line[len("data: ") :]
                        draft_dict = json.loads(line)
                        html_file.write(f"<p>{json.dumps(draft_dict)}</p>\n")
                        print(draft_dict)
                        if draft_dict["detail-type"] == "conversational-manager-message-finished":
                            return draft_dict

def main():
    CURR_ENV = "dev"
    user_id = ENV_DATA[CURR_ENV]["id"]
    agent_host = ENV_DATA[CURR_ENV]["url"]
    message = "Perform the following skill service: Issue Analysis"
    intent = "ma_clause_identification_skill"
    vault_config =[
        {
            "type": "dbotf",
            "content_type": "",
            "document_type_filter": [],
            "corpus": [
                "bc542a55-7225-4103-a0d9-3e5693ac93e6/cbd01714-0eea-4f23-9877-0691951f7822/d5b38771-f3f1-4d89-8623-1fe1dfe1fbd2"
                ],
            "documents": [
                #"8fc15ffd-268d-49ee-8922-e33517d189d9",
                "881a4f12-a27a-4ea0-8529-df1ebb8b66f2",
                "6f4b2fcf-4925-4845-a31f-2cdb3f225a1f",
                "34aa7ee4-86f2-43c3-837a-f670b3834f9a",
                "e94f279d-0eab-4d79-bee7-bbc78f5fd0f4",
                "bacf60c9-3de1-46f0-b512-8af82d285475",
                "eb6eab00-8c0e-44dd-9cc9-e41840e67919",
                "696f87d5-b43d-48fd-80c5-9ed2e20bc02f",
                "2f82ef99-efe1-4b45-bce7-df662eced94d",
                "aaf61fab-fb2d-4046-a338-79721ab46445",
                "e96d3c41-e2e4-413a-b6b9-f9992d4a6cd1",
                "28fee29a-42cd-4a8f-9ad4-3f0d7eacd20e",
                "ed615a7a-4137-4310-834f-97809a45f99b",
                "1f02b96a-796c-4e75-b4e2-eca6f17a1972",
                "09735e22-c553-4591-b217-851ad8abe713",
                "fa19114c-f97c-4b73-9e0f-649650802f53",
                "4d7bbfa4-2892-492c-b49b-ef7b1176e525",
                "a7262bc0-7412-4dc9-9daf-d54896d0c367",
                "5073f3be-ee57-4df4-8905-0691f1691976",
                "2d666171-efd5-4c1c-bb06-cbab999f42bf",
                "32accc4f-c6e2-4450-9fd5-39aefbe9166e",
                "00bc36de-83a5-4d9c-83c9-db1a72ff8d7a",
                "ab33c1f5-1cf7-45d0-a7fc-61f820f69834"
                ],
            "vault_public_id": "d5b38771-f3f1-4d89-8623-1fe1dfe1fbd2",
            "subvault_public_id": ""
            }
        ]
    # Create a session
    session_id = create_session(agent_host, user_id)

    headers = get_wam_headers(CURR_ENV)
    headers["x-ln-output-format"] = "json"
    headers["X-LN-Request"] = headers["X-LN-Request"].replace(
        "</rt:requestToken>", LONG_HEADER + "</rt:requestToken>"
        )

    output = process_payload(agent_host, user_id, session_id, message, intent, vault_config, headers, highlighted_section="")
    with open(Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_output.json", "w") as f:
        json.dump(output, f, indent=2)

    return output


if __name__ == "__main__":
    print(main())
