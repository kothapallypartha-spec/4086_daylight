#!/usr/bin/env python3
"""
Test script for S3 utility functions in lambda_handler.py
"""

import sys
import os
import json

# Add the parent directories to Python path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
clause_skill_dir = os.path.dirname(current_dir)  # clause_skill directory
src_python_dir = os.path.dirname(clause_skill_dir)  # src/python directory
sys.path.insert(0, src_python_dir)
sys.path.insert(0, clause_skill_dir)

from lambda_handler import (
    upload_file_s3,
    delete_file_s3,
    download_file_s3,
    get_document_from_file,
)


def test_s3_functions():
    """Test S3 functions with mock data"""

    print("Testing S3 utility functions...")

    # Test data
    test_content = json.dumps({"test": "data", "timestamp": "2024-01-01"}).encode(
        "utf-8"
    )
    test_filename = "test_output.json"

    # Test without actual AWS credentials (will fail gracefully)
    print("\n1. Testing upload_file_s3:")
    result = upload_file_s3(test_content, test_filename)
    print(f"Upload result: {result}")

    print("\n2. Testing delete_file_s3:")
    status, message = delete_file_s3(test_filename)
    print(f"Delete result: {status}, {message}")

    print("\n3. Testing download_file_s3:")
    content = download_file_s3(test_filename)
    print(f"Download result: {content is not None}")

    print("\n4. Testing get_document_from_file:")
    doc_content = get_document_from_file(test_filename)
    print(f"Get document result: {doc_content is not None}")

    print(
        "\nNote: These functions will fail without AWS credentials, but imports and function signatures work correctly."
    )


if __name__ == "__main__":
    test_s3_functions()
