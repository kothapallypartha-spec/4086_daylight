#!/usr/bin/env python3
"""
This test iterates through all DOCX files in a specified directory
and analyzes each one, providing detailed output for comparison and validation.

Usage:
    python test_batch_docx_analysis.py [input_directory]

If no directory is specified, defaults to tests/data directory.
"""

import requests
import json
import time
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional


class DocxAnalysisTester:
    """Test runner for analyzing multiple DOCX documents."""

    def __init__(
        self,
        api_base_url: str = "http://localhost:8000",
        data_dir: Optional[Path] = None,
    ):
        self.api_base_url = api_base_url
        self.data_dir = data_dir if data_dir else Path(__file__).parent / "data"
        self.output_dir = Path(__file__).parent / "output"
        self.output_dir.mkdir(exist_ok=True)

        # Ensure data directory exists
        if not self.data_dir.exists():
            raise FileNotFoundError(f"Input directory does not exist: {self.data_dir}")
        if not self.data_dir.is_dir():
            raise NotADirectoryError(f"Input path is not a directory: {self.data_dir}")

    def find_docx_files(self) -> List[Path]:
        """Find all DOCX files in the data directory."""
        docx_files = list(self.data_dir.glob("*.docx"))
        return sorted(docx_files)  # Sort for consistent ordering

    def analyze_single_document(self, file_path: Path) -> Dict[str, Any]:
        """Analyze a single DOCX document and return results."""
        print(f"\n{'='*80}")
        print(f"Analyzing: {file_path.name}")
        print(f"{'='*80}")

        start_time = time.time()

        try:
            # Make API request
            url = f"{self.api_base_url}/analyze-document"

            with open(file_path, "rb") as file:
                files = {
                    "file": (
                        file_path.name,
                        file,
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    )
                }

                print(f"Uploading {file_path.name}...")
                print(f"File size: {file_path.stat().st_size:,} bytes")
                print("Processing (may take a moment)...")

                response = requests.post(url, files=files, timeout=900)

            processing_time = time.time() - start_time

            if response.status_code == 200:
                result = response.json()

                # Print success summary
                print(f"Analysis completed successfully!")
                print(f"Processing time: {processing_time:.2f} seconds")
                print(f"Sections found: {result['total_sections']}")
                print(
                    f"Message: {result['message']}"
                )  # Analyze sections if any were found
                if result["sections"]:
                    self._print_section_analysis(result["sections"])
                else:
                    print("No sections were extracted from this document")
                    print("This could be due to:")
                    print("- Document format not suitable for clause analysis")
                    print("- Content doesn't match expected clause type patterns")
                    print("- Processing or filtering issues")

                # Save detailed results
                self._save_results(file_path, result, processing_time)

                return {
                    "file_name": file_path.name,
                    "success": True,
                    "sections_found": result["total_sections"],
                    "processing_time": processing_time,
                    "error": None,
                }

            else:
                error_msg = f"HTTP {response.status_code}: {response.text}"
                print(f"Analysis failed: {error_msg}")

                return {
                    "file_name": file_path.name,
                    "success": False,
                    "sections_found": 0,
                    "processing_time": processing_time,
                    "error": error_msg,
                }

        except requests.exceptions.RequestException as e:
            error_msg = f"Request failed: {str(e)}"
            print(f"Network error: {error_msg}")

            return {
                "file_name": file_path.name,
                "success": False,
                "sections_found": 0,
                "processing_time": time.time() - start_time,
                "error": error_msg,
            }

        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            print(f"Error: {error_msg}")

            return {
                "file_name": file_path.name,
                "success": False,
                "sections_found": 0,
                "processing_time": time.time() - start_time,
                "error": error_msg,
            }

    def _print_section_analysis(self, sections: List[Dict[str, Any]]) -> None:
        """Print detailed analysis of found sections."""
        print(f"\nSection Analysis:")

        # Count sections by type and level
        type_counts = {}
        level_counts = {}

        for section in sections:
            type_name = section.get("typeName", "Unknown")
            level = section.get("nesting_level", 0)

            type_counts[type_name] = type_counts.get(type_name, 0) + 1
            level_counts[level] = level_counts.get(level, 0) + 1

        # Print statistics
        print(f"Sections by type:")
        for type_name, count in sorted(type_counts.items()):
            type_display = type_name if type_name else "'No Type'"
            print(f"  {type_display}: {count}")

        print(f"\nSections by nesting level:")
        for level, count in sorted(level_counts.items()):
            print(f"  Level {level}: {count}")

        # Show first 3 sections as examples only, because sometimes several are found.
        print(f"\nSample sections (first 3):")
        for i, section in enumerate(sections[:3], 1):
            print(f"\n   --- Section {i} ---")
            print(f"   Title: {section.get('title', 'No title')}")
            print(f"   Type: {section.get('typeName', 'No type')}")
            print(f"   Level: {section.get('nesting_level', 'Unknown')}")
            print(f"   Path: {section.get('hierarchical_path', 'No path')}")

            # Show a small text preview
            clean_text = section.get("clean_clause_text", "")
            if clean_text:
                preview = (
                    clean_text[:150] + "..." if len(clean_text) > 150 else clean_text
                )
                print(f"   Text: {preview}")
            else:
                print(f"   Text: No clean text available")

    def _save_results(
        self, file_path: Path, result: Dict[str, Any], processing_time: float
    ) -> None:
        """Save detailed results to JSON file."""
        # Create enhanced result with metadata
        enhanced_result = {
            "analysis_metadata": {
                "source_file": file_path.name,
                "file_size_bytes": file_path.stat().st_size,
                "processing_time_seconds": processing_time,
                "analysis_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            },
            "analysis_results": result,
        }

        # Save to file
        safe_name = file_path.stem.replace(" ", "_").replace(".", "_")
        output_file = self.output_dir / f"batch_analysis_{safe_name}.json"

        # I have added output/ to .gitignore, so we won't bloat up the repo
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(enhanced_result, f, indent=2, ensure_ascii=False)

        print(f"Detailed results saved to: {output_file}")

    def run_batch_analysis(self) -> None:
        """Run analysis on all DOCX files and provide summary."""
        print("Starting Batch DOCX Analysis")
        print("=" * 80)
        print(f"Input directory: {self.data_dir.resolve()}")
        print(f"Output directory: {self.output_dir.resolve()}")
        print()

        # Find all DOCX files
        docx_files = self.find_docx_files()

        if not docx_files:
            print("No DOCX files found in the specified directory!")
            print(f"Searched in: {self.data_dir.resolve()}")
            print(
                "Please add some DOCX files to test with or specify a different directory."
            )
            return

        print(f"Found {len(docx_files)} DOCX files to analyze:")
        for i, file_path in enumerate(docx_files, 1):
            file_size = file_path.stat().st_size
            print(f"   {i}. {file_path.name} ({file_size:,} bytes)")

        # Analyze each file
        results = []
        total_start_time = time.time()

        for i, file_path in enumerate(docx_files, 1):
            print(f"\nProcessing {i}/{len(docx_files)}")
            result = self.analyze_single_document(file_path)
            results.append(result)

            # Small delay between files to be nice to the API
            if i < len(docx_files):
                time.sleep(1)

        # Print final summary
        total_time = time.time() - total_start_time
        self._print_batch_summary(results, total_time)

        # Save batch summary
        self._save_batch_summary(results, total_time)

    def _print_batch_summary(
        self, results: List[Dict[str, Any]], total_time: float
    ) -> None:
        """Print summary of batch analysis results."""
        print(f"\n{'='*80}")
        print("BATCH ANALYSIS SUMMARY")
        print(f"{'='*80}")

        successful = [r for r in results if r["success"]]
        failed = [r for r in results if not r["success"]]

        print(f"Overall Statistics:")
        print(f"   Total files processed: {len(results)}")
        print(f"   Successful analyses: {len(successful)}")
        print(f"   Failed analyses: {len(failed)}")
        print(f"   Success rate: {len(successful)/len(results)*100:.1f}%")
        print(f"   Total processing time: {total_time:.2f} seconds")

        if successful:
            total_sections = sum(r["sections_found"] for r in successful)
            avg_sections = total_sections / len(successful)
            avg_time = sum(r["processing_time"] for r in successful) / len(successful)

            print(f"\nSection Statistics (successful analyses only):")
            print(f"Total sections found: {total_sections}")
            print(f"Average sections per document: {avg_sections:.1f}")
            print(f"Average processing time: {avg_time:.2f} seconds")

            print(f"\nSuccessful analyses:")
            for result in successful:
                print(
                    f"- {result['file_name']}: {result['sections_found']} sections ({result['processing_time']:.1f}s)"
                )

        if failed:
            print(f"\nFailed analyses:")
            for result in failed:
                print(f"- {result['file_name']}: {result['error']}")

    def _save_batch_summary(
        self, results: List[Dict[str, Any]], total_time: float
    ) -> None:
        """Save batch summary to JSON file."""
        summary = {
            "batch_metadata": {
                "total_files": len(results),
                "successful_analyses": len([r for r in results if r["success"]]),
                "failed_analyses": len([r for r in results if not r["success"]]),
                "total_processing_time": total_time,
                "analysis_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            },
            "individual_results": results,
        }

        summary_file = self.output_dir / "batch_analysis_summary.json"
        with open(summary_file, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)

        print(f"\nBatch summary saved to: {summary_file}")


def main():
    """Main function to run the batch analysis."""
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description="Analyze all DOCX files in a directory using the Clause Analysis API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                                    # Use default tests/data directory
  %(prog)s /path/to/documents                 # Use custom directory
  %(prog)s ../contracts --api http://api:8080 # Custom directory and API URL
        """,
    )

    parser.add_argument(
        "input_directory",
        nargs="?",
        type=Path,
        help="Directory containing DOCX files to analyze (default: tests/data)",
    )

    parser.add_argument(
        "--api",
        "-a",
        default="http://localhost:8000",
        help="API base URL (default: http://localhost:8000)",
    )

    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        help="Output directory for results (default: tests/output)",
    )

    args = parser.parse_args()

    try:
        # Determine input directory
        if args.input_directory:
            data_dir = args.input_directory.resolve()
            print(f"Using custom input directory: {data_dir}")
        else:
            # Default to tests/data relative to this script
            data_dir = Path(__file__).parent / "data"
            print(f"Using default input directory: {data_dir.resolve()}")

        # Create tester instance
        tester = DocxAnalysisTester(api_base_url=args.api, data_dir=data_dir)

        # Override output directory if specified
        if args.output:
            tester.output_dir = args.output.resolve()
            tester.output_dir.mkdir(parents=True, exist_ok=True)
            print(f"Using custom output directory: {tester.output_dir}")

        print()

        # Check if API is available
        print("Checking API availability...")
        try:
            response = requests.get(f"{tester.api_base_url}/health", timeout=5)
            if response.status_code == 200:
                print("API is available and responding")
            else:
                print(f"API returned status {response.status_code}")
        except requests.exceptions.RequestException:
            print("API is not available!")
            print("Please make sure the FastAPI service is running:")
            print("python src/python/clause_skill/clause_skill_fastapi_service.py")
            return 1

        print()

        # Run the batch analysis
        tester.run_batch_analysis()
        return 0

    except (FileNotFoundError, NotADirectoryError) as e:
        print(f"Directory error: {e}")
        return 1
    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user")
        return 1
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        import traceback

        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = main()
    print(f"\nAnalysis complete. Exit code: {exit_code}")
