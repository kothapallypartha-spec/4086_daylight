import requests
from pathlib import Path
import json


def test_document_analysis():
    """Test the FastAPI service with a document file (PDF or DOCX)."""

    # Look for test documents in the data directory
    data_dir = Path(__file__).parent / "data"

    # Look for common document types
    test_files = []
    for pattern in ["*.pdf", "*.docx", "*.doc"]:
        test_files.extend(data_dir.glob(pattern))

    if not test_files:
        print("No test documents found in tests/data directory.")
        print("Please add a .pdf, .docx, or .doc file to tests/data/ directory.")
        return

    # Use the first available test file
    test_file = test_files[0]
    print(f"Using test file: {test_file.name}")

    # API endpoint
    url = "http://localhost:8000/analyze-document"

    try:
        # Open and send the file
        with open(test_file, "rb") as file:
            files = {"file": (test_file.name, file, "application/octet-stream")}

            print(f"Uploading and analyzing document: {test_file.name}")
            print("This may take a moment for document conversion...")

            response = requests.post(url, files=files, timeout=900)

        if response.status_code == 200:
            result = response.json()
            print(f"\nSuccess! Document analysis completed.")
            print(f"Total sections found: {result['total_sections']}")
            print(f"Message: {result['message']}")

            # Display first few sections as examples
            if result["sections"]:
                print(f"\nFirst 3 sections (out of {len(result['sections'])}):")
                for i, section in enumerate(result["sections"][:3]):
                    print(f"\n--- Section {i+1} ---")
                    print(f"Title: {section['title']}")
                    print(f"Type: {section['typeName']} (ID: {section['typeID']})")
                    print(f"Hierarchical Path: {section['hierarchical_path']}")
                    print(f"Nesting Level: {section['nesting_level']}")
                    print(f"Section Number: {section['sectionNumber']}")
                    print(f"Source File: {section['source_file']}")
                    print(
                        f"Clause Text (first 200 chars): {section['clause_text'][:200]}..."
                    )
                    print(
                        f"Clean Text (first 200 chars): {section['clean_clause_text'][:200]}..."
                    )

            # Save full response to file for inspection
            output_file = (
                Path(__file__).parent
                / "output"
                / f"document_analysis_result_{test_file.stem}.json"
            )
            output_file.parent.mkdir(exist_ok=True)

            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)

            print(f"\nFull results saved to: {output_file}")

        else:
            print(f"Error: {response.status_code}")
            print(f"Response: {response.text}")

    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")


if __name__ == "__main__":
    # Create a sample file if no test documents exist
    data_dir = Path(__file__).parent / "data"
    test_files = (
        list(data_dir.glob("*.pdf"))
        + list(data_dir.glob("*.docx"))
        + list(data_dir.glob("*.doc"))
    )

    test_document_analysis()
