import json

from MASkillServices.IssueAnalysis.src.text_utils import match_clauses_to_xpaths


def main():
    all_xpath_info = json.load(open("/tmp/all_xpath_info.json", "r"))
    ref_alignments = json.load(open("/tmp/ref_alignments.json", "r"))

    clauses = [
        {
            "clause_text": "NovaQuest and Aceragen acknowledge and agree that (i) Aceragen has suspended the Program (as defined in the Purchase Agreement) in a material respect such that Aceragen is obligated to effect a Non-Technical Failure Termination Distribution (as defined in the Purchase Agreement) to NovaQuest; (ii) Aceragen has otherwise materially breached the Purchase Agreement, including with respect to its diligence obligations set forth in Section 3.2 thereof and its obligation to maintain a minimum cash balance of Two Million Dollars ($2,000,000) as set forth in Section 8.5(d); and (iii) Aceragen cannot currently pay its debts as they become due, which constitutes a material breach pursuant to Section 9.3(d) of the Purchase Agreement (collectively, the \"Purchase Agreement Deficiencies\"). NovaQuest and Aceragen further acknowledge and agree that (A) the amount of the Non-Technical Failure Termination Distribution payable to NovaQuest as of the Effective Date is [****] and that such amount shall continue to accrue interest as set forth in the Purchase Agreement until the ABC Commencement Date (such total amount, the \"Allowed Secured Claim Amount\"); (B) Aceragen owes NovaQuest not less than that amount and that such amount constitutes a current, non-cancellable payment obligation of Aceragen; and (C) that amount is secured by a valid, perfected, first priority security interest in the Product Assets.",
            "clause_type": "Sample",
        }
    ]

    match_clauses_to_xpaths(clauses, all_xpath_info, ref_alignments)

    ignore = 0


if __name__ == "__main__":
    main()