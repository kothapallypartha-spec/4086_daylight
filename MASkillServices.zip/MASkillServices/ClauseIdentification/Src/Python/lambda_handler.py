"""
Lambda response utilities for the Clause Skill API.
Handles AWS Lambda + Application Load Balancer response formatting with S3 fallback for large responses.

Using the IssueAnalysis virtual environment,
in ~/4086-daylight-skill-services/MASkillServices/ClauseIdentification, do
$ (cd Src/Python; PYTHONPATH=. pylint -E $(rg --files -g '*.py'))
to check for egregious errors
"""
import re
import json
import sys
import os
import logging
from uuid import uuid4, UUID
import urllib.request
from urllib.parse import urlparse
import boto3

# Handle both direct execution and package imports
try:
    from .data_models import (
        AnalysisResult,
        ErrorResponse,
        AnalysisRequest,
    )
except ImportError:
    from data_models import (
        AnalysisResult,
        ErrorResponse,
        AnalysisRequest,
    )
# Handle both direct execution and package imports. Prob need to simplify this.
try:
    from .clause_type_intelligize import (
        call_contract_analysis_api,
        process_api_response,
        )
except ImportError:
    from clause_type_intelligize import (
        call_contract_analysis_api,
        process_api_response,
        )

DEBUG = (
    os.environ.get("DEBUG", "false").lower() == "true"
)  # Enable debug logging if set


LOG_LEVEL = "INFO"
logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger()

IO_BUCKET = os.environ.get("IO_BUCKET", "11346-due-diligence-ma-164682029196")
IO_LOC = os.environ.get("IO_LOC", "io")
CLAUSE_REC_IO_BUCKET = os.environ.get(
    "CLAUSE_REC_IO_BUCKET", "11346-due-diligence-ma-164682029196"
)

# For now we are just making up user_id and session_id, as we don't have a real auth context
# In future we will get these from app and will parse from input request
def get_user_id() -> str:
    """
    Extract or generate user ID from the request context.
    Currently returns a placeholder value for testing purposes.

    Returns:
        str: User identifier
    """
    return "clause-analysis-user-001"


def get_session_id() -> UUID:
    """
    Extract or generate session ID from the request context.
    Currently generates a new UUID for each request.

    Returns:
        UUID: Session identifier
    """
    return uuid4()


def upload_file_s3(file_content, object_name, loc=IO_LOC, bucket=IO_BUCKET):
    """
    Upload file content to S3 bucket.

    Args:
        file_content: File content (bytes or str)
        object_name: S3 object name
        loc: S3 prefix/location (default: IO_LOC)
        bucket: S3 bucket name (default: IO_BUCKET)

    Returns:
        S3 key if successful, None if failed
    """
    try:
        import boto3

        if not bucket:
            logger.error("S3 bucket not configured")
            return None

        s3 = boto3.client("s3")
        key = f"{loc}/{object_name}"
        logger.info(f"Uploading output to {key} in s3")

        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=file_content,
            ServerSideEncryption="AES256",
            ContentType="application/json",
        )
        return key

    except ImportError:
        logger.error("boto3 not available for S3 upload")
        return None
    except Exception as e:
        logger.error(f"Unable to upload file")
        logger.error(e)
        return None


def delete_file_s3(object_name, loc=IO_LOC, bucket=IO_BUCKET):
    """
    Delete file from S3 bucket.

    Args:
        object_name: S3 object name
        loc: S3 prefix/location (default: IO_LOC)
        bucket: S3 bucket name (default: IO_BUCKET)

    Returns:
        Tuple of (status_code, message)
    """
    try:

        if not bucket:
            logger.error("S3 bucket not configured")
            return 400, "S3 bucket not configured"

        s3 = boto3.resource("s3")
        KEY = f"{loc}/{object_name}"
        logger.info(f"Deleting file:{object_name} from {KEY}")

        response = s3.Bucket(bucket).delete_objects(Delete={"Objects": [{"Key": KEY}]})   # type: ignore
        errors = response.get("Errors", [])

        if len(errors):
            message = errors[0].get("Message", "Unable to delete file")
            logger.error(message)
            return 400, message
        else:
            return 200, f"successfully deleted {bucket}/{KEY}"

    except ImportError:
        logger.error("boto3 not available for S3 operations")
        return 400, "boto3 not available"
    except Exception as e:
        logger.error(f"Unable to delete file:{object_name}")
        logger.error(e)
        return 400, f"Unable to delete file:{object_name}"


def download_file_s3(file_name, loc=IO_LOC, bucket=IO_BUCKET):
    """
    Download file from S3 bucket.

    Args:
        file_name: S3 object name
        loc: S3 prefix/location (default: IO_LOC)
        bucket: S3 bucket name (default: IO_BUCKET)

    Returns:
        File content as bytes if successful, None if failed
    """
    try:

        if not bucket:
            logger.error("S3 bucket not configured")
            return None

        s3 = boto3.client("s3")
        key = f"{loc}/{file_name}"
        logger.info(f"Downloading file from {key} in s3")

        response = s3.get_object(Bucket=bucket, Key=key)
        return response["Body"].read()

    except ImportError:
        logger.error("boto3 not available for S3 download")
        return None
    except Exception as e:
        logger.error(f"Unable to download file from S3: {file_name}")
        logger.error(e)
        return None


def get_document_from_file(file_name, bucket=IO_BUCKET):
    """
    Get document content from S3 file.

    Args:
        file_name: S3 object name
        bucket: S3 bucket name (default: IO_BUCKET)

    Returns:
        File content if successful, None if failed
    """
    try:
        content = download_file_s3(file_name, bucket=bucket)
        if content is None:
            logger.error(f"Unable to download file from S3: {file_name}")
            return None
        return content

    except Exception as e:
        logger.error(f"Unable to download file from S3: {file_name}")
        logger.error(e)
        return None


def lambda_handler(event: dict, context) -> dict:
    """
    AWS Lambda handler for clause analysis requests.
    """
    logger.info("Clause analysis Lambda handler started")
    logger.info(f"Event keys: {list(event.keys())}")

    # Validate event has body
    if "body" not in event:
        return ErrorResponse(
            body="Missing 'body' in event"
        ).model_dump()

    try:
        body = json.loads(event["body"])
        assert isinstance(body, dict), "Request body must be a valid JSON object"
        data = AnalysisRequest.model_validate(body)
        logger.info("Request validation successful")
        url = str(data.url)
        if re.match(".*-la-sp-upload.route53.lexis.com.*upload", url) and ("artifacts" not in url):
            logger.warning("Manipulating upload URL to point to docxhtml directly")
            url = url.replace("upload/", "upload/artifacts/")
        filename = body.get("filename_stem", os.path.basename(urlparse(url).path))
        logger.info(f"Fetching document from URL: {url}, header: {data.headers}")
        req = urllib.request.Request(
            url=url,
            headers=data.headers or {}
        )
        with urllib.request.urlopen(req) as response:
            html_content = response.read().decode('utf-8')
        if not html_content:
            return {
                "statusCode": 500,
                "headers": {
                    "Content-Type": "application/json"
                },
                "body": json.dumps(ErrorResponse.from_exception(
                    ValueError("No valid input content found")
                ).model_dump())
            }
        logger.info(
            f"Processing content from {filename}, length: {len(html_content)}"
        )
        result = process_clause_analysis(
            html_content=html_content,
            filename=filename
        )
        logger.info(
            f"Analysis completed successfully. Found {result.total_sections} sections"
        )
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps(result.model_dump())
        }
    except Exception as e:
        logger.exception(e)
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps(ErrorResponse.from_exception(e).model_dump())
        }


def process_clause_analysis(html_content: str, filename: str) -> AnalysisResult:
    """
    Process HTML content and return analysis results.
    """


    # Get response from the contract analysis wrapper API
    api_response, processed_html = call_contract_analysis_api(html_content)

    if api_response is None:
        return AnalysisResult(
            success=False,
            message="Contract analysis API failed",
            sections=[],
            total_sections=0,
        )

    # Process API response
    sections_data = process_api_response(api_response, filename, processed_html)

    return AnalysisResult(
        success=True,
        message=f"Analysis completed successfully for {filename}",
        sections=sections_data,
        total_sections=len(sections_data),
        document_info={"filename": filename},
    )
