from typing import Any, Dict, List


def flatten_sections(
        sections: List[Dict[str, Any]],
        parent_path: str = "",
        level: int = 0,
        html_content: str = "",
        ) -> List[Dict[str, Any]]:
    """
    Recursively flatten nested sections into a list with hierarchical naming and extract clause text.

    Args:
        sections (List[Dict[str, Any]]): List of section dictionaries from API response
        parent_path (str): Parent path for hierarchical naming (e.g., "1_0")
        level (int): Current nesting level
        html_content (str): The original HTML content for extracting clause text

    Returns:
        List[Dict[str, Any]]: Flattened list of sections with hierarchical information and clause text
    """
    flattened = []

    for idx, section in enumerate(sections):
        # Create hierarchical path (e.g., "1_0", "1_0_2", etc. because I see a lot of nesting in html docs)
        current_path = f"{parent_path}_{idx}" if parent_path else str(idx)

        # Extract clause text using coordinates
        start_index = section.get("startIndex", 0)
        end_index = section.get("endIndex", 0)
        clause_text = ""
        clause_xpath = ""

        if (
                html_content
                and start_index < len(html_content)
                and end_index <= len(html_content)
        ):
            try:
                clause_text = html_content[start_index:end_index].strip()
                # Extract XPath for this clause text
                clause_xpath = extract_xpath_for_text(
                    html_content, start_index, end_index
                    )
            except Exception as e:
                clause_text = f"ERROR extracting text: {str(e)}"
                clause_xpath = f"ERROR extracting XPath: {str(e)}"
        elif html_content:
            clause_text = f"ERROR: Coordinates out of range. Content length: {len(html_content)}, requested: {start_index}-{end_index}"
            clause_xpath = "ERROR: Invalid coordinates"

        # Extract section information
        section_info = {
            "hierarchical_path": current_path,  # Adding this to help navigate the hierarchy because xpath kind of sucks right now
            "nesting_level": level,  # Level at which the clause is nested in the doc. Might be helpful downstream too.
            "title": section.get(
                "title", ""
                ),  # This is coming from contract analysis API
            "sectionNumber": section.get(
                "sectionNumber", ""
                ),  # This is coming from contract analysis API
            "typeName": section.get(
                "typeName", ""
                ),  # This is the clause type name coming from intelligize
            "typeID": section.get(
                "typeID", 0
                ),  # This is the internal ID for the clause type coming from intelligize
            "startIndex": start_index,  # Starting index for the clause text found in the text
            "endIndex": end_index,  # Ending index for the clause text found in the text
            "level": section.get("level", 0),
            "isDefinition": section.get(
                "isDefinition", False
                ),  # This is coming from contract analysis API
            "parent_path": (
                parent_path if parent_path else None
            ),  # Parent path for hierarchical naming
            "section_index_at_level": idx,  # Index of this section among its siblings at the same level because same section has multiple children
            "clause_xpath": clause_xpath,  # Add the XPath for the clause, though this is not good quality right now
            "clause_text": clause_text,  # Add the extracted clause text
            "clean_clause_text": filter_xml_tags(clause_text),
            }

        flattened.append(section_info)

        # Recursively process nested sections
        if "sections" in section and section["sections"]:
            nested_sections = flatten_sections(
                section["sections"], current_path, level + 1, html_content
                )
            flattened.extend(nested_sections)

    return flattened

