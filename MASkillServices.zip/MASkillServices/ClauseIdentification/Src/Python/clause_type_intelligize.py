import os

import numpy as np
import json
from typing import List, Dict, Any
import logging

from api_retry import APIParameters, call_api
from data_models import ClauseSection
from text_utils import deduce_matching_xpaths
from definitions import clause_definitions

logger = logging.getLogger()

XML_HEADER = (
    '<?xml version="1.0" encoding="utf-8" standalone="no"?><!DOCTYPE html PUBLIC "-//W3C//DTD '
    'XHTML 1.0 Transitional//EN" '
    '"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html '
    'xmlns="http://www.w3.org/1999/xhtml">'
)

EMBEDDINGS_SVC_URL = os.environ.get("EMBEDDINGS_SVC_URL", "https://cdc1c-get-em.route53.lexis.com/legalbert512sift/gpu/v1")
SIMILARITY_THRESHOLD = float(os.environ.get("SIMILARITY_THRESHOLD", 0.75))

def encode(texts: List[str], id: int = 123, max_length: int = 4096) -> List[List[float]]:
    try:
        request_data = APIParameters(
            url=EMBEDDINGS_SVC_URL,
            payload={"texts": texts, "id": id},
            headers={"Content-Type": "application/json"},
            timeout=30,
            max_retries=3
            )
        response = call_api(request_data)
        if response.status_code != 200:
            raise ValueError(f"Failed in the http request: {response.text}")
        embeddings = response.data["result"]
    except Exception as e:
        raise IOError(f"Failed to get embeddings: {repr(e)}")

    return embeddings


def call_contract_analysis_api(html_content: str):
    """
    Call the Contract Analysis API with proper XML formatting.

    Args:
        html_content (str): Raw HTML/XHTML content from the file

    Returns:
        tuple: (JSON response from the API or None if failed, processed documentxhtml content)
    """
    ASSET_GROUP = os.environ.get('ASSET_GROUP', 'pdc1c')   # default to prod?
    url = os.environ.get("CONTRACT_PARSER_URL", f"https://{ASSET_GROUP}-get-answers.route53.lexis.com/contract-analysis/")

    # Clean up document content - remove existing HTML tags
    new_document_content = html_content.replace("<HTML>", "").replace("<html>", "")

    # This is the actual content that gets sent to the API and what the coordinates refer to
    processed_documentxhtml = f"{XML_HEADER}{new_document_content}"

    payload = {
            "documentxhtml": processed_documentxhtml,
            "show_full_clause_only": True,
        }
    headers = {"Content-Type": "application/json"}

    try:
        # logger.info(payload)
        request_data = APIParameters(
            url=url,
            payload=payload,
            headers=headers,
            timeout=240,
            max_retries=3
            )
        response = call_api(request_data, base_backoff_time=1.0)
        # logger.info(response.text)
        data = response.data
        data_str = json.dumps(data, indent=2)
        logger.info("Part of the service output" + data_str[:1000])  # Log only the first 1000 characters
        if response.status_code != 200:
            logger.error(
                f"Contract Analysis API: {url} failed.\n Status: {response.status_code}\n Response: {response.text}"
            )
            raise IOError(f"Contract Analysis API failed with status {response.status_code}. Error: {response.text}")
    except Exception as e:
        logger.error(f"Error calling API: {e}")
        raise IOError(f"Error calling Contract Analysis API: {repr(e)}")
    return data, processed_documentxhtml


def process_api_response(
    api_response: Dict[str, Any], filename: str, processed_documentxhtml: str = ""
) -> List[ClauseSection]:
    """
    Process the API response and extract section information with actual clause text.

    Args:
        api_response (Dict[str, Any]): JSON response from the Contract Analysis API
        filename (str): Name of the source file for tracking
        processed_documentxhtml (str): The processed documentxhtml content sent to the API (includes XML header)

    Returns:
        List[Dict[str, Any]]: Flattened list of sections with metadata and clause text
    """
    # From Mike's ADO ticket. Kept Intelligize clause types where they match in meaning with Mike's list, else Mike's clause type


    logger.info("Deducing matching xpaths for clauses")
    clauses = api_response["output"].get("clause_sections", [])

    # Adjust the offset shift due to XML header
    shift = len(XML_HEADER) - len("<HTML>")
    for clause in clauses:
        clause["startIndex"] -= shift
        clause["endIndex"] -= shift
    html_content = "<HTML>" + processed_documentxhtml.replace(XML_HEADER, "")
    deduce_matching_xpaths(html_content, clauses)

    # Check if response has the expected structure
    logger.info(
        f"Finding clauses matching the required clause types. Total clauses from the parser service: {len(clauses)}"
        )
    filtered_clauses = []
    clause_types_to_keep, clause_type_definitions = zip(*clause_definitions.items())
    ref_clause_types_embeddings = encode(clause_types_to_keep)
    ref_clauses_embeddings = encode(clause_type_definitions)
    batched_clauses = np.array_split(
        [clause["text"] for clause in clauses if "clause_type" in clause], len(clauses) // 50 + 1
        )
    clause_text_to_embedding = {}
    for batch in batched_clauses:
        embeddings = encode(batch.tolist())
        for clause_text, embedding in zip(batch, embeddings):
            clause_text_to_embedding[clause_text] = embedding
    uniq_clause_types = set([clause.get("clause_type", "") for clause in clauses if "clause_type" in clause])
    uniq_clause_types = {ct for ct in uniq_clause_types if ct.strip()}
    clause_type_to_embedding = {
        ct: encode([ct])[0] for ct in uniq_clause_types
    }
    for clause in clauses:
        clause_text = clause.get("text", "")
        similarities = np.dot(clause_text_to_embedding[clause_text], np.array(ref_clauses_embeddings).T) / (
            np.linalg.norm(clause_text_to_embedding[clause_text]) * np.linalg.norm(ref_clauses_embeddings, axis=1)
        )
        clause_type = clause.get("clause_type", "")
        if clause_type:
            clause_type_embedding = clause_type_to_embedding[clause_type]
            type_similarities = np.dot(clause_type_embedding, np.array(ref_clause_types_embeddings).T) / (
                np.linalg.norm(clause_type_embedding) * np.linalg.norm(ref_clause_types_embeddings, axis=1)
            )
            similarities = np.maximum(similarities, type_similarities)
        if similarities.max() < SIMILARITY_THRESHOLD:  # Threshold for similarity
            continue
        standard_clause_type = clause_types_to_keep[similarities.argmax()]
        new_clause = {
            "document_title": filename,
            "title": clause.get("heading", ""),
            "type_name": standard_clause_type,
            "startIndex": clause.get("startIndex", 0),
            "endIndex": clause.get("endIndex", 0),
            "clause_text": html_content[clause["startIndex"]:clause["endIndex"] + 1],
            "clean_clause_text": clause.get("text").strip(),
            "clause_xpath": ",".join(clause.get("xpaths", [])),
            }

        filtered_clauses.append(ClauseSection(**new_clause))

    logger.info(f"Total clauses after filtering: {len(filtered_clauses)}")

    return filtered_clauses
