import json
import time
from typing import Any, Dict
import logging
import requests
from pydantic import BaseModel
from requests.exceptions import ConnectionError, ConnectTimeout, ReadTimeout

logger = logging.getLogger()

class APIParameters(BaseModel):
    url: str
    payload: list | dict
    timeout: float = 60
    headers: Dict = dict()
    method: str = "post"
    max_retries: int = 2

class APIResponse(BaseModel):
    status_code: int = 400
    message: str = "API Failure"
    data: Any = None

def call_api(api_params: APIParameters, base_backoff_time=0.25) -> APIResponse:
    headers = {"Content-Type": "application/json"}
    url = api_params.url
    headers.update(api_params.headers)
    data = b"None"
    for i in range(api_params.max_retries):
        retry_suffix = ". Retrying..." if i + 1 < api_params.max_retries else ""
        try:
            if api_params.method == "post":
                data = json.dumps(api_params.payload, ensure_ascii=False).encode("utf-8")
                response = requests.post(url, data=data, headers=headers, timeout=api_params.timeout)
            else:  # get
                data = json.dumps(api_params.payload, ensure_ascii=False).encode("utf-8")
                response = requests.get(
                    url,
                    params=api_params.payload,
                    headers=headers,
                    timeout=api_params.timeout,
                    )

            if response.status_code == 200:
                return APIResponse(
                    status_code=response.status_code,
                    message="success",
                    data=response.json(),
                    )
            elif 500 <= response.status_code < 600:
                logger.warning(f"{response.status_code} server error when calling {url}{retry_suffix}")
            else:
                logger.error(f"{response.status_code} client error when calling {url}")
                return APIResponse(status_code=response.status_code, message=response.text, data=None)

        except (ConnectTimeout, ReadTimeout, ConnectionError) as e:
            logger.warning(f"Connection error when calling {url}. Reason: {repr(e)}{retry_suffix}")
        finally:
            time.sleep((i + 1) * base_backoff_time)

    return APIResponse(
        status_code=500,
        message=f"Failed to invoke {url} after {api_params.max_retries} attempts.",
        )
