import json
from data_models import AnalysisRequest, AnalysisResult

if __name__ == '__main__':
    with open("clause_identification_input.json", "w") as f:
        json.dump(AnalysisRequest.model_json_schema(), f, indent=2)

    with open("clause_identification_output.json", "w") as f:
        json.dump(AnalysisResult.model_json_schema(), f, indent=2)