clause_definitions = {
    "Termination rights of third party": (
        "Provisions granting a third party, such as a counterparty to a material contract or a regulatory authority, "
        "the right to terminate the agreement upon the occurrence of specified events (e.g., change of control, assignment, "
        "breach of covenants). These clauses may require third-party consent, trigger termination fees, or invoke material "
        "adverse effect (MAE) provisions, impacting deal certainty and closing conditions."
    ),
    "Termination rights of target company": (
        "Clauses allowing the target company to terminate the merger or acquisition agreement under certain conditions, "
        "such as failure to obtain regulatory approvals, breach of representations and warranties, material adverse change, "
        "or receipt of a superior proposal (fiduciary out). These provisions may include notice requirements, reverse "
        "termination fees, and procedures for exercising termination rights."
    ),
    "Change of control": (
        "Clauses addressing the legal consequences of a change in ownership, direct or indirect, of a party to the agreement. "
        "They may trigger consent rights, acceleration of obligations, termination rights, or anti-assignment provisions. "
        "Change of control definitions often reference voting power, equity interests, or control of management, and are "
        "critical for compliance with covenants and third-party contracts."
    ),
    "Anti-assignment": (
        "Provisions restricting or prohibiting the assignment or delegation of rights and obligations under the agreement "
        "without prior written consent. These clauses may distinguish between assignment by operation of law (e.g., merger) "
        "and voluntary assignment, and often reference novation, subrogation, or successor liability to maintain contractual "
        "privity post-acquisition."
    ),
    "Non-competition or exclusivity": (
        "Clauses prohibiting the seller, its affiliates, or key personnel from engaging in competitive activities with the "
        "acquired business for a specified duration and geographic scope. These provisions may include non-circumvention, "
        "non-interference, and exclusivity covenants, and are subject to enforceability limitations under antitrust and "
        "restraint of trade laws."
    ),
    "Non-solicitation": (
        "Provisions barring the seller or related parties from soliciting, recruiting, or hiring employees, customers, or "
        "suppliers of the acquired business for a defined period post-closing. These clauses may include carve-outs for "
        "general advertising, non-targeted recruitment, or pre-existing relationships, and are often paired with liquidated "
        "damages or injunctive relief remedies."
    ),
    "Confidentiality": (
        "Clauses obligating parties to maintain the confidentiality of proprietary, non-public, or trade secret information "
        "disclosed during the transaction. These provisions may address permitted disclosures, duration of confidentiality, "
        "return or destruction of materials, and exceptions for disclosures required by law, regulation, or court order."
    ),
    "Most-favored nation": (
        "Provisions ensuring that a party receives terms, conditions, or pricing no less favorable than those offered to any "
        "other party in similar agreements. These clauses may include audit rights, notification requirements, and mechanisms "
        "for retroactive adjustment if more favorable terms are granted elsewhere."
    ),
    "Indemnification": (
        "Clauses requiring one party (indemnitor) to compensate the other (indemnitee) for losses, damages, liabilities, "
        "costs, or expenses arising from breaches of representations, warranties, covenants, or specified events. "
        "Indemnification provisions may include caps, baskets, survival periods, procedures for making claims, and exclusions "
        "for consequential or punitive damages."
    ),
    "Guarantees": (
        "Provisions under which a third party, such as a parent company, shareholder, or affiliate, guarantees the "
        "performance, payment, or obligations of a party to the agreement. Guarantees may be limited or unlimited, "
        "conditional or unconditional, and may include provisions for demand, subrogation, or waiver of defenses."
    ),
    "Notice and consent requirements": (
        "Clauses specifying the procedures, timing, and form for providing notices or obtaining consents for actions such as "
        "assignments, amendments, waivers, or regulatory filings. These provisions may reference deemed consent, cure periods, "
        "methods of delivery (e.g., email, registered mail), and requirements for written or prior notice."
    ),
    "Unusual payment obligations": (
        "Provisions imposing non-standard payment terms, such as contingent consideration (earn-outs), escrow arrangements, "
        "holdbacks, milestone payments, or deferred purchase price. These clauses may address calculation methodologies, "
        "audit rights, dispute resolution mechanisms, and conditions precedent to payment."
    ),
    }