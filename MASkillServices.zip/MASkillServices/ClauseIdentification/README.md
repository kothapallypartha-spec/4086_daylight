# Clause Skill Daylight

A service for analyzing contract clauses in documents. Takes PDF or Word documents, converts them to HTML, and identifies specific clause types like termination terms, indemnification clauses, etc.

The main deployment target is AWS Lambda, but there's also a FastAPI server for local development and testing.

## What it does

- Converts PDF and DOCX files to HTML for analysis
- Analyzes contracts to find and extract specific clause types
- Returns structured data about clause locations and content
- Handles large responses by storing them in S3 when needed

## Setup

First, get the dependencies installed. I'm using Python 3.13 but 3.10+ should work fine.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

If you prefer poetry or uv, those work too - there's a pyproject.toml file.

## Running locally

For development, run the FastAPI server:

```bash
python fastapi_server.py
```

This starts the server on localhost:8000. API docs are at http://localhost:8000/docs

## Testing

I've set up a test runner that checks everything:

```bash
python run_tests.py
```

This runs unit tests for the Lambda handler and S3 functions. The FastAPI integration tests will try to connect to localhost:8000, so start the server first to test those.

For just the Lambda handler (which is the main deployment target):

```bash
python src/python/clause_skill/tests/test_lambda_handler.py
```

## How it works

The service processes documents in a few steps:

1. **Document conversion**: PDFs and Word docs get converted to HTML using libraries like pdfplumber and python-docx
2. **Clause analysis**: The HTML gets sent to a contract analysis API that identifies clause types
3. **Response formatting**: Results are returned as JSON, either inline or stored in S3 for large responses

## Deployment

This is designed to run as an AWS Lambda function behind an Application Load Balancer. The Lambda handler automatically handles:

- Request parsing from ALB format
- Document processing pipeline
- S3 storage for responses over 900KB (ALB limit)
- Proper error handling and logging

Environment variables to set:

- `IO_BUCKET`: S3 bucket for large responses (has a default)
- `IO_LOC`: S3 prefix (defaults to "io")
- `DEBUG`: Set to "true" for more logging

## Files

- `lambda_handler.py`: Main Lambda function and ALB integration
- `clause_skill_fastapi_service.py`: FastAPI service for local development
- `data_models.py`: Pydantic models for request/response validation
- `clause_type_intelligize.py`: Contract analysis logic and API integration
- `tests/`: Test suite with unit and integration tests
