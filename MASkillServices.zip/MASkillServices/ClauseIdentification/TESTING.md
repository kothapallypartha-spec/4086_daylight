# Testing

All tests are in `src/python/clause_skill/tests/`. There are a few different types:

- `test_lambda_handler.py` - Unit tests for the main Lambda function
- `test_s3_functions.py` - Tests for S3 upload/download utilities
- `test_html_doc.py` - Integration test using the FastAPI server
- `test_docx_doc.py` - Document upload test via FastAPI

The `data/` folder has sample contract files for testing, and `output/` contains expected results.

## Running tests

Easiest way is to run everything:

```bash
python run_tests.py
```

This runs all the tests and gives a summary. For individual tests:

```bash
# Test the main Lambda handler (recommended)
python src/python/clause_skill/tests/test_lambda_handler.py

# Test S3 functions (works without AWS credentials)
python src/python/clause_skill/tests/test_s3_functions.py

# Test FastAPI endpoints (need server running first)
python src/python/clause_skill/tests/test_html_doc.py
python src/python/clause_skill/tests/test_docx_doc.py
```

For the FastAPI tests, start the server first:

Start the server first:

```bash
python fastapi_server.py
```

Then run the API tests in another terminal.

## What gets tested

The unit tests (`test_lambda_handler.py`, `test_s3_functions.py`) don't need any external services - they test the core logic and AWS integration code.

The integration tests (`test_html_doc.py`, `test_docx_doc.py`) test the full pipeline by hitting the FastAPI endpoints. These need the server running.

Sample documents are in `tests/data/` and expected outputs are in `tests/output/`. I've committed these so the tests work out of the box.
