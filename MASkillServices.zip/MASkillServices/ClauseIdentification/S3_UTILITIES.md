# S3 Utilities

The Lambda handler includes S3 functions for storing large responses that exceed the ALB limit of ~900KB. These match the patterns from other projects like 4086-due-diligence-ma. Assuming all the right IAM permissions are set.

## Available functions

**`upload_file_s3(file_content, object_name, loc=IO_LOC, bucket=IO_BUCKET)`**
Uploads content to S3 with AES256 encryption. Returns the S3 key on success.

**`delete_file_s3(object_name, loc=IO_LOC, bucket=IO_BUCKET)`**  
Deletes a file from S3. Returns (status_code, message) tuple.

**`download_file_s3(file_name, loc=IO_LOC, bucket=IO_BUCKET)`**
Downloads file content as bytes. Used internally by get_document_from_file.

**`get_document_from_file(file_name, bucket=IO_BUCKET)`**
Wrapper that downloads a document from S3. Matches the existing codebase pattern.

## Configuration

The functions use these environment variables with sensible defaults:

- `IO_BUCKET`: Main bucket for responses (defaults to 2591-contract-analysis-us-east-1-688136498438)
- `IO_LOC`: S3 prefix for organizing files (defaults to "io")
- `CLAUSE_REC_IO_BUCKET`: Separate bucket for clause recommendations (defaults to 3111-contract-analysis-us-east-1-688136498438)
- `DEBUG`: Set to "true" for more logging

Usually don't need to set since the defaults work for the production environment.

```bash
# Only set if different values are needed:
IO_BUCKET=different-bucket-name
IO_LOC=different-prefix
DEBUG=true
```

## When S3 gets used

The Lambda handler automatically stores responses in S3 when they're too big for the ALB response limit (~900KB). Large contract analysis results get uploaded to S3 and the response just contains a reference to where the data is stored.

## Local testing

The functions handle missing AWS credentials gracefully during local development - they'll return error status codes and log messages but won't crash your application. We can change this later if we want to test with right AWS permissiosns.

## Notes

These S3 functions match the patterns from other projects in the codebase. They use the same parameter names (loc, bucket), include AES256 encryption for uploads, and return consistent error codes and messages.
