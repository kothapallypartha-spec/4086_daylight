#!/usr/bin/env python3
"""
Test runner for all tests in the clause_skill/tests directory.
Runs all test_*.py files and provides a summary.
"""

import os
import sys
import subprocess
from pathlib import Path


def run_test_file(test_file_path):
    """Run a single test file and return results."""
    try:
        print(f"\n{'='*60}")
        print(f"Running: {test_file_path.name}")
        print("=" * 60)

        result = subprocess.run(
            [sys.executable, str(test_file_path)],
            capture_output=True,
            text=True,
            cwd=test_file_path.parent.parent.parent.parent,  # Go to project root
        )

        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)

        return result.returncode == 0, result.returncode

    except Exception as e:
        print(f"Error running {test_file_path.name}: {e}")
        return False, -1


def main():
    """Run all test files in the tests directory."""

    # Get the tests directory path
    current_dir = Path(__file__).parent
    tests_dir = current_dir / "src" / "python" / "clause_skill" / "tests"

    if not tests_dir.exists():
        print(f"Tests directory not found: {tests_dir}")
        return 1

    # Find all test files
    test_files = list(tests_dir.glob("test_*.py"))

    if not test_files:
        print(f"No test files found in {tests_dir}")
        return 1

    print(f"Found {len(test_files)} test files:")
    for test_file in test_files:
        print(f"  - {test_file.name}")

    # Run all tests
    results = []
    for test_file in sorted(test_files):
        success, exit_code = run_test_file(test_file)
        results.append((test_file.name, success, exit_code))

    # Print summary
    print(f"\n{'='*60}")
    print("TEST SUMMARY")
    print("=" * 60)

    passed = 0
    failed = 0

    for test_name, success, exit_code in results:
        status = "PASSED" if success else f"FAILED (exit code: {exit_code})"
        print(f"{test_name:30} {status}")
        if success:
            passed += 1
        else:
            failed += 1

    print(f"\nTotal: {len(results)} tests")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
