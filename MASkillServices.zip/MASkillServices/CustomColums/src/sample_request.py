import requests
import json

# Load the sample request data
with open('sample_request.json', 'r') as f:
    request_data = json.load(f)

# Service endpoint (adjust URL as needed)
url = "http://localhost:8001/identify-issues"  # Replace with your actual endpoint


print(request_data)

try:
    # Send POST request
    response = requests.post(
        url,
        json=request_data,
        headers={'Content-Type': 'application/json'}
    )
    
    # Print response details
    print(f"Status Code: {response.status_code}")
    print(f"Response Headers: {response.headers}")
    print(f"Response Body: {response.text}")
    
    # Check if request was successful
    if response.status_code == 200:
        print("✅ Request successful!")
        # Parse JSON response if applicable
        try:
            json_response = response.json()
            print(f"JSON Response: {json.dumps(json_response, indent=2)}")
        except json.JSONDecodeError:
            print("Response is not valid JSON")
    else:
        print(f"❌ Request failed with status code: {response.status_code}")
        
except requests.exceptions.RequestException as e:
    print(f"❌ Request error: {e}")
except FileNotFoundError:
    print("❌ sample_request.json file not found")
except json.JSONDecodeError:
    print("❌ Invalid JSON in sample_request.json")