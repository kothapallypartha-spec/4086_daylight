# Issue Identification FastAPI (Folder-Only Guide)

Minimal FastAPI service for M&A style clause / issue extraction using an internal LLM proxy.
To run the service, configure your .env, refer .env_local as example.
Make sure you are connected to VPN as the service needs acess to LLM proxy.

## Contents
```
main.py                     # FastAPI app (health + /identify-issues)
issue_identification_agent.py# Core analysis & output schemas
llm_proxy_openai.py         # LLM proxy wrapper (loads .env if present)
sample_request.json         # Example request body
sample_request.py           # Simple client script
issue_identification_test.py# Ad-hoc local file ingestion test
requirements.txt            # Dependencies
```

## Install
```bash
pip install -r requirements.txt
pip install llm-proxy --extra-index-url https://cert-proxy-api.search.use1.dev-fos.nl.lexis.com/dist/

```

## Run
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Docs: http://127.0.0.1:8000/docs  |  Health: /healthz

## Endpoint
POST /identify-issues

Request body:
```json
{
  "documents": [
    {"file_name": "Sample MSA", "content": "Full text..."}
  ],
  "new_schema": false
}
```
Set `new_schema` to true to receive flattened `clause_risks` instead of nested `data`.

## Sample (curl)
```bash
curl -X POST http://127.0.0.1:8000/identify-issues \
  -H "Content-Type: application/json" \
  -d @sample_request.json
```

## Basic Response Shapes
Default (`new_schema=false`): keys -> status, result_file, data
Flattened (`new_schema=true`): keys -> status, result_file, clause_risks

## Environment Variables
Load via `.env`:
```
cp .env_local .env
# update env accordingly
source .env
```

## Output File
Results appended to `ISSUE_RESULTS_PATH` or `issue_results.txt` in this directory.

## Notes
* Keep `.env` out of version control.
* Large documents may increase latency (model token limits apply).
* Add authentication / rate limiting before exposing externally.

