import json

from main import IdentifyRequest
from issue_identification_agent import IssueIdentificationOutput

if __name__ == '__main__':
    with open("issue_analysis_input.json", "w") as f:
        json.dump(IdentifyRequest.model_json_schema(), f, indent=2)

    with open("issue_analysis_output.json", "w") as f:
        json.dump(IssueIdentificationOutput.model_json_schema(), f, indent=2)