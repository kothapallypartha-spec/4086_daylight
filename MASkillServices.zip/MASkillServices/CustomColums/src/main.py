import math
import re
from typing import Dict, List, Set

import html2text
import urllib.request
from fastapi import FastAPI, HTTPException
from mangum import Mangum
from pydantic import BaseModel, Field

from issue_identification_agent import Document

from aws.logger import get_logger

logger = get_logger()
logger.info("Logger initialized")
app = FastAPI(title="Custom Column Boundary API")
STOPWORDS: Set[str] = {
    "the", "and", "with", "that", "this", "from", "have", "will", "shall",
    "must", "such", "here", "there", "into", "about", "between", "under",
    "over", "they", "their", "them", "your", "ours", "were", "been",
    "also", "including", "include", "within", "without", "upon", "over",
    "into", "each", "other", "which", "where", "when", "than", "more",
}
WORD_PATTERN = re.compile(r"[A-Za-z0-9]+")

class BoundaryConditionRequest(BaseModel):
    document_input: Document
    custom_column_name: str = Field(..., min_length=1, description="Name of the custom column")
    custom_column_description: str = Field(..., min_length=1, description="Business description explaining the column")
    must_include: List[str] = Field(default_factory=list, description="Optional list of required keywords")
    must_exclude: List[str] = Field(default_factory=list, description="Optional list of forbidden keywords")


class BoundaryConditionEvaluation(BaseModel):
    column_name: str
    document_name: str
    satisfied: bool
    matched_terms: List[str]
    missing_terms: List[str]
    required_terms_missing: List[str]
    excluded_terms_found: List[str]
    notes: List[str] = Field(default_factory=list)


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    return {"ok": True}
@app.post("/custom-columns/boundary-check", response_model=BoundaryConditionEvaluation)
async def evaluate_custom_column_boundary(payload: BoundaryConditionRequest) -> BoundaryConditionEvaluation:
    try:
        document = _resolve_document_content(payload.document_input)
    except Exception as exc:
        logger.exception("Failed to retrieve document for boundary check")
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    evaluation = _evaluate_boundary_condition(
        column_name=payload.custom_column_name,
        description=payload.custom_column_description,
        document=document,
        must_include=payload.must_include,
        must_exclude=payload.must_exclude,
    )
    return evaluation


handler = Mangum(app, lifespan="off")


def _resolve_document_content(document: Document) -> Document:
    if document.content:
        return document
    if not document.url:
        raise ValueError("Either content or url must be provided.")
    if re.match(".*-la-sp-upload.route53.lexis.com.*upload", document.url) and ("artifacts" not in document.url):
        logger.warning("Manipulating upload URL to point to docxhtml directly")
        document.url = document.url.replace("upload/", "upload/artifacts/")
    req = urllib.request.Request(document.url, headers=document.headers or {})
    with urllib.request.urlopen(req) as response:
        document.html_content = response.read().decode("utf-8")
    h = html2text.HTML2Text()
    document.content = h.handle(document.html_content)
    return document


def _evaluate_boundary_condition(
    *,
    column_name: str,
    description: str,
    document: Document,
    must_include: List[str],
    must_exclude: List[str],
) -> BoundaryConditionEvaluation:
    doc_text = document.content or ""
    content_tokens = _tokenize(doc_text)
    derived_terms = _derive_boundary_terms(description)
    matched_terms = sorted({term for term in derived_terms if term in content_tokens})
    missing_terms = sorted(set(derived_terms) - set(matched_terms))

    normalized_includes = sorted({term.strip().lower() for term in must_include if term.strip()})
    normalized_excludes = sorted({term.strip().lower() for term in must_exclude if term.strip()})
    required_terms_missing = [term for term in normalized_includes if term not in content_tokens]
    excluded_terms_found = [term for term in normalized_excludes if term in content_tokens]

    notes: List[str] = []
    if derived_terms:
        notes.append(f"Derived {len(derived_terms)} candidate terms from description.")
    else:
        notes.append("No derived terms from description; falling back to column name search.")

    column_present = column_name.lower() in doc_text.lower()
    if column_present:
        notes.append("Column name detected in document content.")

    satisfaction_threshold = max(1, math.ceil(len(derived_terms) * 0.6)) if derived_terms else 1
    derived_terms_satisfied = len(matched_terms) >= satisfaction_threshold if derived_terms else False

    satisfied = (
        not required_terms_missing
        and not excluded_terms_found
        and (derived_terms_satisfied or column_present)
    )

    if required_terms_missing:
        notes.append("Required terms missing from document content.")
    if excluded_terms_found:
        notes.append("Found forbidden terms in document content.")

    return BoundaryConditionEvaluation(
        column_name=column_name,
        document_name=document.file_name,
        satisfied=satisfied,
        matched_terms=matched_terms,
        missing_terms=missing_terms,
        required_terms_missing=required_terms_missing,
        excluded_terms_found=excluded_terms_found,
        notes=notes,
    )


def _derive_boundary_terms(description: str) -> List[str]:
    tokens = WORD_PATTERN.findall(description.lower())
    return sorted({token for token in tokens if len(token) > 3 and token not in STOPWORDS})


def _tokenize(text: str) -> Set[str]:
    if not text:
        return set()
    return {token.lower() for token in WORD_PATTERN.findall(text.lower())}
