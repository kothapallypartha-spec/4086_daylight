
from typing import List, Dict, Any, Optional, Type, TypeVar
from pydantic import BaseModel
from pydantic.fields import FieldInfo
from typing import get_args, get_origin, Union, Optional, List
import json
import inspect
from dotenv import load_dotenv
import os
load_dotenv()

from llm_proxy import create_simple_proxy
from llm_proxy.prompt.chat import HumanMessage
from llm_proxy.prompt import (ChatPromptTemplate, HumanMessagePromptTemplate,
                              SystemMessagePromptTemplate, AIMessagePromptTemplate)
from aws.secrets import SecretsManager

from aws.logger import get_logger
logger = get_logger()
T = TypeVar('T', bound=BaseModel)


class ChatCompletion:
    """Mimics OpenAI's ChatCompletion structure"""

    def __init__(self, parsed_result: Any):
        self.choices = [Choice(parsed_result)]


class Choice:
    """Mimics OpenAI's Choice structure"""

    def __init__(self, parsed_result: Any):
        self.message = Message(parsed_result)


class Message:
    """Mimics OpenAI's Message structure"""

    def __init__(self, parsed_result: Any):
        self.parsed = parsed_result


def extract_description(cls):
    """Return class docstring only if defined directly on the class, not inherited."""
    if "__doc__" in cls.__dict__:
        doc = cls.__doc__
        return inspect.cleandoc(doc) if doc else ""
    return None


def to_custom_json_schema(model_cls):
    def model_to_schema(cls):
        schema = {
            "title": cls.__name__,
            "type": "object",
            "description": extract_description(cls),
            "properties": {},
            "required": [],
            "additionalProperties": False
        }

        for field_name, model_field in cls.model_fields.items():
            field_type = model_field.annotation
            origin = get_origin(field_type)
            field_info: FieldInfo = model_field
            field_schema = {
                "title": field_info.title or field_name.replace("_", " ").title(),
                "description": field_info.description or "",
            }

            if origin is list:
                item_type = get_args(field_type)[0]
                if inspect.isclass(item_type) and issubclass(item_type, BaseModel):
                    field_schema["type"] = "array"
                    field_schema["items"] = model_to_schema(item_type)
                else:
                    field_schema["type"] = "array"
                    field_schema["items"] = {"type": "string"}
            elif inspect.isclass(field_type) and issubclass(field_type, BaseModel):
                field_schema.update(model_to_schema(field_type))
            else:
                field_schema["type"] = "string"

            schema["properties"][field_name] = field_schema
            schema["required"].append(field_name)  # <-- Make all fields required

        return schema

    return {
        "type": "json_schema",
        "json_schema": {
            "name": model_cls.__name__,
            "description": extract_description(model_cls),
            "schema": model_to_schema(model_cls),
            "strict": True
        }
    }


class ChatCompletions:
    """Handles chat completions with structured output parsing"""

    def __init__(self, client):
        self.client = client
        # Add completions attribute to match OpenAI structure
        self.completions = self

    def parse(self,
              model: str,
              messages: List[Dict[str, str]],
              response_format: Type[T],
              **kwargs) -> ChatCompletion:
        """
        Parse chat completion with structured output

        Args:
            model: Model name
            messages: List of message dictionaries with 'role' and 'content'
            response_format: Pydantic model class for structured output
            **kwargs: Additional arguments (ignored for compatibility)

        Returns:
            ChatCompletion object with parsed result
        """
        assert model, "Model name must be specified"
        assert response_format and inspect.isclass(response_format) and issubclass(response_format, BaseModel), \
            "response_format must be a Pydantic model class"
        anthropic = 'claude' in model.lower() or 'anthropic' in model.lower()
        system_content = ""        # for non-anthropic models, this stays empty
        prompt_messages = []
        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            
            # handle curly braces in content or llm proxy template format steps will fail
            escaped_content = content.replace("{", "{{").replace("}", "}}")

            if role == "system":
                if anthropic:
                    # save up system messages, prepend to first user message
                    system_content += escaped_content + "\n\n"
                else:
                    prompt_messages.append(SystemMessagePromptTemplate.from_template(escaped_content))
            elif role == "user":
                # system messages always precede user messages
                prompt_messages.append(HumanMessagePromptTemplate.from_template(
                    system_content + escaped_content
                ))
                system_content = ""
            elif role == "assistant":
                prompt_messages.append(AIMessagePromptTemplate.from_template(escaped_content))

        formatted_response_format = to_custom_json_schema(response_format)
        if anthropic:
            # OpenAI -> "response_format=" keyword specifies structured output
            # Anthropic -> explicit instruction instead
            prompt_messages.append(HumanMessage(
                content='Respond ONLY with valid JSON matching this schema: ' +
                json.dumps(formatted_response_format)
            ))
        args = {
            "prompt": ChatPromptTemplate.from_messages(prompt_messages),
            "model": model,
            "tenant": self.client.tenant,
            "retry": self.client.retry,
            "timeout": self.client.timeout,
            "max_tokens": 30000
        }
        if not anthropic:
            args["response_format"] = formatted_response_format

        llm = create_simple_proxy(**args)
        tracing_info = {
            "asset_id": "<4086>",
            "trans_id": "<4086 M&A due diligence - agentic issue identification>",
            "user_id": "<issue identification>",
            "user_type": "issue identification",
            "ext_info": {}
        }

        # Get the response
        response = llm.chat(tracing_info=tracing_info)

        # Parse the response into the expected Pydantic model
        # When the LLM gives a JSON response, it MIGHT be wrapped in "```json ... ```"
        if isinstance(response, str):
            response = response.strip()
            assert len(response) > 0, "Empty response from LLM for {template}"
            if response.startswith("```json"):
                response = response[7:-3].strip()
            elif response.startswith("```"):
                response = response[3:-3].strip()
            # Now we can parse the response into the expected Pydantic model
            try:
                parsed_result = json.loads(response)
            except json.JSONDecodeError:
                # Anthropic models seem to create malformed JSON
                raise ValueError(response)
        else:
            parsed_result = response_format.model_validate(response)

        return ChatCompletion(parsed_result)


class OpenAILikeClient:
    """
    A wrapper around create_simple_proxy that provides an OpenAI-like interface
    """

    def __init__(self,
                 model_name: str = os.getenv("GPT_4_1_MINI", ""),
                 retry: int = 1,
                 timeout: int = 300):
        assert model_name, "Model name must be specified"
        self.model_name = model_name
        ASSET_ID = os.getenv("ASSET_ID", "3363")
        ASSET_GROUP = os.getenv("AssetGroup", "ddc1c")
        assert ASSET_ID, "ASSET_ID environment variable must be set"
        assert ASSET_GROUP, "AssetGroup environment variable must be set"
        # When deploying via Jenkins pipeline, we pick this up from the template
        # but when running locally, we need the default
        # Infrastructure/releaseECRLambda_ddc1c.template
        #     SECRET_NAME: !Sub /AssetID_3363/ddc4c/rag-workflows-secret
        secret_name = os.getenv(
            "SECRET_NAME",
            "/AssetID_3363/ddc4c/rag-workflows-secret"
        )
        logger.info(f"Fetching secrets from {secret_name}")
        secrets_mgr = SecretsManager(
            secret_name=secret_name,
            region_name='us-east-1'
        )
        tenant = secrets_mgr.get_secret('LLM_PROXY_TENANT')
        assert tenant, "Tenant must be specified"
        self.tenant = tenant
        self.retry = retry
        self.timeout = timeout
        self.chat = ChatCompletions(self)


# Convenience function to create a client instance
def OpenAI_Like(**kwargs) -> OpenAILikeClient:
    """
    Create an OpenAI-like client instance

    Args:
        **kwargs: Configuration options for the client

    Returns:
        OpenAILikeClient instance
    """
    return OpenAILikeClient(**kwargs)


# example usage of the OpenAI_Like client
def example_usage():
    class ClauseAnalysis(BaseModel):
        """
        Represents a single legal clause extracted from a document,
        along with a corresponding issue or risk identified during M&A due diligence.

        Attributes:
            clause_text (str): The full, extracted text of the legal clause.
            issue_or_risk (str): A detailed and extractive description of the legal, financial, or operational
                issue or risk identified in the clause. Should reflect potential impact on the deal.
        """
        clause_text: str
        issue_or_risk: str

    client = OpenAI_Like()

    # Define the messages for the chat completion
    messages = [
        {"role": "system", "content": "You are an expert in M&A legal due diligence."},
        {"role": "user", "content": "Analyze the provided documents for issues and risks."}
    ]

    # Parse the chat completion with structured output
    response = client.chat.parse(
        model="gpt-4.1-mini",
        messages=messages,
        response_format=ClauseAnalysis
    )

    # Print the parsed results
    print(response.choices[0].message.parsed)

#example_usage()
