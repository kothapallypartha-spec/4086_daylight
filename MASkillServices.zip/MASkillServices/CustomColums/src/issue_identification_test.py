from issue_identification_agent import Document, issue_identification_agent

print(issue_identification_agent)

import os
from typing import Iterable, List, Dict, Optional

def read_files(file_paths: Iterable[str], encodings: Optional[Iterable[str]] = None) -> List[Dict[str, str]]:
    """
    Reads a list of text files, trying multiple encodings.
    Returns: [{"file_name": <basename>, "content": <text>}, ...]
    """
    if encodings is None:
        # Order matters: try the most likely first
        encodings = ("utf-8", "utf-8-sig", "utf-16", "cp1252", "latin-1")

    results: List[Dict[str, str]] = []
    print("Retrieving documents for further analysis...\n")

    for file_path in file_paths:
        tried = []
        try:
            for enc in encodings:
                try:
                    with open(file_path, "r", encoding=enc) as f:
                        content = f.read()
                    print(f"✓ Successfully read document: {file_path} (encoding={enc})")
                    results.append({
                        "file_name": os.path.basename(file_path),
                        "content": content
                    })
                    break  # stop trying encodings for this file
                except UnicodeDecodeError:
                    tried.append(enc)
                    continue
            else:
                # ran out of encodings without success
                print(f"✗ Could not decode {file_path} with encodings: {', '.join(tried)}")
        except FileNotFoundError:
            print(f"⚠ File not found: {file_path}")
        except PermissionError:
            print(f"⚠ Permission denied: {file_path}")
        except OSError as e:
            print(f"⚠ OS error reading {file_path}: {e}")

    return results

folder_path = "/Users/zhangz9/Data/parley_pro_sample"
from pathlib import Path
from typing import List

def list_files(folder: str, recursive: bool = False, include_hidden: bool = False) -> List[str]:
    """
    Return a sorted list of file paths inside `folder`.

    Args:
        folder: Path to the folder.
        recursive: If True, include files in subfolders.
        include_hidden: If True, include dotfiles (e.g., .DS_Store).

    Raises:
        NotADirectoryError: If `folder` is not a directory.
    """
    p = Path(folder).expanduser().resolve()
    if not p.is_dir():
        raise NotADirectoryError(f"Not a directory: {p}")

    pattern = "**/*" if recursive else "*"
    files = [
        str(f)
        for f in p.glob(pattern)
        if f.is_file() and (include_hidden or not f.name.startswith("."))
    ]
    return sorted(files)

file_paths = list_files(folder_path, recursive=True, include_hidden=False)

documents = read_files(file_paths[13:14])

# result = issue_identification_agent(documents)
result = None    # Placeholder to make SonarQube quit complaining
