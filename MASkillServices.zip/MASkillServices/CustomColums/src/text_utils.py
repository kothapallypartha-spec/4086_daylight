import re

from lxml import etree
from bisect import bisect_left, bisect_right

import difflib
import logging

logger = logging.getLogger(__name__)

CONTRACT_PARSER_URL = "https://cdc1c-get-answers.route53.lexis.com/contract-analysis/"
XML_HEADER = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\"?><!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\">"

def custom_tokenizer(sentence: str):
    tokenization_chars = set(re.sub(r"[\sA-Za-z0-9\u00C0-\u017F]+", "", sentence))
    if type(sentence) == float: return []
    if len(sentence) == 0: return []
    split_regex = r'|'.join(['(' + re.escape(x) + ')' for x in tokenization_chars])
    if split_regex:
        split_regex += '|'
    split_regex += '(\s+)'
    splits = re.split(split_regex, sentence)
    tokens = [y for y in splits if y and y.strip()]

    return tokens

def filter_xml_tags(xml_text: str) -> str:
    no_tag_text = re.sub(r'<[^<]+>', lambda m: " " * len(m.group()), xml_text)
    return no_tag_text

def get_token_positions(tokens, text):
    alignments = []
    current_offset = 0
    for token in tokens:
        try:
            word_offset = text.index(token, current_offset)
            start_position = word_offset
            end_position = start_position + len(token) - 1
            alignments.append((token, start_position, end_position))
            current_offset = word_offset + len(token)
        except ValueError:
            continue
    return alignments

def get_all_xpaths(html_content, filter_tag="//*"):
    """
    Extract non-overlapping (outermost) XPaths from an HTML document

    Args:
        html_content: HTML content as string

    Returns:
        List of non-overlapping XPaths
    """
    # Parse the HTML content
    parser = etree.HTMLParser()
    tree = etree.fromstring(html_content, parser)

    # Create ElementTree to use getpath
    tree_with_getpath = etree.ElementTree(tree)

    # Get all elements
    all_elements = tree.xpath(filter_tag)

    distinct_elements = []
    for element in all_elements:
        # Get the direct text content of this element (excluding child element text)
        element_text = ' '.join(element.itertext())

        if element_text.strip() and (element_text not in distinct_elements):
            distinct_elements.append((element_text, tree_with_getpath.getpath(element)))

    return distinct_elements

def match_clauses_to_xpaths(clauses, all_xpaths_info, ref_alignments):

    ref_tokens = [t for t, _, _ in ref_alignments]
    for clause in clauses:
        clause_tokens = custom_tokenizer(clause["clause_text"])
        matcher = difflib.SequenceMatcher(None, ref_tokens, clause_tokens, autojunk=False) # get longest possible matches
        match_blocks = matcher.get_matching_blocks()
        longest_blocks = merge_blocks(match_blocks, min_gap=1, min_size=2)

        clause["clause_xpath"] = []
        clause["start_index"] = ref_alignments[-1][2] + 1
        clause["end_index"] = -1
        for block_id, block in enumerate(longest_blocks):
            # if block.size <= 10:
            #     continue
            start_idx = block.a
            end_idx = block.a + block.size - 1
            start_pos = ref_alignments[start_idx][1]
            end_pos = ref_alignments[end_idx][2]


            # Find all xpaths that overlap with this range
            for s, xpath, st, en, tokens in all_xpaths_info:
                if ((st <= start_pos < en) or (st < end_pos <= en)) and (xpath not in clause["clause_xpath"]):
                    clause["clause_xpath"].append(xpath)
                    clause["start_index"] = min([clause["start_index"], start_pos])
                    clause["end_index"] = max([clause["end_index"], end_pos])


def get_start_end_positions(sentences, ref_sentence, ref_alignments=None):
    # First pass: Align ref_sentence with itself
    if not ref_alignments:
        ref_sentence_tokens = custom_tokenizer(ref_sentence)
        ref_alignments = get_token_positions(ref_sentence_tokens, ref_sentence)


    # Second pass: Iterate over sentence_tokens to pick the right slice from ref_alignments
    alignments = [None] * len(sentences)
    sub_alignments = []
    current_offset = 0
    previous_word_offset = -1
    previous_token = None
    ref_tokens = [t for t, _, _ in ref_alignments]

    for i, sentence in enumerate(sentences):
        last_sentence_start = len(sub_alignments)
        sentence_tokens = custom_tokenizer(sentence)

        for token in sentence_tokens:
            try:
                word_offset = ref_tokens.index(token, current_offset)

            except ValueError:
                word_offset = previous_word_offset + 1

            try:
                start_position = ref_alignments[word_offset][1]
            except Exception:
                start_position = ref_alignments[previous_word_offset + 1][1] if previous_word_offset + 1 < len(ref_alignments) else -1
            if token:
                sub_alignments.append((token, start_position, start_position + len(token) - 1, True))

            if (previous_token is not None) and word_offset - 1 == previous_word_offset:
                sub_alignments[-2] = (sub_alignments[-2][0], sub_alignments[-2][1], sub_alignments[-2][2], False)

            current_offset = word_offset + 1
            previous_word_offset = current_offset - 1
            previous_token = token

            if len(sentence.strip()) > 0:
                sub_alignments[-1] = (sub_alignments[-1][0], sub_alignments[-1][1], sub_alignments[-1][2], True)

        if sub_alignments[last_sentence_start][1] > sub_alignments[-1][2]:
            logger.warning("Something went wrong in alignment detection.")
        alignments[i] = (sub_alignments[last_sentence_start][1] if sub_alignments else -1, sub_alignments[-1][2] if sub_alignments else -1)

    return alignments

def get_tokens_in_range(ref_alignments, st, en):
    # ref_alignments: list of (token, start, end)
    starts = [start for _, start, _ in ref_alignments]
    ends = [end for _, _, end in ref_alignments]

    left = bisect_left(ends, st)
    right = bisect_right(starts, en)
    return [t for t, t_st, t_en in ref_alignments[left:right] if t_st >= st and t_en <= en]


def extract_text_from_xpaths(tree, xpaths):
    texts = []
    for xpath in xpaths:
        elements = tree.xpath(xpath)
        for elem in elements:
            texts.append(' '.join(elem.itertext()))
    return texts

def merge_blocks(blocks, min_gap=1, min_size=2):
    merged = []
    for block in blocks:
        if block.size < min_size:
            continue
        if merged and (block.a - (merged[-1].a + merged[-1].size) <= min_gap) and (block.b - (merged[-1].b + merged[-1].size) <= min_gap):

            last = merged.pop()
            new_size = last.size + (block.a - (last.a + last.size)) + block.size
            merged.append(difflib.Match(last.a, last.b, new_size))
        else:
            merged.append(block)
    return merged

def deduce_matching_xpaths(html_content, clauses, debug=False):

    logger.info("Filtering XML tags from the content...")
    cleaned_content = filter_xml_tags(html_content)

    logger.info("Tkenizing the cleaned content...")
    ref_sentence_tokens = custom_tokenizer(cleaned_content)
    ref_alignments = get_token_positions(ref_sentence_tokens, cleaned_content)

    logger.info("Extracting all XPaths from the HTML content...")
    all_xpaths = get_all_xpaths(html_content, filter_tag="/html/body//p | /html/body//ol")

    logger.info("Getting start and end positions for all XPaths...")
    alignments = get_start_end_positions([text for text, _ in all_xpaths], cleaned_content, ref_alignments)

    logger.info("Matching clauses to XPaths...")
    all_xpath_info = [(s, xpath, st, en) for (s, xpath), (st, en) in zip(all_xpaths, alignments)]
    all_xpath_info = [
        (s, xpath, st, en, get_tokens_in_range(ref_alignments, st, en))
        for s, xpath, st, en in all_xpath_info
        ]

    match_clauses_to_xpaths(clauses, all_xpath_info, ref_alignments)

    parser = etree.HTMLParser()
    tree = etree.fromstring(html_content, parser)

    logger.info("Verifying matched XPaths by extracting texts...")
    if not debug:
        return
    for clause in clauses:
        clause["checks"] = {
            "matched_xpath_texts":  extract_text_from_xpaths(tree, clause["clause_xpath"]),
            "extracted_html_snippet": html_content[clause["start_index"]:clause["end_index"]] if ("start_index" in clause and "end_index" in clause) else ""
            }

