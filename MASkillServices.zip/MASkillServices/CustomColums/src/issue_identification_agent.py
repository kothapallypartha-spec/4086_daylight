import os

from text_utils import deduce_matching_xpaths
from llm_proxy_openai import OpenAI_Like
from pydantic import BaseModel, Field
from typing import List, Any, Optional
import json
from aws.logger import get_logger


logger = get_logger()

DEBUG = os.getenv("DEBUG", "false").lower() == "true"

# Request document model
class Document(BaseModel):
    file_name: str = Field(..., description="Document title or filename")
    content: str | None = Field(None, description=
        "Full textual content of the document (optional if URL is provided)")
    url: str | None = Field(None, description=
        "Pre-signed URL to the original document (optional if content is provided)")
    headers: dict | None = Field({}, description="Optional headers for HTTP requests")
    html_content: str | None = Field("", description="HTML content of the document")

    @classmethod
    def validate(cls, value):
        if not value.get('content') and not value.get('url'):
            raise ValueError("Either 'content' or 'url' must be provided.")
        return value


# granular issue/risk model
class IssueOrRisk(BaseModel):
    """Single issue/risk linked to a clause.
    description: Extractive concise statement of the risk/issue.
    implications: Legal / financial / strategic consequences.
    impacts: Deal areas potentially affected (e.g. valuation, indemnities).
    recommendations: Actionable next steps / follow-up diligence / remediation."""
    description: str
    implications: List[str]
    impacts: List[str]
    recommendations: List[str]


class ClauseCheck(BaseModel):
    matched_xpath_texts: List[str] | None = None
    extracted_html_snippet: str | None = None


# clause analysis model
class ClauseAnalysisWithoutOffsets(BaseModel):
    """Extracted contractual clause with classification and associated issues/risks that
    may affect the M&A transaction or post-close obligations.
    clause_text: Full quoted clause text (verbatim) from source document.
    clause_type: Normalized category (e.g. Termination, Indemnity, Change of Control).
    issue_or_risk: Structured list of identified IssueOrRisk objects
    associated with the clause that may affect the transaction or post-close obligations."""
    document_name: str
    clause_text: str
    clause_type: str
    issue_or_risk: List[IssueOrRisk]

class ClauseAnalysis(ClauseAnalysisWithoutOffsets):
    clause_xpath: Optional[List[str]] = Field([], description="matching xpath expressions")
    start_index: Optional[int] = Field(-1)
    end_index: Optional[int] = Field(-1)
    checks: Optional[ClauseCheck] = Field(None)


class IssueIdentificationOutputWithoutOffsets(BaseModel):
    """Per-document M&A due diligence analysis output.
    document_name: Source document filename.
    clauses: List of analyzed clauses with linked structured risks."""
    document_name: str
    clauses: List[ClauseAnalysisWithoutOffsets]

# Updated output model (per document)
class IssueIdentificationOutput(BaseModel):
    """Per-document M&A due diligence analysis output.
    document_name: Source document filename.
    clauses: List of analyzed clauses with linked structured risks."""
    document_name: str
    clauses: List[ClauseAnalysis]


def issue_identification_agent(
        doc: Document, *, model_name: str, context: Any = None
    ) -> IssueIdentificationOutput:
    logger.info(f"Starting issue identification with model: {model_name}")

    issue_identification_system_prompt = (
        "You are a professional Merger and Acquisition (M&A) legal due "
        "diligence expert, your job is to "
        "1. Carefully analyze these documents from the data room, "
        "uploaded by the customer company. "
        "2. Fully understand the context of the document for "
        "legal M&A due diligence analysis. "
        "3. Extract full clauses, identify issues, risks,"
        " that may affect the transaction or post-close obligations. "
        "4. Think through the task and make a plan "
        "to execute the task like a pro! \n"
        "Note: "
        "Describe the issues and risks in detail and in an extractive manner. "
        "Use declarative findings grounded in deal facts when identifying issues and risks, "
        "avoid issues and risks that are hypothetical in nature, such as if/potential/may/might/could, etc. "
        "Your analysis should be thorough and comprehensive. "
        "Clarity and accuracy are critical, your findings must be "
        "supported by the provided documents. "
        "For each clause, identify issues/risks. For every issue/risk provide: "
        "1) description (extractive and concise), "
        "2) implications (legal/financial/strategic), "
        "3) impacts (areas of the deal affected), "
        "4) recommendations (actionable next steps). "
        "Use complete sentence as it is in the original document,and avoid using '...' for omission."
        "Output is a JSON object per document, for example:\n"
        "{document_name: \"Sample Document\",\n"
        " clauses: [\n"
        "   {clause_text: \"This is a sample clause.\",\n"
        "    clause_type: \"Sample\",\n"
        "    issue_or_risk: [\n"
        "      {description: \"Potential issue with this clause.\",\n"
        "       implications: [\"Legal risk\"],\n"
        "       impacts: [\"Valuation\"],\n"
        "       recommendations: [\"Review clause\"]}\n"
        "    ]}\n"
        " ]\n"
        "}\n"
    )

    client = OpenAI_Like(model_name=model_name, timeout=300)

    safe_content = json.dumps(doc.content)

    user_prompt = (
        f"Analyze the following document for legal M&A due diligence:\n"
        f"Document Name: {doc.file_name}\n"
        f"Content:\n{safe_content}\n"
        "Return ONLY valid JSON matching the schema."
    )

    messages = [
        {"role": "system", "content": issue_identification_system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    logger.info("Identifying risks in the document")
    completion = client.chat.parse(
        model=model_name,    # "gpt-4.1",
        messages=messages,
        response_format=IssueIdentificationOutputWithoutOffsets
    )
    result: IssueIdentificationOutputWithoutOffsets = completion.choices[0].message.parsed
    if isinstance(result, dict):
        result = IssueIdentificationOutputWithoutOffsets.model_validate(result)

    for clause in result.clauses:
        issue_count = len(clause.issue_or_risk) if clause.issue_or_risk else 0
        logger.info(
            "Document='%s' ClauseType='%s' Issues=%d",
            result.document_name,
            clause.clause_type,
            issue_count,
        )

    clauses = [item.model_dump() for item in result.clauses]

    deduce_matching_xpaths(doc.html_content, clauses=clauses, debug=DEBUG)

    clause_risks = []
    for clause in clauses:
        risk = ClauseAnalysis(
            document_name=result.document_name,
            clause_text=clause["clause_text"],
            clause_type=clause["clause_type"],
            clause_xpath=clause["clause_xpath"] if "clause_xpath" in clause else [],
            start_index=clause.get("start_index", -1),
            end_index=clause.get("end_index", -1),
            checks=clause.get("checks", None),
            issue_or_risk=[IssueOrRisk(
                description=issue["description"],
                implications=issue["implications"],
                impacts=issue["impacts"],
                recommendations=issue["recommendations"]
            ) for issue in clause["issue_or_risk"]
                ]
        )
        clause_risks.append(risk)

    new_result = IssueIdentificationOutput(
        document_name=result.document_name,
        clauses=clause_risks
        )

    return new_result

