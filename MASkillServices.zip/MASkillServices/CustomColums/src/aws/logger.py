import os
import sys
import logging

DEBUG = os.environ.get("DEBUG", "0").lower() in ("1", "true", "yes")

_logger = None


def get_logger():
    global _logger
    if not _logger:
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)
        logging.basicConfig(
            level=logging.DEBUG if DEBUG else logging.INFO,
            format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
            stream=sys.stderr
        )
        _logger = logging.getLogger()
        _logger.info("Logger initialized")
        logging.getLogger("botocore.hooks").setLevel(logging.WARNING)
        logging.getLogger("botocore.endpoint").setLevel(logging.WARNING)
        logging.getLogger("botocore.utils").setLevel(logging.WARNING)
        logging.getLogger("botocore.auth").setLevel(logging.WARNING)
        logging.getLogger("botocore.credentials").setLevel(logging.WARNING)
        logging.getLogger("botocore.loaders").setLevel(logging.WARNING)
        logging.getLogger("botocore.client").setLevel(logging.WARNING)
        logging.getLogger("botocore.regions").setLevel(logging.WARNING)
        logging.getLogger("botocore.httpsession").setLevel(logging.WARNING)
        logging.getLogger("botocore.parsers").setLevel(logging.WARNING)
        logging.getLogger("botocore.retryhandler").setLevel(logging.WARNING)
        logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)
    return _logger
