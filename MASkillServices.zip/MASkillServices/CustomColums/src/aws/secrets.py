import boto3
import json
from .logger import get_logger
logger = get_logger()

class SecretsManager:
    def __init__(self, secret_name, region_name , profile=None):
        logger.info(f"Initializing SecretsManager for secret: {secret_name} in region: {region_name}")
        self.secret_name = secret_name
        self.region_name = region_name
        self.secrets = self._get_aws_secret(profile)

    def _get_aws_secret(self, profile):
        session = boto3.Session(profile_name=profile) if profile else boto3.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=self.region_name
        )
        logger.info(f"Retrieving secret {self.secret_name}")
        get_secret_value_response = client.get_secret_value(SecretId=self.secret_name)
        secret = get_secret_value_response['SecretString']
        try:
            return json.loads(secret)
        except Exception as e:
            logger.exception(e)
            raise RuntimeError(f"Failed to parse secrets JSON for secret_name: {self.secret_name}: {e}")

    def get_secret(self, key):
        value = self.secrets.get(key)
        if value is None:
            raise KeyError(f"Secret key '{key}' not found or value is None.")
        return value