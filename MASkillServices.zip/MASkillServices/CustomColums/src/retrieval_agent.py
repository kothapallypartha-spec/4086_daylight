import time

def retrieve_documents_for_ma_due_diligence(document_profile: str, table_of_contents: str):
    # step 1: generate a document request list based on the document profile
    document_request_list_prompt = (
        "You are a professional Merger and Acquisition (M&A) legal due diligence expert. "
        "You are provided a document profile, which includes "
        "the title, category, summary, metadata, clauses, "
        "potential issues, and relevance of this document."
        "Your job is to: \n"
        "1. determine if you need additional documents to combine "
        "with this given one to help you thoroughly "
        "identify risks and issues, especially deal breakers that may impact this deal. \n"
        "2. if you need additional documents, draft a document request list. \n"
        "3. Be concise and clear.\n"
        "Output format: \n"
        "Document request list: \n"
    )

    from openai import OpenAI
    import json
    import os
    from typing import List, Dict, Any
    from llm_proxy_openai import OpenAI_Like

    t1 = time.time()

    client = OpenAI_Like()

    from pydantic import BaseModel

    class DocumentRequestOutput(BaseModel):
        """
        A Pydantic model representing the output structure for drafting a document request list
        in M&A legal due diligence.

        Attributes:
            document_request_list (str): A string containing the drafted document request list.
        """
        document_request_list: str

    user_prompt = (
        "Here is the document profile you need to analyze: \n"
        f"{document_profile},\n\n"
    )

    # todo: safe string formatting
    user_prompt = user_prompt.replace('{', '{{').replace('}', '}}')
    #print(user_prompt)

    messages = [
        {"role": "system", "content": document_request_list_prompt},
        {"role": "user", "content": user_prompt},
    ]
    print("Thinking: \n"
          "User wants to retrieve related documents for thorough M&A due diligence analysis. \n"
          )
    completion = client.chat.parse(
        model="gpt-4.1",
        messages=messages,
        response_format=DocumentRequestOutput
    )
    result = completion.choices[0].message.parsed
    print("Document request list generated: \n")
    print(result.document_request_list)
    document_request_list = result.document_request_list

    # step 2: retrieve documents based on the document request list and table of contents
    retrieval_prompt = (
        "You are a professional Merger and Acquisition M&A legal "
        "due diligence expert. You are provided a document request "
        "list that describes the documents needed for a thorough "
        "analysis. You are also provided a table of contents for "
        "all the documents that the customer company have uploaded. "
        "Your job is to carefully check if there are any documents "
        "in the table of contents that match the request list. If "
        "so, extract the top 3 document paths and names "
        "(Do not modify the path), and return "
        "them in a structured format. Also state documents that are "
        "requested but not found in the table of content. \n\n"
        "Matching documents:\n"
        "1. Document path:\n"
        "2. Document path\n\n"
        "Missing documents:\n"
    )


    from pydantic import BaseModel
    from typing import List

    class RetrievalOutput(BaseModel):
        """
        A Pydantic model representing the output structure for document retrieval in M&A legal due diligence.

        Attributes:
            matching_documents (List[str]): A list of document paths that match the document request list.
            missing_documents (List[str]): A list of document names or descriptions that are missing from the provided documents.
        """
        matching_documents: List[str]
        missing_documents: List[str]

    user_prompt = (
        f"Here is the document request list:\n"
        f"{document_request_list}\n\n"
        f"Here is the table of contents of all the documents "
        f"provided by the customer company:\n"
        f"{table_of_contents}\n"
    )
    user_prompt = user_prompt.replace('{', '{{').replace('}', '}}')

    messages = [
        {"role": "system", "content": retrieval_prompt},
        {"role": "user", "content": user_prompt},
    ]

    completion = client.chat.parse(
        model="gpt-4.1",
        messages=messages,
        response_format=RetrievalOutput
    )
    result = completion.choices[0].message.parsed
    print("Here are the matching documents and missing documents based on the request list and table of contents: \n")
    print("Matching Documents:")
    print(result.matching_documents)
    print("Missing Documents:")
    print(result.missing_documents)

    # add the document profile to the matching documents
    result.matching_documents.append(document_profile['document_path'])
    print("All documents to be retrieved for analysis: \n")
    print(result.matching_documents)
    documents_to_retrieve = list(set(result.matching_documents))

    # step 3: retrieve the documents based on the matching documents paths
    def retrieve_documents(file_paths: list) -> list:
        """
        Request and read additional documents for analysis.

        Args:
            file_paths: A list of absolute paths to the document files.

        Returns:
            A list of dictionaries, each containing the file name and its content or an error message.
        """
        results = []
        print("Retrieving documents for further analysis...\n")
        for file_path in file_paths:
            try:
                # Support multiple encodings to handle various file formats
                encodings = ['utf-8']

                for encoding in encodings:
                    try:
                        with open(file_path, 'r', encoding=encoding) as f:
                            content = f.read()
                        print(f"✓ Successfully read document: {file_path}")
                        results.append({"file_name": os.path.basename(file_path), "content": content})
                        break
                    except UnicodeDecodeError:
                        continue
                else:
                    # If all encodings fail
                    results.append({"file_name": os.path.basename(file_path),
                                    "content": f"Error: Could not read file {file_path} with any supported encoding"})

            except FileNotFoundError:
                results.append({"file_name": os.path.basename(file_path),
                                "content": f"Error: File not found at path {file_path}"})
            except Exception as e:
                results.append({"file_name": os.path.basename(file_path),
                                "content": f"Error reading file {file_path}: {str(e)}"})

        return results

    retrieved_documents = retrieve_documents(documents_to_retrieve)
    t2 = time.time()
    print(f"Retrieved all documents in {t2 - t1:.2f} seconds.")
    return retrieved_documents
