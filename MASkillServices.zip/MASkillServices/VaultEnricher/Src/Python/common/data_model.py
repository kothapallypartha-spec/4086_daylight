import json
import traceback
import os
from typing import List, Literal

from pydantic import BaseModel, Field, field_validator

MODEL_NAME = os.getenv("MODEL_NAME", "anthropic-claude-3-7-sonnet-20250219_Daylight_3363_nonprod")

class InputModel(BaseModel):
    filename_stem: str = Field(..., description="The document identifier (no file extension)")
    content: str | None = Field(None, description=
    "Full textual content of the document (optional if pre-signed URL is provided)")
    url: str | None = Field(None, description=
    "URL to the original document (optional if content is provided)")
    model_name: str = Field(MODEL_NAME, description="The name of the model to use for processing")
    headers: dict | None = Field(None, description="Optional headers for HTTP requests")

    @classmethod
    def validate(cls, value):
        if not value.get('content') and not value.get('presigned_url'):
            raise ValueError("Either 'content' or 'presigned_url' must be provided.")
        return value


class DocumentProfile(BaseModel):
    title: str = Field(..., description="Clear and descriptive title based on document content")
    parties: List[str] = Field(..., description="List of parties involved in the document")
    date: str = Field(..., description="Date of the document")
    jurisdiction: str = Field(..., description="Jurisdiction applicable to the document")
    summary: str = Field(..., description="Concise summary of document's purpose and key contents (3-5 sentences)")
    relevance: Literal["High", "Medium", "Low"] = Field(..., description="Document relevance to M&A due diligence (High/Medium/Low)")


class Headers(BaseModel):
    ContentType: str = Field("application/json", description="Content type of the response.", alias="Content-Type")
    AccessControlAllowOrigin: str = Field("*", description="CORS header to allow all origins.", alias="Access-Control-Allow-Origin")
    AccessControlAllowMethods: str = Field("OPTIONS,POST", description="CORS header to allow specific methods.", alias="Access-Control-Allow-Methods")
    AccessControlAllowHeaders: str = Field("*", description="CORS header to allow all headers.", alias="Access-Control-Allow-Headers")

class Result(BaseModel):
    statusCode: int = Field(200, description="HTTP status code of the response.")
    headers: Headers = Field(default_factory=Headers, description="HTTP headers for the response.")
    body: str = Field(..., description="Detailed predicted document categories or labels as a JSON string.")

    @field_validator("body")
    def validate_body(cls, v):
        try:
            data = json.loads(v)
            DocumentProfile.model_validate(data)
        except Exception as e:
            raise ValueError(f"body is not valid: {e}")
        return v


class ErrorResponse(BaseModel):
    body: str = Field(..., description="Error message")
    headers: Headers = Field(default_factory=Headers, description="HTTP headers for the response.")
    traceback: str = Field(..., description="Traceback of the error")
    statusCode: int = Field(500, description="HTTP status code")

    @classmethod
    def from_exception(cls, e: Exception, statusCode=500) -> "ErrorResponse":
        import traceback
        tb = traceback.format_exception(type(e), e, e.__traceback__)
        return cls(body=str(e), traceback="".join(tb), statusCode=statusCode)

    @classmethod
    def from_error_message(cls, error: str, statusCode: int = 500) -> "ErrorResponse":
        return cls(body=error, traceback="", statusCode=statusCode)