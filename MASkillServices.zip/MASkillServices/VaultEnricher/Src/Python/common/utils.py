import base64
import datetime
import json
import logging

import logging
import os
import time
from copy import copy
from pathlib import Path
from typing import Dict, Optional, Tuple
from lxml import etree

import boto3
import requests
from botocore.config import Config
from pydantic import BaseModel

logger = logging.getLogger(__name__)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(filename)s:%(lineno)d - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)
logger.propagate = False


def get_day_earliest_and_latest(year, month, day, start_hour, end_hour):
    date = datetime.date(year, month, day)
    earliest = date.strftime(f"%m/%d/%Y:{start_hour:02d}:00:00")
    latest = date.strftime(f"%m/%d/%Y:{end_hour:02d}:00:00")
    return earliest, latest


def get_splunk_query(SPLUNK_QUERY, earliest, latest):
    search_query = SPLUNK_QUERY.replace("{earliest}", earliest).replace("{latest}", latest)
    return search_query

def pre_signed_url_output(file_name):
    """
    Upload file to S3 and generate pre-signed URL for access.
    Uses real AWS S3 (not LocalStack).
    """
    retry_config = Config(
        retries={
            'max_attempts': 5,
            'mode': 'standard'
            }
        )

    bucket_name = "11346-due-diligence-ma-164682029196"
    s3_client = boto3.client('s3', config=retry_config)

    key = 'presigned_urls/' + os.path.basename(file_name)
    logger.info(f"Uploading {file_name} to s3://{bucket_name}/{key}")

    s3_client.upload_file(file_name, Bucket=bucket_name, Key=key)

    pre_signed_url = s3_client.generate_presigned_url(
        ClientMethod="get_object",
        Params={'Bucket': bucket_name, 'Key': key},
        ExpiresIn=3600
        )
    logger.info(f"Generated pre-signed URL: {pre_signed_url}")

    return pre_signed_url


class DocFileModel(BaseModel):
    document_display_name: str
    upload_identifier: str
    session_identifier: str
    upload_link: str
    document_page_count: Optional[int] = None
    document_character_count: Optional[int] = None



class FileUploader:
    CREATE_SESSION_PATH = "f/up/v1/session"
    DELETE_SESSION_PATH = "f/up/v1/session/{}"

    UPLOAD_FILE_PATH = "f/up/v1/{}/upload/file"
    UPLOAD_STATUS_PATH = "f/up/v1/{}/upload/{}/status"

    GET_DOCX_URL = "f/up/v1/{}/upload/{}/docx"
    GET_DOCX_HTML_URL = "f/up/v1/{}/upload/{}/docxhtml"
    GET_TEXT_URL = "f/up/v1/{}/upload/{}/text"
    GET_ALL_DOCX_HTML_URL = "f/up/v1/{}/upload/docxhtml"

    def __init__(self):
        asset_group = "cdc7c"
        self.base_url = f"https://{asset_group}-la-sp-upload.route53.lexis.com/"
        self.session_attrs = None
        self.headers = self.get_wam_headers() # self.get_wam_headers()

    def get_headers(self, content_type=True, accept=True):
        headers = copy(self.headers)
        if content_type:
            headers["Content-Type"] = "application/json"
        if accept:
            headers["Accept"] = "application/json"
        return headers

    @staticmethod
    def get_wam_headers():
        user_id = "LNGAST004481@Service2Service"
        password =  "Pwd4481LN"
        auth_token_header = FileUploader._get_auth_token_header(user_id, password)
        request_token_header = FileUploader._get_request_token()

        application_token_header = FileUploader._post_req1_get_app_token(auth_token_header, request_token_header)
        session_token_header = FileUploader._post_req2_get_sess_token(
            auth_token_header, request_token_header, application_token_header, user_id
            )

        assert session_token_header, "Failed to get session headers"

        return {
            "X-LN-Validate-Output": "true",
            "X-LN-Application": application_token_header.decode('utf-8'),
            "X-LN-Request": request_token_header,
            "X-LN-Session": session_token_header.decode('utf-8'),
            }

    @staticmethod
    def _get_auth_token_header(user_id, password):
        user_id = user_id.split("@")[0]
        credentials_str = f"{user_id}:{password}"
        username_password = bytes(credentials_str, "utf8")
        username_password_b64 = base64.b64encode(username_password).decode("utf-8")
        return f"Basic {username_password_b64}"

    @staticmethod
    def _get_request_token(tok1_ctx_feat_perm_id="1541499"):
        token_url = "http://services.lexisnexis.com/xmlschema/request-token/1"
        tok1_transx_id = "476d9a4c-4c55-dc47-877f-23beed4b2aa9"
        tok1_client_id = "test client"
        tok1 = (
            f'<rt:requestToken xmlns:rt="{token_url}"><transactionID>'
            f"{tok1_transx_id}</transactionID><sequence>1</sequence><featurePermID/>"
            f"<clientID>{tok1_client_id}</clientID><cpmFeatureCode/><billBackString>"
            f"test</billBackString><contextualFeaturePermID>{tok1_ctx_feat_perm_id}"
            f"</contextualFeaturePermID><other><priceToken>Demo</priceToken></other>"
            f"</rt:requestToken>"
        )
        return tok1

    @staticmethod
    def _post_req1_get_app_token(auth_token, req_token):
        endpoint_domain = "cdc1c-i-services.route53.lexis.com"
        token_url = "http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1"
        url1 = f"https://{endpoint_domain}/identity/accesstoken/application"
        headers = {"x-ln-request": req_token, "content-type": "application/xml", "Authorization": auth_token}
        app_perm_id = "1000516"
        create_app_token_req_payload = (
            f"<CreateApplicationTokenRequest xmlns="
            f'"{token_url}"><applicationPermId>'
            f"{app_perm_id}</applicationPermId>"
            f"</CreateApplicationTokenRequest>"
        )
        response = requests.request("POST", url1, data=create_app_token_req_payload, headers=headers)
        if response.status_code == 201:
            xml_response_payload = response.text
            return FileUploader._get_app_token_from_response(xml_response_payload)
        elif response and response.text:
            print(response.text)
        return ""

    @staticmethod
    def _get_app_token_from_response(xml_response_payload):
        NS_APP_TOKEN_CURLY = "{http://services.lexisnexis.com/xmlschema/application-token/1}"
        xpath_application_token = NS_APP_TOKEN_CURLY + "applicationToken"
        root_data = etree.fromstring(xml_response_payload.encode("utf-8"))
        if root_data.tag == xpath_application_token:
            return etree.tostring(root_data)

    @staticmethod
    def _post_req2_get_sess_token(auth_token, req_token, app_token, s2s_id=""):
        endpoint_domain = "cdc1c-i-services.route53.lexis.com"
        token_url = "http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1"
        s2s_uri_path = "service"
        url = f"https://{endpoint_domain}/identity/accesstoken/{s2s_uri_path}/session?s2suid={s2s_id}"
        headers = {
            "x-ln-request": req_token,
            "X-LN-Application": app_token,
            "content-type": "application/xml",
            "Authorization": auth_token,
            }
        create_sess_token_req_payload = (
            f"<CreateSessionTokenRequest xmlns="
            f'"{token_url}"><ssoCookieValue>'
            f"</ssoCookieValue><lnSessionId>generate"
            f"</lnSessionId></CreateSessionTokenRequest>"
        )
        response = requests.request("POST", url, data=create_sess_token_req_payload, headers=headers)
        if response.status_code == 201:
            xml_response_payload = response.text
            return FileUploader._get_sess_token_from_response(xml_response_payload)
        elif response and response.text:
            print(response.text)
        return ""

    @staticmethod
    def _get_sess_token_from_response(xml_response_payload):
        xpath_session_token = "{http://services.lexisnexis.com/xmlschema/session-token/1}sessionToken"
        root_data = etree.fromstring(xml_response_payload.encode("utf-8"))

        if root_data.tag == xpath_session_token:
            return etree.tostring(root_data)

    def _create_session(self):
        url = self.base_url + self.CREATE_SESSION_PATH
        payload = json.dumps(
            {
                "source": "BriefAnalysisLexis+",
                "isUnclaimed": False,
                "defaultArtifactExpirationInMinutes": 10
                }
            )
        headers = self.get_headers()
        response = requests.post(url, headers=headers, data=payload)
        if response.status_code == 200:
            self.session_attrs = response.json()
        else:
            raise Exception(f"{response.reason} status code = {response.status_code}")

    def delete_session(self):
        if self.session_attrs is not None:
            session_id = self.session_attrs["sessionIdentifier"]
            url = self.base_url + self.DELETE_SESSION_PATH.format(session_id)
            headers = self.get_headers()
            response = requests.delete(url, headers=headers)
            if response.status_code == 200:
                print("session deleted successfully")

    def upload_file(self, file_path: Path) -> Tuple[DocFileModel, Dict]:
        if self.session_attrs is None:
            self._create_session()

        session_id = self.session_attrs["sessionIdentifier"]
        url = self.base_url + self.UPLOAD_FILE_PATH.format(session_id)
        headers = self.get_headers(content_type=False)
        headers["Upload-File-Name"] = file_path.name
        headers["Upload-Source"] = "BriefAnalysisLexis+"
        with open(file_path, "rb") as f:
            response = requests.post(url, headers=headers, data=f)

            if response.status_code == 200:
                content = response.json()
                upload_id = content["uploadIdentifier"]
                status_url = self.base_url + self.UPLOAD_STATUS_PATH.format(session_id, upload_id)
                status_headers = self.get_headers()

                for _ in range(50):
                    status_response = requests.get(status_url, headers=status_headers)
                    if status_response.status_code == 200:
                        status_content = status_response.json()
                        if (
                                status_content["uploadStatusCode"] == "Completed"
                                and status_content["uploadProgress"] == 100
                        ):
                            document_display_name = status_content["displayName"]
                            upload_identifier = status_content["uploadIdentifier"]
                            session_identifier = status_content["sessionIdentifier"]
                            upload_link = self.base_url + self.GET_DOCX_HTML_URL.format(session_id, upload_id)
                            document_page_count = status_content["originalFile"].get("pageCount", 0)
                            document_character_count = status_content.get("convertedFile", {}).get("characterCount", 0)

                            return DocFileModel(
                                document_display_name=document_display_name,
                                upload_identifier=upload_identifier,
                                session_identifier=session_identifier,
                                upload_link=upload_link,
                                document_page_count=document_page_count,
                                document_character_count=document_character_count,
                                ), headers
                        else:
                            print(
                                f"WAITING FOR UPLOAD TO COMPLETE: {status_content['uploadStatusCode']}: {status_content['uploadProgress']}%")
                    time.sleep(10)
            else:
                print(response.text)
        raise RuntimeError("Could not upload the file properly")

    def download_docx_file(self, session_id: str, upload_id: str, output_path: Path) -> bytes:
        url = self.base_url + self.GET_DOCX_URL.format(session_id, upload_id)
        headers = self.get_headers()
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            with open(output_path, 'wb') as file:
                file.write(response.content)
            return response.content
        else:
            raise Exception(f"Failed to download docx file. Response: {response.text}")

