import sys
import os
import json
import logging
import datetime
import hashlib
import traceback
from typing import Any
import boto3
from datetime import datetime

from pydantic import BaseModel, Field

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DEBUG = False

REGION = os.environ.get("Region", "us-east-1")

IO_BUCKET = os.environ.get("IO_BUCKET", "2591-contract-analysis-us-east-1-688136498438")
IO_LOC = os.environ.get("IO_LOC", "io")
CLAUSE_REC_IO_BUCKET = os.environ.get("CLAUSE_REC_IO_BUCKET", "3111-contract-analysis-us-east-1-688136498438")


def download_file_s3(file_name, loc=IO_LOC, bucket=IO_BUCKET):
    try:
        s3 = boto3.client("s3")
        key = f"{loc}/{file_name}"
        logger.info(f"Reading file: s3://{bucket}/{key}")
        s3_clientobj = s3.get_object(Bucket=bucket, Key=key)
        body = s3_clientobj["Body"].read().decode('utf-8')
        return body
    except Exception as e:
        logger.error(f"Unable to download file: s3://{bucket}/{loc}/{file_name}. Error: {repr(e)}")
    return None


def upload_file_s3(file_content, object_name, loc=IO_LOC, bucket=IO_BUCKET):
    try:

        s3 = boto3.client("s3")
        key = f"{loc}/{object_name}"
        logger.info(f"Uploading output to {key} in s3")
        # date_time = datetime.datetime.now() + datetime.timedelta(seconds=5)
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=file_content,
            ServerSideEncryption="AES256"
        )
        return key
    except Exception as e:
        logger.error(f"Unable to upload file")
        logger.error(e)
        return None


def delete_file_s3(object_name, loc=IO_LOC, bucket=IO_BUCKET):
    try:
        s3 = boto3.resource("s3")
        KEY = f"{loc}/{object_name}"
        logger.info(f"Deleting file:{object_name} from {KEY}")
        response = s3.Bucket(bucket).delete_objects(Delete={'Objects': [{'Key': KEY}]})   # type: ignore
        errors = response.get('Errors', [])
        if len(errors):
            message = errors[0].get('Message', 'Unable to delete file')
            logger.error(message)
            return 400, message
        else:
            return 200, f"successfully deleted {bucket}/{KEY}"
    except Exception as e:
        logger.error(f"Unable to delete file:{object_name}")
        logger.error(e)
    return 400, f"Unable to delete file:{object_name}"


def get_document_from_file(file_name, bucket=IO_BUCKET):
    try:
        content = download_file_s3(file_name, bucket=bucket)
        if content is None:
            logger.error(f"Unable to download file from S3: {file_name}")
            return None

    except Exception as e:
        logger.error(f"Unable to download file from S3: {file_name}")
        logger.error(e)
        return None

    return content



