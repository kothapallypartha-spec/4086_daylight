from pathlib import Path

from typing import List, Dict, Any

import json
from pydantic import BaseModel, Field
from typing import List, Literal

from common.llm_proxy_openai import OpenAI_Like, to_custom_json_schema
from common.utils import logger
from common.data_model import DocumentProfile

doc_understanding_system_prompt = "You are a professional legal assistant specializing in due diligence for mergers and acquisitions. " \
                                  "Your task is to analyze legal documents and extract key information to assist in risk assessment and issue identification. " \
                                  "You will classify documents, summarize their contents, extract metadata, identify legal clauses, and spot potential issues. Your output will be used by senior legal experts, so clarity and accuracy are critical."


doc_understanding_prompt = f""" 
You are assisting in a legal due diligence process for a merger or acquisition. Your job is to organize and analyze legal documents provided by the target company so that M&A legal experts can efficiently conduct risk assessment and issue identification.

For each document:

1. Come up with a clear and descriptive title based on the document content (e.g., "Master Services Agreement - Acme Corp (2022) - part 1").

2. Extract metadata if available, including: document date, document type, parties involved, agreements or contracts if any, etc.

3. Generate a comprehensive summary of the document's purpose and key contents (3 to 5 paragraphs). Do not invent or infer facts.

4. Indicate the document's relevancy to the M&A due diligence task based on its content and impact on deal structure or risk assessment. Use one of the following levels:
   - High: Document contains clauses or information that could materially impact the deal (e.g., ownership, liability, change-of-control risk).
   - Medium: Document contains information relevant for understanding obligations, contracts, or operations.
   - Low: Document is administrative or unlikely to impact transaction terms.

You should prepare the following fields for each document:
- document title
- metadata (dictionary)
- summary
- relevance (High / Medium / Low)

Be conservative in your risk spotting, and never guess or fabricate document content. Your output will be used by senior legal experts for risk evaluation, so clarity and accuracy are critical.

Document content MUST BE IN JSON FORMAT. NO OTHER TEXT should be included in your response.
Use the following JSON schema for your response:
{to_custom_json_schema(DocumentProfile)}
"""

def update_table_of_content(
        category: str,
        title: str,
        document_path: str,
        metadata: str,
        summary: str,
        clauses: List[Any],
        potential_issues: List[Any],
        relevance: str,
        ) -> str:
    """
    Add a new item to the table of contents list.

    Args:
        category: Document category
        title: Document title
        document_path: File path to the document
        metadata: Dictionary with document metadata (as JSON string or dict)
        summary: Document summary
        clauses: List of clauses with 'label' and 'text' keys
        potential_issues: List of issues with 'summary', 'category', 'clause', 'severity' keys
        relevance: Document relevance level (High/Medium/Low)

    Returns:
        Status message
        :param data_file:
    """
    try:
        toc_list =[]
        # Ensure metadata is a dictionary
        if isinstance(metadata, str):
            try:
                metadata_dict = json.loads(metadata)
            except Exception:
                metadata_dict = {"raw": metadata}
        else:
            metadata_dict = metadata

        # Convert Clause and PotentialIssue objects to dicts (Pydantic v2+)
        clauses_list = [c.model_dump() if hasattr(c, "model_dump") else dict(c) for c in clauses]
        potential_issues_list = [p.model_dump() if hasattr(p, "model_dump") else dict(p) for p in potential_issues]

        new_item = {
            "category": category,
            "title": title,
            "document_path": document_path,
            "metadata": metadata_dict,
            "summary": summary,
            "clauses": clauses_list,
            "potential_issues": potential_issues_list,
            "relevance": relevance
            }

        toc_list.append(new_item)
        return "Table of contents updated successfully"
    except Exception as e:
        return f"Error updating table of contents: {str(e)}"

class Clause(BaseModel):
    label: str = Field(..., description="Label of the extracted legal clause")
    text: str = Field(..., description="Text of the extracted legal clause")


class PotentialIssue(BaseModel):
    summary: str = Field(..., description="Summary of the identified legal risk issue")
    category: str = Field(..., description="Category of the issue")
    clause: str = Field(..., description="Clause from which the issue was identified")
    severity: Literal["High", "Medium", "Low"] = Field(..., description="Severity of the issue")


def process_doc_content(content: str, model_name: str, filename_stem: str = "filename"):
    """
    Process the content of a document using LLM to extract metadata, summary, and relevance.

    Args:
        content (str): Full textual content of the document.
        filename_stem (str): Document identifier (no file extension).
        save_dir (Path): Directory to save the output JSON file.

    Returns:
        A DocumentProfile object with extracted information.
    """
    client = OpenAI_Like(model_name=model_name)
    try:
        messages = [
            {"role": "system", "content": doc_understanding_system_prompt},
            {"role": "user", "content": doc_understanding_prompt}
            ]
        msg = "This is the content of the document:\n" + content + "\n\n End of document.\n"
        messages.append({"role": "user", "content": msg})
        response = client.chat.parse(
            messages=messages,
            response_format=DocumentProfile
            )
        document_profile = response.choices[0].message.parsed

        return document_profile
    except Exception as e:
        logger.error(f"✗ Error reading {filename_stem}: {str(e)}")
        logger.exception(e)
        raise
