
from typing import List, Dict, Any, Optional, Type, TypeVar
from pydantic import BaseModel, Field
from pydantic.fields import FieldInfo
from typing import get_args, get_origin, Union, Optional, List
import inspect
import os
import logging
import boto3
import json
from aws.secrets import SecretsManager

logger = logging.getLogger()

from llm_proxy import create_simple_proxy
from llm_proxy.prompt import (ChatPromptTemplate, HumanMessagePromptTemplate,
                              SystemMessagePromptTemplate, AIMessagePromptTemplate)

T = TypeVar('T', bound=BaseModel)


class ChatCompletion:
    """Mimics OpenAI's ChatCompletion structure"""

    def __init__(self, parsed_result: Any):
        self.choices = [Choice(parsed_result)]


class Choice:
    """Mimics OpenAI's Choice structure"""

    def __init__(self, parsed_result: Any):
        self.message = Message(parsed_result)


class Message:
    """Mimics OpenAI's Message structure"""

    def __init__(self, parsed_result: Any):
        self.parsed = parsed_result


def extract_description(cls):
    """Return class docstring only if defined directly on the class, not inherited."""
    if "__doc__" in cls.__dict__:
        doc = cls.__doc__
        return inspect.cleandoc(doc) if doc else ""
    return None


def to_custom_json_schema(model_cls):
    def model_to_schema(cls):
        schema = {
            "title": cls.__name__,
            "type": "object",
            "description": extract_description(cls),
            "properties": {},
            "required": [],
            "additionalProperties": False
        }

        for field_name, model_field in cls.model_fields.items():
            field_type = model_field.annotation
            origin = get_origin(field_type)
            field_info: FieldInfo = model_field
            field_schema = {
                "title": field_info.title or field_name.replace("_", " ").title(),
                "description": field_info.description or "",
            }

            if origin is list:
                item_type = get_args(field_type)[0]
                if inspect.isclass(item_type) and issubclass(item_type, BaseModel):
                    field_schema["type"] = "array"
                    field_schema["items"] = model_to_schema(item_type)
                else:
                    field_schema["type"] = "array"
                    field_schema["items"] = {"type": "string"}
            elif inspect.isclass(field_type) and issubclass(field_type, BaseModel):
                field_schema.update(model_to_schema(field_type))
            else:
                field_schema["type"] = "string"

            schema["properties"][field_name] = field_schema
            schema["required"].append(field_name)  # <-- Make all fields required

        return schema

    return {
        "type": "json_schema",
        "json_schema": {
            "name": model_cls.__name__,
            "description": extract_description(model_cls),
            "schema": model_to_schema(model_cls),
            "strict": True
        }
    }


class ChatCompletions:
    """Handles chat completions with structured output parsing"""

    def __init__(self, client):
        self.client = client
        # Add completions attribute to match OpenAI structure
        self.completions = self

    def parse(self,
              messages: List[Dict[str, str]],
              response_format: Type[T],
              **kwargs) -> ChatCompletion:
        """
        Parse chat completion with structured output

        Args:
            model: Model name (will use client's default if different)
            messages: List of message dictionaries with 'role' and 'content'
            response_format: Pydantic model class for structured output
            **kwargs: Additional arguments (ignored for compatibility)

        Returns:
            ChatCompletion object with parsed result
        """
        assert isinstance(response_format, type) and issubclass(response_format, BaseModel), \
            "response_format must be a Pydantic model class"
        # Check if this is a Claude/Anthropic model
        model = self.client.model_name
        assert model, "Model name must be specified"
        is_claude = 'claude' in model.lower() or 'anthropic' in model.lower()
        system_content = ""

        # Convert OpenAI-style messages to LangChain-style templates
        prompt_messages = []

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            escaped_content = content.replace("{", "{{").replace("}", "}}")

            if role == "system":
                if is_claude:
                    # For Claude, accumulate system messages to prepend to first user message
                    system_content += escaped_content + "\n\n"
                else:
                    # For other models, keep as system message
                    prompt_messages.append(SystemMessagePromptTemplate.from_template(escaped_content))
            elif role == "user":
                if is_claude and system_content and len(prompt_messages) == 0:
                    # For Claude, prepend accumulated system content to first user message
                    combined_content = system_content + escaped_content
                    prompt_messages.append(HumanMessagePromptTemplate.from_template(combined_content))
                    system_content = ""  # Clear it after use
                else:
                    prompt_messages.append(HumanMessagePromptTemplate.from_template(escaped_content))
            elif role == "assistant":
                prompt_messages.append(AIMessagePromptTemplate.from_template(escaped_content))

        template = ChatPromptTemplate.from_messages(prompt_messages)

        # Format the Pydantic model for response format
        # formatted_response_format = to_custom_json_schema(response_format)

        #print(formatted_response_format)

        # Create the proxy
        llm = create_simple_proxy(
            template,
            self.client.model_name,
            # response_format=formatted_response_format,
            tenant=self.client.tenant,
            retry=self.client.retry,
            timeout=self.client.timeout,
            max_tokens=30000
        )

        # Default tracing info
        tracing_info = {
            "asset_id": "<4086>",
            "trans_id": "<4086 M&A due diligence - agentic issue identification>",
            "user_id": "<issue identification>",
            "user_type": "issue identification",
            "ext_info": {}
        }

        # Get the response
        response = llm.chat(tracing_info=tracing_info)

        # Parse the response into the expected Pydantic model
        if isinstance(response, str):
            import json
            try:
                response = (
                    response.strip()
                    .removeprefix("```json")
                    .removeprefix("```")
                    .removesuffix("```")
                    .strip()
                )
                response_data = json.loads(response)
                parsed_result = response_format.model_validate(response_data)
            except Exception as e:
                import logging
                logger = logging.getLogger()
                logger.error(f"Raw response: {repr(response)}")
                logger.error(f"Error parsing response: {e}")
                raise
        else:
            parsed_result = response_format.model_validate(response)

        return ChatCompletion(parsed_result)


class OpenAILikeClient:
    """
    A wrapper around create_simple_proxy that provides an OpenAI-like interface
    """

    def __init__(self,
                 model_name = os.getenv("MODEL_NAME", ""),
                 retry: int = 1,
                 timeout: int = 120):
        assert model_name, "Model name must be specified"
        self.model_name = model_name
        ASSET_ID = os.getenv("ASSET_ID", "3363")
        ASSET_GROUP = os.getenv("AssetGroup", "ddc4c")
        assert ASSET_ID, "ASSET_ID environment variable must be set"
        assert ASSET_GROUP, "AssetGroup environment variable must be set"
        secrets_mgr = SecretsManager(
            f'/AssetID_3363/{ASSET_GROUP}/rag-workflows-secret',
            'us-east-1'
        )
        tenant = secrets_mgr.get_secret('LLM_PROXY_TENANT')
        assert tenant, "Tenant must be specified"
        self.tenant = tenant
        self.retry = retry
        self.timeout = timeout
        self.chat = ChatCompletions(self)


# Convenience function to create a client instance
def OpenAI_Like(**kwargs) -> OpenAILikeClient:
    """
    Create an OpenAI-like client instance

    Args:
        **kwargs: Configuration options for the client

    Returns:
        OpenAILikeClient instance
    """
    return OpenAILikeClient(**kwargs)


# example usage of the OpenAI_Like client
def example_usage():
    class ClauseAnalysis(BaseModel):
        """
        Represents a single legal clause extracted from a document,
        along with a corresponding issue or risk identified during M&A due diligence.

        Attributes:
            clause_text (str): The full, extracted text of the legal clause.
            issue_or_risk (str): A detailed and extractive description of the legal, financial, or operational
                issue or risk identified in the clause. Should reflect potential impact on the deal.
        """
        clause_text: str
        issue_or_risk: str

    client = OpenAI_Like()

    # Define the messages for the chat completion
    messages = [
        {"role": "system", "content": "You are an expert in M&A legal due diligence."},
        {"role": "user", "content": "Analyze the provided documents for issues and risks."}
    ]

    # Parse the chat completion with structured output
    response = client.chat.parse(
        model="gpt-4.1-mini",
        messages=messages,
        response_format=ClauseAnalysis
    )

    # Print the parsed results
    print(response.choices[0].message.parsed)

#example_usage()
