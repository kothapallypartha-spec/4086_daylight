# lambda.py
import os
from pathlib import Path

from common.data_model import ErrorResponse, InputModel, Result

MODEL_NAME = os.getenv("MODEL_NAME", "anthropic-claude-3-7-sonnet-20250219_Daylight_3363_nonprod")

import html2text
import urllib.request
import sys
import logging
import json
from pydantic import BaseModel, Field, ValidationError
from common.tools_doc_understanding import process_doc_content
from common.utils import pre_signed_url_output, FileUploader

LOG_LEVEL = "INFO"
logging.basicConfig(
    level=LOG_LEVEL,
    format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger()




def lambda_handler(event: dict, context):
    logger.info(f"Received event: {event}")
    if 'body' not in event:
        error_response = ErrorResponse.from_error_message("Missing 'body' in event", statusCode=400)
        return error_response.model_dump()
    try:
        body = json.loads(event['body'])
        assert isinstance(body, dict), "Event body is not a valid JSON object"
        data = InputModel(**body)
        if not data.content:
            if not data.url:
                logger.error("Neither content nor URL provided in the input.")
                return ErrorResponse.from_error_message(
                    "Either 'content' or 'url' must be provided.", statusCode=400
                ).model_dump(by_alias=True)
            req = urllib.request.Request(data.url, headers=data.headers or {})
            with urllib.request.urlopen(req) as response:
                html = response.read().decode('utf-8')
            h = html2text.HTML2Text()
            data.content = h.handle(html)
            logger.info("Successfully fetched and converted HTML content from URL.")
        metadata = process_doc_content(
            content=data.content,
            model_name=data.model_name,
            filename_stem=data.filename_stem,
        )
        logger.info("Document processing completed successfully.")
        return Result(body=json.dumps(metadata.model_dump()),
                      statusCode=200).model_dump(by_alias=True)
    except ValidationError as ve:
        validation_errors = json.loads(ve.json())  # structured list of errors
        logger.error(f"Lambda execution failed due an error in either input or output data: {validation_errors}")
        logger.exception(validation_errors)
        error_response = ErrorResponse.from_exception(ve, statusCode=422)
        return error_response.model_dump(by_alias=True)
    except Exception as e:
        logger.error(f"Lambda execution failed: {str(e)}")
        logger.exception(e)
        error_response = ErrorResponse.from_exception(e)
        return error_response.model_dump(by_alias=True)


if __name__ == "__main__":
    test_event = {
        "body": json.dumps({
            "filename_stem": "test_doc",
            "url": pre_signed_url_output(os.environ["FILE_PATH"])
        })
    }
    result = lambda_handler(test_event, None)
    print(json.dumps(result, indent=2))

    uploader = FileUploader()
    document, headers = uploader.upload_file(Path(os.environ["DOCX_FILE_PATH"]))
    test_event = {
        "body": json.dumps({
            "filename_stem": "test_doc",
            "url": document.upload_link,
            "headers": headers
            })
        }
    result = lambda_handler(test_event, None)
    print(json.dumps(result, indent=2))
