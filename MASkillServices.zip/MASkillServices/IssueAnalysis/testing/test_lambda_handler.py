"""
Test script for Lambda handler functionality

Usage:
    python test_lambda_handler.py <path_to_document>

Example:
    python test_lambda_handler.py '/Users/zhangz9/Downloads/contract.docx'

Environment Variables (set in src/.env_local):
    - RESULT: Directory path where results will be saved (e.g., "/path/to/output/")
    - MODEL_NAME: LLM model to use (default: OpenAI_gpt-4.1-2025-04-14_Daylight_US_3363_nonprod)
    - AWS_PROFILE: AWS profile for authentication (required for AWS Secrets Manager access)

Output:
    - Results saved to: <RESULT>/result<timestamp>.json
"""
import asyncio
import json
import sys
import os
import pprint
from pathlib import Path
from datetime import datetime

import boto3
import logging
from botocore.config import Config

from sp_uploader import FileUploader

from main import identify_issues, IdentifyRequest


logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Adding the parent directories to Python path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
clause_skill_dir = os.path.dirname(current_dir)  # clause_skill directory
src_python_dir = os.path.dirname(clause_skill_dir)  # src/python directory
sys.path.insert(0, src_python_dir)
sys.path.insert(0, clause_skill_dir)


# from data_models import AnalysisResult, ErrorResponse, ClauseSection


def pre_signed_url_output(file_name):
    """
    Upload file to S3 and generate pre-signed URL for access.
    Uses real AWS S3 (not LocalStack).
    """
    retry_config = Config(
        retries={
            'max_attempts': 5,
            'mode': 'standard'
        }
    )

    bucket_name = "11346-due-diligence-ma-164682029196"
    s3_client = boto3.client('s3', config=retry_config)

    key = 'presigned_urls/' + os.path.basename(file_name)
    logger.info(f"Uploading {file_name} to s3://{bucket_name}/{key}")

    s3_client.upload_file(file_name, Bucket=bucket_name, Key=key)

    pre_signed_url = s3_client.generate_presigned_url(
        ClientMethod="get_object",
        Params={'Bucket': bucket_name, 'Key': key},
        ExpiresIn=3600
    )
    logger.info(f"Generated pre-signed URL: {pre_signed_url}")

    return pre_signed_url

def test_lambda_event_structure(mode):
    """Test what a Lambda event would look like"""

    doc = sys.argv[1] if len(sys.argv) > 1 else "stock-purchase.html"
    fullpath = os.path.realpath(os.path.join(current_dir, "../../../", doc))
    stem = os.path.splitext(os.path.basename(fullpath))[0]

    if mode == "pre-signed-url":
        sample_event = {
            "body": json.dumps({
                "filename_stem": stem,
                "url": pre_signed_url_output(fullpath)
            }),
            "headers": {"Content-Type": "application/json"},
        }

        identify_request_object = IdentifyRequest.model_validate(sample_event)
    else:
        uploader = FileUploader("local")
        document, headers = uploader.upload_file(Path(fullpath))
        sample_event = {
            "document_input":{
                "file_name": stem,
                "content": None,
                "url": document.upload_link.replace("docx", "docxhtml"),
                "headers": headers
            },
            "model": os.getenv("MODEL_NAME", "OpenAI_gpt-4.1-2025-04-14_Daylight_US_3363_nonprod")
        }
        #     "body": json.dumps({
        #         "filename_stem": stem,
        #         "url": document.upload_link.replace("docx", "docxhtml"),
        #         "headers": headers,
        #     }),
        # }

        identify_request_object = IdentifyRequest.model_validate(sample_event)

    response = asyncio.run(identify_issues(identify_request_object))

    print(f"  Lambda response: {response}")

    json_data = response.model_dump_json(indent=4)

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    result_file_path = os.getenv("RESULT")
    result_file_path = result_file_path + f"result{timestamp}.json"

    with open(result_file_path, "w") as file:
        file.write(json_data)

    print(json_data)
    # if response['statusCode'] == 200:
    #     sections = json.loads(response['body'])['sections']
    #     def palatable(section):
    #         return {
    #             k: v for k, v in section.items()
    #             if k not in ['clean_clause_text', 'clause_text']
    #         }
    #     sections = [palatable(s) for s in sections]
    #     pprint.pprint(sections)
    # else:
    #     print(f"Lambda returned error status: {response['statusCode']}")
    #     pprint.pprint(json.loads(response['body']))
    #     raise ValueError("Lambda handler returned error status")

if __name__ == "__main__":
    print("Testing Lambda Handler Components\n")
    mode = "sp-upload"

    try:
        test_lambda_event_structure(mode)
        print("\nAll tests passed!")

    except Exception as e:
        print(f"\nTest failed: {e}")
        import traceback

        traceback.print_exc()
