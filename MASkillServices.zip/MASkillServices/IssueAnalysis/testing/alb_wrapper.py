import sys
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
import requests
import json
import base64
import traceback
from typing import Dict, Any
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

app = FastAPI(title="ALB Lambda Wrapper")

LAMBDA_ENDPOINT = "http://lambda:8080/2015-03-31/functions/function/invocations"

def create_alb_event(request: Request, body: bytes, path: str) -> Dict[str, Any]:
    """
    Transform HTTP request into ALB→Lambda event format.
    Validates that the structure matches what AWS ALB actually sends.
    """
    headers = dict(request.headers)

    # ALB always sends body as string, base64-encodes binary
    is_base64 = False
    try:
        body_str = body.decode('utf-8')
    except UnicodeDecodeError:
        body_str = base64.b64encode(body).decode('utf-8')
        is_base64 = True

    event = {
        "requestContext": {
            "elb": {
                "targetGroupArn": "arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/test/test"
            }
        },
        "httpMethod": request.method,
        "path": path,
        "queryStringParameters": dict(request.query_params) if request.query_params else None,
        "headers": headers,
        "body": body_str,
        "isBase64Encoded": is_base64
    }

    return event

def validate_lambda_response(response: Dict[str, Any]) -> None:
    """
    Assert that Lambda response matches ALB integration format.
    These are the actual AWS requirements.
    """
    assert "statusCode" in response, "Lambda must return 'statusCode'"
    assert isinstance(response["statusCode"], int), "statusCode must be integer"
    assert 100 <= response["statusCode"] < 600, "statusCode must be valid HTTP code"

    assert "headers" in response, "Lambda must return 'headers'"
    assert isinstance(response["headers"], dict), "headers must be dict"

    assert "body" in response, "Lambda must return 'body'"
    assert isinstance(response["body"], str), "body must be string"

    if "isBase64Encoded" in response:
        assert isinstance(response["isBase64Encoded"], bool), "isBase64Encoded must be boolean"

    logger.info("✓ Lambda response validates against ALB contract")

def validate_app_team_contract(request_body: Dict[str, Any]) -> None:
    """
    Validate the app team's API contract.
    Adjust these assertions based on your actual requirements.
    Example valid request body:
    {
        "document_input": {
            "url": "https://11346-....s3.amazonaws.com/presigned_urls/doc.html?AWSAccessKeyId=...."
        }
    }
    """
    if "document_input" not in request_body:
        logger.error("Request must include 'document_input'")
        print(json.dumps(request_body, indent=2), file=sys.stderr)
        raise ValueError("Request must include 'document_input'")

    doc_input = request_body["document_input"]

    # Must have either URL or text_input
    if not ("url" in doc_input or "text_input" in doc_input):
        logger.error("document_input must have 'url' or 'text_input'")
        print(json.dumps(doc_input, indent=2), file=sys.stderr)
        raise ValueError("document_input must have 'url' or 'text_input'")

    if "url" in doc_input:
        assert isinstance(doc_input["url"], str), "url must be string"
        assert doc_input["url"].startswith("https://"), "url must be HTTPS pre-signed URL"

    if "filter_clause_types" in request_body:
        assert isinstance(request_body["filter_clause_types"], list), \
            "filter_clause_types must be list"

    logger.info("✓ Request validates against app team contract")

@app.post("/issue-analysis/")
@app.post("/issue-analysis")
async def proxy_to_lambda(request: Request):
    """
    Main endpoint that mimics ALB behavior.
    """
    # Read request body
    body = await request.body()

    # Validate app team contract
    try:
        request_json = json.loads(body)
        validate_app_team_contract(request_json)
    except AssertionError as e:
        logger.error(f"App team contract validation failed: {e}")
        tb = traceback.TracebackException.from_exception(e)
        filename, line_num = tb.stack[-1].filename, tb.stack[-1].lineno
        return JSONResponse(
            status_code=400,
            content={
                "error": f"Contract violation: {str(e)}",
                "filename": filename,
                "line": line_num
            }
        )
    except json.JSONDecodeError as e:
        tb = traceback.TracebackException.from_exception(e)
        filename, line_num = tb.stack[-1].filename, tb.stack[-1].lineno
        return JSONResponse(
            status_code=400,
            content={
                "error": f"Invalid JSON: {str(e)}",
                "filename": filename,
                "line": line_num
            }
        )

    # Create ALB event format
    alb_event = create_alb_event(request, body, str(request.url.path))

    logger.info(f"Invoking Lambda with ALB event structure")

    # Invoke Lambda container
    try:
        lambda_response = requests.post(
            LAMBDA_ENDPOINT,
            json=alb_event,
            timeout=120
        )
        lambda_response.raise_for_status()

        lambda_result = lambda_response.json()

    except requests.exceptions.RequestException as e:
        logger.error(f"Lambda invocation failed: {e}")
        return JSONResponse(
            status_code=502,
            content={"error": "Lambda invocation failed"}
        )

    # Validate Lambda response format
    try:
        validate_lambda_response(lambda_result)
    except AssertionError as e:
        logger.error(f"Lambda response validation failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": f"Lambda response contract violation: {str(e)}",
                "lambda_response": lambda_result
            }
        )

    # Extract response components
    status_code = lambda_result["statusCode"]
    headers = lambda_result.get("headers", {})
    body = lambda_result["body"]
    is_base64 = lambda_result.get("isBase64Encoded", False)

    # Decode body if base64
    if is_base64:
        body = base64.b64decode(body)

    return Response(
        content=body,
        status_code=status_code,
        headers=headers
    )

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
