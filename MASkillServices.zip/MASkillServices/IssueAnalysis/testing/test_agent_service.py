import base64
import json
import os
import time
import xml
from copy import copy
from pathlib import Path
from typing import Tuple, Optional, Dict
import xml.dom.minidom
import grequests

import requests
from lxml import etree
from pydantic import BaseModel
from botocore.config import Config
import boto3
from requests.auth import HTTPBasicAuth

PROD_URL = "https://agent-svc.us.3363-rag-us-prod.sk8s.aws.lexis.com"
STAGING_URL = "https://agent-svc.us.3363-rag-us-staging.sk8s.aws.lexis.com"
CERT_URL = "https://cert-agent-svc.rag-us.use1.dev-searchplatform.nl.lexis.com"
DEV_URL = "http://agent-svc.rag-us.use1.dev-searchplatform.nl.lexis.com"
LOCAL_URL = "http://127.0.0.1:8080"

VIEW_MORE = "https://agent-svc.rag.us.sk8s.aws.lexis.com/api/v1/proxy/documents/snippets?message_id=9b33a3ed-a5d0-4957-a735-c01f83a33101&content_type=analytical-materials&page=1&size=20"

ENV_DATA = {
    "prod": {"url": PROD_URL, "id": "urn:user:PA195739221", "asset_group": "pdc1c", "user": "protegeuser_1"},
    "staging": {"url": STAGING_URL, "id": "urn:user:PA195739219", "asset_group": "pdc2c", "user": "protegeuser_2"},
    "cert": {"url": CERT_URL, "id": "urn:user:CA200433345", "asset_group": "cdc1c", "user": "LPlusAI0"},  # LPlusAI0 - cert1
    "dev": {"url": DEV_URL, "id": "urn:user:CB204094827", "asset_group": "cdc7c", "user": "LPlusAI0"},  # LPlusAI0 - cert7
    "local": {"url": LOCAL_URL, "id": "urn:user:CB204094827", "asset_group": "cdc7c", "user": "LPlusAI0"}  # LPlusAI0 - cert7
    }
COMMOM_SERVER_ENDPOINT = "-i-services.route53.lexis.com"


def get_auth_tokens(username, password, server):

    request_header = """<rt:requestToken xmlns:rt="http://services.lexisnexis.com/xmlschema/request-token/1"><transactionID>00db4725-1c04-8f59-4fc1-4efca6a765c3</transactionID><sequence>1</sequence><featurePermID/><clientID>test client</clientID><cpmFeatureCode/><billBackString>test</billBackString><contextualFeaturePermID>1000516</contextualFeaturePermID><other><priceToken>Demo</priceToken></other></rt:requestToken>"""
    # According to Brian Rambacher application tokens never expire so hard coding it, ratherthan generating it again

    application_token = """<ns2:applicationToken xmlns:ns2="http://services.lexisnexis.com/xmlschema/application-token/1"><applicationPermID>1000202</applicationPermID><issued>2023-05-14T15:49:03.849Z</issued><signature>v1-29e7a301a1ff3dbbb3552fb00daef426</signature></ns2:applicationToken>"""

    headers = {"Content-Type": "application/xml", "Accept": "application/xml", "X-LN-Request": request_header}

    sso_post_data = (
            "<CreateSSOTokenRequest "
            'xmlns="http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            'xmlns:xsd="http://www.w3.org/2001/XMLSchema"> '
            "<userId>" + username + "</userId><password>" + password + "</password></CreateSSOTokenRequest>"
    )

    headers["X-LN-Application"] = application_token
    tokenUrlSSO = "http://" + server +  COMMOM_SERVER_ENDPOINT + "/identity/accesstoken/sso"

    print("Session call: " + tokenUrlSSO)
    sso_resp_data = requests.post(
        tokenUrlSSO, headers=headers, data=sso_post_data, auth=HTTPBasicAuth("internalsvcs", "3uF6ezaC")
        )

    sso_value = sso_resp_data.text
    xm = xml.dom.minidom.parseString(sso_value)
    sso_token = xm.documentElement.firstChild.firstChild.toxml()
    sso_tag = xm.documentElement.firstChild.toxml()

    # ----------------------- session ------------------------------

    tokenUrlSession = "http://" + server + COMMOM_SERVER_ENDPOINT + "/identity/accesstoken/session"

    session_post_data = (
            "<CreateSessionTokenRequest "
            'xmlns="http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            'xmlns:xsd="http://www.w3.org/2001/XMLSchema"><ssoCookieValue>'
            + sso_token
            + "</ssoCookieValue><lnSessionId>generate</lnSessionId></CreateSessionTokenRequest>"
    )

    print("Session call: " + tokenUrlSession)
    session_resp_data = requests.post(
        tokenUrlSession, headers=headers, data=session_post_data, auth=HTTPBasicAuth("internalsvcs", "3uF6ezaC")
        )
    session_value = session_resp_data.text
    xm = xml.dom.minidom.parseString(session_value)
    session_token = xm.documentElement.toxml()
    print("\n")
    print("X-LN-Session: " + session_token)
    print("--------------------------------------------------------")

    print("X-LN-Application: " + application_token)
    print("--------------------------------------------------------")

    print("X-LN-Request: " + request_header)
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Session: " + session_token.replace('"', '\\"'))
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Application: " + application_token.replace('"', '\\"'))
    print("--------------------------------------------------------")

    print("Escaped Quotes X-LN-Request: " + request_header.replace('"', '\\"'))
    print("--------------------------------------------------------")

    return request_header, application_token, session_token

def get_wam_headers(env):
    asset_group= ENV_DATA[env]["asset_group"]
    user = ENV_DATA[env]["user"]
    request_header, application_token, session_token = get_auth_tokens(user, "Testing99", server=asset_group)
    return {
        "X-LN-Validate-Output": "true",
        "X-LN-Application": application_token,
        "X-LN-Request": request_header,
        "X-LN-Session": session_token,
        }

class DocFileModel(BaseModel):
    document_display_name: str
    upload_identifier: str
    session_identifier: str
    upload_link: str
    document_page_count: Optional[int] = None
    document_character_count: Optional[int] = None


class FileUploader:
    CREATE_SESSION_PATH = "f/up/v1/session"
    DELETE_SESSION_PATH = "f/up/v1/session/{}"

    UPLOAD_FILE_PATH = "f/up/v1/{}/upload/file"
    UPLOAD_STATUS_PATH = "f/up/v1/{}/upload/{}/status"

    GET_DOCX_URL = "f/up/v1/{}/upload/{}/docx"
    GET_DOCX_HTML_URL = "f/up/v1/{}/upload/{}/docxhtml"
    GET_TEXT_URL = "f/up/v1/{}/upload/{}/text"
    GET_ALL_DOCX_HTML_URL = "f/up/v1/{}/upload/docxhtml"

    def __init__(self, env: str):
        asset_group = ENV_DATA[env]["asset_group"]
        self.base_url = f"https://{asset_group}-la-sp-upload.route53.lexis.com/"
        self.session_attrs = None
        self.headers = get_wam_headers(env) # self.get_wam_headers()

    def get_headers(self, content_type=True, accept=True):
        headers = copy(self.headers)
        if content_type:
            headers["Content-Type"] = "application/json"
        if accept:
            headers["Accept"] = "application/json"
        return headers

    @staticmethod
    def get_wam_headers():
        user_id = "LNGAST004481@Service2Service"
        password =  "Pwd4481LN"
        auth_token_header = FileUploader._get_auth_token_header(user_id, password)
        request_token_header = FileUploader._get_request_token()

        application_token_header = FileUploader._post_req1_get_app_token(auth_token_header, request_token_header)
        session_token_header = FileUploader._post_req2_get_sess_token(
            auth_token_header, request_token_header, application_token_header, user_id
            )

        assert session_token_header, "Failed to get session headers"

        return {
            "X-LN-Validate-Output": "true",
            "X-LN-Application": application_token_header.decode('utf-8'),
            "X-LN-Request": request_token_header,
            "X-LN-Session": session_token_header.decode('utf-8'),
            }

    @staticmethod
    def _get_auth_token_header(user_id, password):
        user_id = user_id.split("@")[0]
        credentials_str = f"{user_id}:{password}"
        username_password = bytes(credentials_str, "utf8")
        username_password_b64 = base64.b64encode(username_password).decode("utf-8")
        return f"Basic {username_password_b64}"

    @staticmethod
    def _get_request_token(tok1_ctx_feat_perm_id="1541499"):
        token_url = "http://services.lexisnexis.com/xmlschema/request-token/1"
        tok1_transx_id = "476d9a4c-4c55-dc47-877f-23beed4b2aa9"
        tok1_client_id = "test client"
        tok1 = (
            f'<rt:requestToken xmlns:rt="{token_url}"><transactionID>'
            f"{tok1_transx_id}</transactionID><sequence>1</sequence><featurePermID/>"
            f"<clientID>{tok1_client_id}</clientID><cpmFeatureCode/><billBackString>"
            f"test</billBackString><contextualFeaturePermID>{tok1_ctx_feat_perm_id}"
            f"</contextualFeaturePermID><other><priceToken>Demo</priceToken></other>"
            f"</rt:requestToken>"
        )
        return tok1

    @staticmethod
    def _post_req1_get_app_token(auth_token, req_token):
        endpoint_domain = "cdc1c-i-services.route53.lexis.com"
        token_url = "http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1"
        url1 = f"https://{endpoint_domain}/identity/accesstoken/application"
        headers = {"x-ln-request": req_token, "content-type": "application/xml", "Authorization": auth_token}
        app_perm_id = "1000516"
        create_app_token_req_payload = (
            f"<CreateApplicationTokenRequest xmlns="
            f'"{token_url}"><applicationPermId>'
            f"{app_perm_id}</applicationPermId>"
            f"</CreateApplicationTokenRequest>"
        )
        response = requests.request("POST", url1, data=create_app_token_req_payload, headers=headers)
        if response.status_code == 201:
            xml_response_payload = response.text
            return FileUploader._get_app_token_from_response(xml_response_payload)
        elif response and response.text:
            print(response.text)
        return ""

    @staticmethod
    def _get_app_token_from_response(xml_response_payload):
        NS_APP_TOKEN_CURLY = "{http://services.lexisnexis.com/xmlschema/application-token/1}"
        xpath_application_token = NS_APP_TOKEN_CURLY + "applicationToken"
        root_data = etree.fromstring(xml_response_payload.encode("utf-8"))
        if root_data.tag == xpath_application_token:
            return etree.tostring(root_data)

    @staticmethod
    def _post_req2_get_sess_token(auth_token, req_token, app_token, s2s_id=""):
        endpoint_domain = "cdc1c-i-services.route53.lexis.com"
        token_url = "http://services.lexisnexis.com/xmlschemas/identity/accesstoken/1"
        s2s_uri_path = "service"
        url = f"https://{endpoint_domain}/identity/accesstoken/{s2s_uri_path}/session?s2suid={s2s_id}"
        headers = {
            "x-ln-request": req_token,
            "X-LN-Application": app_token,
            "content-type": "application/xml",
            "Authorization": auth_token,
            }
        create_sess_token_req_payload = (
            f"<CreateSessionTokenRequest xmlns="
            f'"{token_url}"><ssoCookieValue>'
            f"</ssoCookieValue><lnSessionId>generate"
            f"</lnSessionId></CreateSessionTokenRequest>"
        )
        response = requests.request("POST", url, data=create_sess_token_req_payload, headers=headers)
        if response.status_code == 201:
            xml_response_payload = response.text
            return FileUploader._get_sess_token_from_response(xml_response_payload)
        elif response and response.text:
            print(response.text)
        return ""

    @staticmethod
    def _get_sess_token_from_response(xml_response_payload):
        xpath_session_token = "{http://services.lexisnexis.com/xmlschema/session-token/1}sessionToken"
        root_data = etree.fromstring(xml_response_payload.encode("utf-8"))

        if root_data.tag == xpath_session_token:
            return etree.tostring(root_data)

    def _create_session(self):
        url = self.base_url + self.CREATE_SESSION_PATH
        payload = json.dumps(
            {
                "source": "BriefAnalysisLexis+",
                "isUnclaimed": False,
                "defaultArtifactExpirationInMinutes": 10
                }
            )
        headers = self.get_headers()
        response = requests.post(url, headers=headers, data=payload)
        if response.status_code == 200:
            self.session_attrs = response.json()
        else:
            raise Exception(f"{response.reason} status code = {response.status_code}")

    def delete_session(self):
        if self.session_attrs is not None:
            session_id = self.session_attrs["sessionIdentifier"]
            url = self.base_url + self.DELETE_SESSION_PATH.format(session_id)
            headers = self.get_headers()
            response = requests.delete(url, headers=headers)
            if response.status_code == 200:
                print("session deleted successfully")

    def upload_file(self, file_path: Path) -> Tuple[DocFileModel, Dict]:
        if self.session_attrs is None:
            self._create_session()

        session_id = self.session_attrs["sessionIdentifier"]
        url = self.base_url + self.UPLOAD_FILE_PATH.format(session_id)
        headers = self.get_headers(content_type=False)
        headers["Upload-File-Name"] = file_path.name
        headers["Upload-Source"] = "BriefAnalysisLexis+"
        with open(file_path, "rb") as f:
            response = requests.post(url, headers=headers, data=f)

            if response.status_code == 200:
                content = response.json()
                upload_id = content["uploadIdentifier"]
                status_url = self.base_url + self.UPLOAD_STATUS_PATH.format(session_id, upload_id)
                status_headers = self.get_headers()

                for _ in range(50):
                    status_response = requests.get(status_url, headers=status_headers)
                    if status_response.status_code == 200:
                        status_content = status_response.json()
                        if (
                                status_content["uploadStatusCode"] == "Completed"
                                and status_content["uploadProgress"] == 100
                        ):
                            document_display_name = status_content["displayName"]
                            upload_identifier = status_content["uploadIdentifier"]
                            session_identifier = status_content["sessionIdentifier"]
                            upload_link = self.base_url + self.GET_DOCX_URL.format(session_id, upload_id)
                            document_page_count = status_content["originalFile"].get("pageCount", 0)
                            document_character_count = status_content.get("convertedFile", {}).get("characterCount", 0)

                            return DocFileModel(
                                document_display_name=document_display_name,
                                upload_identifier=upload_identifier,
                                session_identifier=session_identifier,
                                upload_link=upload_link,
                                document_page_count=document_page_count,
                                document_character_count=document_character_count,
                                ), headers
                        else:
                            print(
                                f"WAITING FOR UPLOAD TO COMPLETE: {status_content['uploadStatusCode']}: {status_content['uploadProgress']}%")
                    time.sleep(10)
            else:
                print(response.text)
        raise RuntimeError("Could not upload the file properly")

    def download_docx_file(self, session_id: str, upload_id: str, output_path: Path) -> bytes:
        url = self.base_url + self.GET_DOCX_URL.format(session_id, upload_id)
        headers = self.get_headers()
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            with open(output_path, 'wb') as file:
                file.write(response.content)
            return response.content
        else:
            raise Exception(f"Failed to download docx file. Response: {response.text}")

def pre_signed_url_output(file_name):
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,POST',
        'Access-Control-Allow-Headers': '*'
        }
    retry_config = Config(
        retries={
            'max_attempts': 5,
            'mode': 'standard'
            }
        )
    os.environ["AWS_DEFAULT_REGION"] = "us-east-1"
    os.environ["AWS_PROFILE"] = "prod-lexisai-dev-lexisaidev"
    bucket_name = "4086-lexis-plus-ai"
    s3_client = boto3.client('s3', config=retry_config)
    key = 'ma_due_diligence/' + file_name.name
    s3_client.upload_file(file_name, Bucket=bucket_name, Key=key)
    pre_signed_url = s3_client.generate_presigned_url(ClientMethod="get_object",
                                                      Params={'Bucket': bucket_name, 'Key': key},
                                                      ExpiresIn=3600
                                                      )
    return pre_signed_url

def create_session(agent_host, user_id):
    payload = {
        "user_id": user_id,
        "session_name": user_id,
        "client_id": "test",
        }
    payload = json.dumps(payload)
    headers = {"Content-Type": "application/json"}
    response = requests.request("POST", agent_host + "/api/v1/proxy/sessions", headers=headers, data=payload)
    session_id = response.json()["data"]["session_id"]
    print(f"Session ID: {session_id}")
    return session_id

def process_payload(agent_host, user_id, session_id, message, intent, documents, headers, highlighted_section=""):
    output_html_path = Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_output.html"


    payload = {
        "user_id": user_id,
        "session_id": session_id,
        "message": message,
        "streaming": True,
        "intent": intent,
        "headers": headers,
        }

    if documents:
        payload["docs"] = [
            {
                "document_display_name": document.document_display_name,
                "upload_identifier": document.upload_identifier,
                "upload_link": document.upload_link,
                "document_page_count": document.document_page_count,
                "document_character_count": document.document_character_count,
                }
            for document in documents
            ]

    if highlighted_section:
        payload["highlighted_section"] = highlighted_section

    payload = json.dumps(payload)
    with open(Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_request.json", "w") as f:
        f.write(payload)
    url = agent_host + "/api/v1/messages_stream"

    with requests.Session() as session:
        with session.post(url, headers=headers, data=payload, stream=True) as response:
            with open(output_html_path, "w", encoding="utf-8") as html_file:
                for line in response.iter_lines():
                    if line:  # filter out keep-alive new chunks
                        line = line.decode("utf-8")
                        if line.startswith(": ping"):
                            continue
                        line = line[len("data: ") :]
                        draft_dict = json.loads(line)
                        html_file.write(f"<p>{json.dumps(draft_dict)}</p>\n")
                        print(draft_dict)
                        if draft_dict["detail-type"] == "conversational-manager-message-finished":
                            return draft_dict

def main():
    CURR_ENV = "dev"
    user_id = ENV_DATA[CURR_ENV]["id"]
    agent_host = ENV_DATA[CURR_ENV]["url"]
    message = "Perform the following skill service: Issue Analysis"
    intent = "ma_issue_analysis_skill"
    file_paths = [
        Path("/Users/elayadim/projects/llm/rag/rag/plans/lexis_plus_ai_us/tests/chains/analyze/resources/test_doc_2.pdf"),
        Path("/Users/elayadim/projects/llm/rag/rag/plans/lexis_plus_ai_us/tests/chains/analyze/resources/test_doc_1.pdf")
    ]
    # Create a session
    session_id = create_session(agent_host, user_id)

    # Upload the document
    uploader = FileUploader(CURR_ENV)
    documents = []
    for file_path in file_paths:
        document, headers = uploader.upload_file(file_path)
        document.upload_link = document.upload_link.replace("/docx", "/docxhtml")
        documents.append(document)
        print(document.upload_link)
    headers["x-ln-output-format"] = "json"


    output = process_payload(agent_host, user_id, session_id, message, intent, documents, headers, highlighted_section="")
    with open(Path("/Users/elayadim/projects/llm/rag/data/tmp/") / f"{intent.replace('/', '_')}_output.json", "w") as f:
        json.dump(output, f, indent=2)

    return output


if __name__ == "__main__":
    print(main())
