# Contract between Application Load Balancer and Lambda function

## ALB → Lambda Event Structure (Request)

When an ALB invokes a Lambda, it sends an event with this exact structure:

```python
{
    # REQUIRED FIELDS
    "requestContext": {              # dict, REQUIRED
        "elb": {                     # dict, REQUIRED
            "targetGroupArn": str    # REQUIRED - ARN of the target group
        }
    },
    "httpMethod": str,               # REQUIRED - "GET", "POST", "PUT", etc.
    "path": str,                     # REQUIRED - URL path like "/clause-identification/analyze"
    "headers": dict,                 # REQUIRED - all HTTP headers as key-value pairs (lowercase keys)
    "body": str | None,              # REQUIRED - request body as string, or None if no body
    "isBase64Encoded": bool,         # REQUIRED - true if body is base64-encoded binary data

    # OPTIONAL FIELDS
    "queryStringParameters": dict | None,  # Query params as key-value, None if no params
    "multiValueHeaders": dict | None,      # Headers with multiple values (rare)
    "multiValueQueryStringParameters": dict | None  # Query params with multiple values (rare)
}
```

### Field Details:

**`requestContext.elb.targetGroupArn`** (string, REQUIRED)
- Example: `"arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/my-targets/50dc6c495c0c9188"`
- Used by Lambda to identify which target group invoked it

**`httpMethod`** (string, REQUIRED)
- One of: `"GET"`, `"POST"`, `"PUT"`, `"DELETE"`, `"PATCH"`, `"HEAD"`, `"OPTIONS"`
- Always uppercase

**`path`** (string, REQUIRED)
- Example: `"/clause-identification/analyze"`
- Does NOT include query string
- Always starts with `/`

**`headers`** (dict, REQUIRED)
- Keys are lowercase (ALB normalizes them)
- Example:
  ```python
  {
      "accept": "application/json",
      "content-type": "application/json",
      "content-length": "145",
      "host": "my-alb-123456.us-east-1.elb.amazonaws.com",
      "x-forwarded-for": "203.0.113.1",
      "x-forwarded-proto": "https",
      "x-forwarded-port": "443"
  }
  ```

**`body`** (string or None, REQUIRED)
- If no body: `None` or `""`
- If JSON: stringified JSON like `'{"key": "value"}'`
- If binary and base64-encoded: base64 string
- **Always a string, never a dict!** You must parse JSON yourself

**`isBase64Encoded`** (bool, REQUIRED)
- `true` if body is base64-encoded binary
- `false` for text/JSON
- If true, you must base64-decode the body

**`queryStringParameters`** (dict or None, OPTIONAL)
- Example: `{"filter": "active", "limit": "10"}`
- `None` if no query parameters
- Single value per key (most common case)

**`multiValueQueryStringParameters`** (dict or None, OPTIONAL)
- Example: `{"id": ["123", "456"]}`  (for `?id=123&id=456`)
- Used when same parameter appears multiple times
- `None` if not present

**`multiValueHeaders`** (dict or None, OPTIONAL)
- Example: `{"accept": ["application/json", "text/html"]}`
- Used when same header appears multiple times (rare)
- `None` if not present

---

## Lambda → ALB Response Structure (Response)

Your Lambda **must** return this exact structure:

```python
{
    # REQUIRED FIELDS
    "statusCode": int,               # REQUIRED - HTTP status code (100-599)
    "headers": dict,                 # REQUIRED - response headers as key-value pairs
    "body": str,                     # REQUIRED - response body as string

    # OPTIONAL FIELDS
    "isBase64Encoded": bool,         # OPTIONAL - true if body is base64-encoded, default false
    "statusDescription": str,        # OPTIONAL - custom status text like "200 OK"
    "multiValueHeaders": dict        # OPTIONAL - headers with multiple values
}
```

### Field Details:

**`statusCode`** (integer, REQUIRED)
- Must be valid HTTP status code: 100-599
- Examples: `200`, `201`, `400`, `404`, `500`
- **Must be integer, not string!** `200` not `"200"`

**`headers`** (dict, REQUIRED)
- Response headers as key-value pairs
- Keys are case-insensitive but typically Title-Case
- Common headers:
  ```python
  {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Cache-Control": "no-cache"
  }
  ```
- **Can be empty dict `{}`** but cannot be omitted

**`body`** (string, REQUIRED)
- Response body as string
- If returning JSON: stringify it like `json.dumps({"result": "success"})`
- If returning HTML: HTML as string
- **Cannot be None** - use `""` for empty body
- **Always a string, never a dict!**

**`isBase64Encoded`** (bool, OPTIONAL)
- Default: `false` if omitted
- Set to `true` if body contains base64-encoded binary data
- ALB will decode it before sending to client

**`statusDescription`** (string, OPTIONAL)
- Custom status text like `"200 OK"` or `"404 Not Found"`
- If omitted, ALB uses standard HTTP status descriptions

**`multiValueHeaders`** (dict, OPTIONAL)
- For sending multiple values for same header
- Example: `{"Set-Cookie": ["session=abc123", "prefs=xyz"]}`

---

## Complete Example

### Request from ALB to Lambda:
```python
{
    "requestContext": {
        "elb": {
            "targetGroupArn": "arn:aws:elasticloadbalancing:us-east-1:164682029196:targetgroup/clause-id-tg/abc123"
        }
    },
    "httpMethod": "POST",
    "path": "/clause-identification/analyze",
    "queryStringParameters": {
        "format": "detailed"
    },
    "headers": {
        "content-type": "application/json",
        "content-length": "89",
        "host": "my-alb.us-east-1.elb.amazonaws.com",
        "x-forwarded-for": "203.0.113.1",
        "x-forwarded-proto": "https"
    },
    "body": "{\"document_input\": {\"text_input\": {\"content\": \"Sample contract text\"}}}",
    "isBase64Encoded": false
}
```

### Response from Lambda to ALB:
```python
{
    "statusCode": 200,
    "statusDescription": "200 OK",
    "headers": {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-cache"
    },
    "body": "{\"success\": true, \"clauses\": [{\"type\": \"termination\", \"text\": \"...\"}]}",
    "isBase64Encoded": false
}
```

---

## Common Mistakes

1. **Body not stringified**
   - ❌ `"body": {"key": "value"}`
   - ✅ `"body": "{\"key\": \"value\"}"`

2. **statusCode as string**
   - ❌ `"statusCode": "200"`
   - ✅ `"statusCode": 200`

3. **Missing required fields**
   - ❌ Omitting `headers` or `body`
   - ✅ Include all required fields, use `{}` and `""` if empty

4. **Forgetting to parse body in request**
   - ❌ `event["body"]["key"]` (body is string, not dict!)
   - ✅ `json.loads(event["body"])["key"]`

5. **Headers case sensitivity**
   - ALB lowercases request headers
   - Response headers are case-insensitive but conventionally Title-Case

This contract is **strict** - violating it will cause ALB integration failures!
