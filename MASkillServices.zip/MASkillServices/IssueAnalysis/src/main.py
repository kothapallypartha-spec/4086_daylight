import json
import os
import re
import traceback
from fastapi import FastAPI, HTTPException
from typing import Dict, Any, List
from pydantic import BaseModel, Field
from issue_identification_agent import (
    issue_identification_agent,
    Document,
    ClauseAnalysis,
    IssueIdentificationOutput
)
from typing import List
from mangum import Mangum

from aws.logger import get_logger
import urllib.request
import html2text

logger = get_logger()
logger.info("Logger initialized")
app = FastAPI(title="Simple Issue Identification API")

MODEL_NAME = os.getenv("MODEL_NAME", "OpenAI_gpt-4.1-2025-04-14_Daylight_US_3363_nonprod")

class IdentifyRequest(BaseModel):
    """
    This is where we validate the input side of the APP TEAM'S API contract.
    We do not need to validate the ALB→Lambda contract here, that is done in the wrapper.
    """
    document_input: Document
    # more fields as needed, e.g., authentication tokens, request metadata
    model_name: str = Field(MODEL_NAME, description="The name of the model to use for processing")


class ErrorResponse(BaseModel):
    error: str = Field(..., description="Error message")
    traceback: str = Field(..., description="Traceback of the error")
    statusCode: int = Field(500, description="HTTP status code")

    @classmethod
    def from_exception(cls, e: Exception) -> "ErrorResponse":
        tb = traceback.format_exception(type(e), e, e.__traceback__)
        return cls(error=str(e), traceback="".join(tb), statusCode=500)

    @classmethod
    def from_error_message(cls, error: str, statusCode: int = 500) -> "ErrorResponse":
        return cls(error=error, traceback="", statusCode=statusCode)


class OutputModel(BaseModel):
    document_name: str = Field(..., description="Source document filename")
    clauses: List[IssueIdentificationOutput] = Field(..., description="List of analyzed clauses with linked structured risks")


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    return {"ok": True}


LambdaOutput = ErrorResponse | IssueIdentificationOutput

@app.post("/")
@app.post("/issue-analysis/")
async def identify_issues(identify_req: IdentifyRequest) -> LambdaOutput:
    """
    FastAPI automatically parses the request body into IdentifyRequest model.
    """
    logger.info(f"Received request for document: {identify_req.document_input.file_name}")
    # result: ErrorResponse | OutputModel = ErrorResponse.from_error_message(
    #     error="Unknown error occurred before processing", statusCode=500
    # )
    try:
        document = identify_req.document_input
        if not document.content:
            if not document.url:
                raise ValueError("Either content or url must be provided.")
            if re.match(".*-la-sp-upload.route53.lexis.com.*upload", document.url) and ("artifacts" not in document.url):
                logger.warning("Manipulating upload URL to point to docxhtml directly")
                document.url = document.url.replace("upload/", "upload/artifacts/")
            req = urllib.request.Request(document.url, headers=document.headers or {})
            with urllib.request.urlopen(req) as response:
                document.html_content = response.read().decode('utf-8')
            h = html2text.HTML2Text()
            document.content = h.handle(document.html_content)
        identification_output = issue_identification_agent(
            document,
            model_name=identify_req.model_name,
            context=None
        )
    except Exception as e:
        logger.exception(e)
        raise HTTPException(
            status_code=500,
            detail=repr(e)
            )
    def f(obj):
        if isinstance(obj, IssueIdentificationOutput):
            return obj.model_dump()
        raise TypeError("Object of type %s is not JSON serializable" % type(obj).__name__)
    return identification_output


handler = Mangum(app, lifespan="off")
