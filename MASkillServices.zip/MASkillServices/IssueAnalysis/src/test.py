from pathlib import Path
from typing import List

import fitz  # PyMuPDF (pip install pymupdf)
from llm_proxy_openai import OpenAI_Like
from pydantic import BaseModel, Field


class BoundaryCheckResult(BaseModel):
    query: str = Field(..., description="Business query the custom column enforces")
    satisfied: bool = Field(..., description="True if boundary conditions are met")
    reasoning: str = Field(..., description="LLM's explanation")
    citations: List[str] = Field(default_factory=list, description="Snippets supporting the decision")


def extract_pdf_text(pdf_path: Path) -> str:
    """Extract plain text from a PDF using PyMuPDF."""
    doc_text = []
    with fitz.open(pdf_path) as pdf:
        for page in pdf:
            doc_text.append(page.get_text("text"))
    return "\n".join(doc_text)


def build_prompt(document_text: str, query: str, boundary_description: str) -> list[dict[str, str]]:
    system_msg = (
        "You are an M&A legal assistant evaluating whether a document satisfies a boundary condition. "
        "Use only the provided text. If evidence is unclear, say so."
    )
    user_msg = (
        f"=== DOCUMENT TEXT ===\n{document_text}\n\n"
        f"=== QUERY ===\n{query}\n\n"
        f"=== BOUNDARY CONDITION ===\n{boundary_description}\n\n"
        "Determine if the document satisfies the boundary condition. "
        "Respond in JSON with keys: satisfied (true/false), reasoning, citations (list of supporting quotes)."
    )
    return [{"role": "system", "content": system_msg}, {"role": "user", "content": user_msg}]


def evaluate_boundary_condition(pdf_path: str, query: str, boundary_description: str, model: str) -> BoundaryCheckResult:
    document_text = extract_pdf_text(Path(pdf_path))
    prompts = build_prompt(document_text, query, boundary_description)

    client = OpenAI_Like(model_name=model, timeout=300)
    completion = client.chat.parse(
        model=model,
        messages=prompts,
        response_format=BoundaryCheckResult,
    )
    return completion.choices[0].message.parsed


if __name__ == "__main__":
    pdf_file = "file:///C:/Users/kothapap/Downloads/(20)%20PSA%20(EDGAR)%20(BitDigitalInc_20250416_8-K_EX-101_SalesPurchaseAgreement)%20(industrial%20or%20data%20center)%20(NC).pdf"
    query_text = "Does the agreement include a 30-day termination for convenience clause?"
    boundary = "Custom column requires explicit 30-day termination notice language with any penalties."
    model_name = "OpenAI_gpt-5.1-2025-11-13_Daylight-RE_nonprod"

    result = evaluate_boundary_condition(pdf_file, query_text, boundary, model_name)
    print(result.model_dump_json(indent=2))