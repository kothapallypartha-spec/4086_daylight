#!/bin/bash -xe

URL="https://ddc4c-get-lplus-ai-services.route53.lexis.com/vault-enricher/"

DOC_URL="https://www.supremecourt.gov/orders/courtorders/040825zr_1b8e.pdf"

curl -k -X POST "${URL}" -H "Content-Type: application/json" \
    -d "$(jq -n --arg content "$BIGSTRING" "{filename_stem: \"supremecourt\", presigned_url: \"$DOC_URL\"}")" | jq .
