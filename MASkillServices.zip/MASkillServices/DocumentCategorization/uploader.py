#!/usr/bin/env python3
import os
import sys
import json
import boto3
import requests
from botocore.config import Config
from pathlib import Path


def generate_presigned_url(file_path: Path) -> str:
    """Upload file to S3 and generate a pre-signed URL"""
    retry_config = Config(
        retries={
            'max_attempts': 5,
            'mode': 'standard'
        }
    )

    # Configure AWS
    os.environ["AWS_DEFAULT_REGION"] = "us-east-1"
    os.environ["AWS_PROFILE"] = "product-newlexis-dev-lexisadvancedeveloper"

    bucket_name = "11346-due-diligence-ma-688136498438"
    s3_client = boto3.client('s3', config=retry_config)

    # Upload file to S3
    key = 'presigned_urls/' + file_path.name
    print(f"Uploading {file_path.name} to S3...")
    s3_client.upload_file(str(file_path), Bucket=bucket_name, Key=key)

    # Generate pre-signed URL
    pre_signed_url = s3_client.generate_presigned_url(
        ClientMethod="get_object",
        Params={'Bucket': bucket_name, 'Key': key},
        ExpiresIn=3600
    )

    return pre_signed_url


def invoke_lambda_service(presigned_url: str, filename_stem: str) -> dict:
    """Invoke the Lambda service with the pre-signed URL"""
    url = "https://ddc4c-get-lplus-ai-services.route53.lexis.com/vault-enricher/"

    payload = {
        "filename_stem": filename_stem,
        "presigned_url": presigned_url
    }

    print(f"Invoking Lambda service at {url}...")
    print(f"Payload: {json.dumps(payload, indent=2)}")

    response = requests.post(
        url,
        headers={"Content-Type": "application/json"},
        json=payload,
        verify=False        # skip SSL verification
    )
    response.raise_for_status()
    return response.json()


def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <file_path> [filename_stem]")
        sys.exit(1)

    file_path = Path(sys.argv[1])

    if not file_path.exists():
        print(f"Error: File {file_path} does not exist")
        sys.exit(1)

    # Use provided filename_stem or derive from file
    if len(sys.argv) >= 3:
        filename_stem = sys.argv[2]
    else:
        filename_stem = file_path.stem

    print(f"Processing file: {file_path}")
    print(f"Using filename_stem: {filename_stem}")
    print("-" * 50)

    # Step 1: Upload to S3 and get pre-signed URL
    presigned_url = generate_presigned_url(file_path)
    print(f"Pre-signed URL generated: {presigned_url[:100]}...")
    print("-" * 50)

    # Step 2: Invoke Lambda service
    result = invoke_lambda_service(presigned_url, filename_stem)
    print("Lambda Response:")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
