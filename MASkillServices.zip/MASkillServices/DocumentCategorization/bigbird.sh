#!/bin/bash -xe

URL="https://ddc4c-get-lplus-ai-services.route53.lexis.com/vault-enricher/"

BIGSTRING=$(cat << 'EOF'
COOKIE SHARING AGREEMENT

Parties: Big Bird ("Provider") and Cookie Monster ("Recipient")
Date: September 17, 2025
Agreement Terms

Cookie Provision: Big Bird agrees to provide Cookie Monster with three (3) chocolate chip cookies per week.
Delivery: Cookies will be delivered every Monday at 2:00 PM to Cookie Monster's trash can.
Payment: In exchange, Cookie Monster agrees to help Big Bird organize his nest once per month.
Quality: All cookies must be fresh-baked and contain real chocolate chips.
Term: This agreement lasts for one (1) month from the date signed.
Termination: Either party may terminate with 24 hours written notice.

Signatures
Big Bird: _________________________ Date: _________
Cookie Monster: _________________________ Date: _________

This agreement is governed by the laws of Sesame Street.
EOF
)

curl -k -X POST "${URL}" -H "Content-Type: application/json" \
    -d "$(jq -n --arg content "$BIGSTRING" '{filename_stem: "bigbird", content: $content}')" | jq .
