# Introduction

This project provides an automated pipeline for querying Splunk logs, extracting and processing chat session data, and evaluating the usefulness of AI-generated legal drafts using LLM-as-judge prompts. The pipeline is designed for legal analytics and monitoring, with all data stored and processed using AWS S3.

The main objectives are:
- Automate the extraction of relevant chat data from Splunk.
- Process and flatten chat logs for downstream analysis.
- Evaluate the usefulness of AI-generated legal content using LLM-based prompts.
- Store all intermediate and final results in S3 for further analysis and dashboarding.

# Getting Started

## Installation

1. Clone the repository.
2. Install Python dependencies (see requirements.txt).
3. Configure AWS credentials and Splunk access in `config.py`.

## Usage

- To run the full pipeline for the current date, use the Lambda handler or run `lambda.py` locally.
- The pipeline will:
  1. Query Splunk for chat logs for the current day.
  2. Process and flatten the logs, saving results to S3 in `mm_dd_yyyy.csv` format.
  3. Analyze the daily sample, evaluate usefulness scores, and save processed results to S3.

# Build and Test

- Run `python lambda.py` for local testing.
- Unit tests can be added for each module.

# Contribute

- Fork the repository and submit pull requests.
- Open issues for bugs or feature requests.

For more details, see the code comments and configuration files.
