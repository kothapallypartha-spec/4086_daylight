import boto3
import json
import pprint

def test_lambda():
    # Create Lambda client
    lambda_client = boto3.client('lambda')

    function_name = "vault-enricher"

    # Test payload - our lambda is an auto mechanic, ask a car question
    test_event = {
        "body": "What tires do you recommend for a New England winter?"
    }

    try:
        print("Invoking Lambda function...")
        response = lambda_client.invoke(
            FunctionName=function_name,
            InvocationType='RequestResponse',  # Synchronous
            Payload=json.dumps(test_event)
        )

        response_payload: dict[str, str | int] = json.loads(response['Payload'].read())
        assert isinstance(response_payload, dict), reponse_payload
        assert response_payload.get("status_code") == 200, response_payload
        assert "Success" in str(response_payload.get("status")), response_payload
        assert "response" in response_payload, response_payload
        answer = response_payload["response"] if "response" in response_payload else str(response_payload)
        print(answer)

        # Check for errors
        if 'FunctionError' in response:
            print(f"Function Error: {response['FunctionError']}")

    except Exception as e:
        print(f"Error invoking Lambda: {str(e)}")

if __name__ == "__main__":
    test_lambda()
