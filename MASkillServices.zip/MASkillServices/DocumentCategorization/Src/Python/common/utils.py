import datetime
import logging

from pathlib import Path
import inspect

logger = logging.getLogger(__name__)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(filename)s:%(lineno)d - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)
logger.propagate = False


def get_day_earliest_and_latest(year, month, day, start_hour, end_hour):
    date = datetime.date(year, month, day)
    earliest = date.strftime(f"%m/%d/%Y:{start_hour:02d}:00:00")
    latest = date.strftime(f"%m/%d/%Y:{end_hour:02d}:00:00")
    return earliest, latest


def get_splunk_query(SPLUNK_QUERY, earliest, latest):
    search_query = SPLUNK_QUERY.replace("{earliest}", earliest).replace("{latest}", latest)
    return search_query


# create auxiliary variables
logger_name = Path(inspect.stack()[-1].filename).stem
logger = logging.getLogger(logger_name)
logger.setLevel(logging.INFO)
log_formatter = logging.Formatter('%(asctime)s:%(name)s:%(levelname)s:%(message)s', "%Y-%m-%d %H:%M:%S")

# create console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(log_formatter)

# Add console handler to logger
logger.addHandler(console_handler)