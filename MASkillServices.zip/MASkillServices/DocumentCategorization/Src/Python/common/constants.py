# Splunk configuration constants
SPLUNK_HOST = 'lexisnexis.splunkcloud.com'
SPLUNK_PORT = 8089
SPLUNK_KWARGS_ONESHOT = {"exec_mode": "normal"}
SPLUNK_NUM_RETRIES = 10

# Loguru configuration
LOG_FILE = "chat_parser.log"
LOG_ROTATION = "10 MB"
LOG_RETENTION = "7 days"
LOG_LEVEL = "INFO"

# Chat API configuration
CHAT_API_URL_TEMPLATE = "https://agent-svc.us.3363-rag-us-prod.sk8s.aws.lexis.com/api/v1/proxy/sessions/{chat_id}/messages"
ASYNC_SEMAPHORE_LIMIT = 10
BATCH_SIZE = 2000

# analyze_daily_sample.py configuration
ANALYZE_LOG_FILE = "analyze_daily_sample.log"
ANALYZE_LOG_ROTATION = "1 MB"
ANALYZE_LOG_RETENTION = "7 days"
ANALYZE_LOG_LEVEL = "INFO"

DATA_PATH = "../daily_sample_data"
DATA_OUTPUT_PATH = "../daily_sample_data_processed_new"
SAMPLE_SIZE = 250
CONCURRENCY_LIMIT = 10

PROXY_API_URL = "https://cert-proxy-api.search.use1.dev-fos.nl.lexis.com/proxy/OpenAI_US_3363_GPT4o_1120_nonprod"
PROXY_API_MODEL = "OpenAI_US_3363_GPT4o_1120_nonprod"
PROXY_API_BREAKER_STRATEGY = "return"
PROXY_API_PRIORITY = "high"
PROXY_API_MAX_TOKENS = 4096
PROXY_API_TEMPERATURE = 0
PROXY_API_ASSET_ID = "4086"

# S3 configuration
S3_BUCKET = "4086-lexis-plus-ai"
S3_DASHBOARD_PREFIX = "monitoring-dashboard/"
S3_LAMBDA_PREFIX = "draft-data-analysis/"
S3_DAILY_SAMPLE_PREFIX = f"{S3_LAMBDA_PREFIX}prod_daily_samples/"
S3_DAILY_COMPLETE_PREFIX = f"{S3_LAMBDA_PREFIX}prod_daily_all_queries/"
S3_DAILY_USEFULNESS_PREFIX = f"{S3_LAMBDA_PREFIX}prod_daily_samples_usefulness_scores/"
S3_DAILY_DRAFT_EVAL_TIME_SAVING_PREFIX = f"{S3_LAMBDA_PREFIX}prod_daily_draft_eval_time_saving/"
S3_DAILY_SPLUNK_PREFIX = f"{S3_LAMBDA_PREFIX}prod_daily_splunk/"
S3_DAILY_SPLUNK_UF_PREFIX = f"{S3_LAMBDA_PREFIX}prod_daily_splunk_uf/"
S3_DAILY_SPLUNK_IF_PREFIX = f"{S3_LAMBDA_PREFIX}prod_daily_splunk_if/"
S3_DAILY_SCORES_JSON = f"{S3_DASHBOARD_PREFIX}daily_scores.json"
S3_DAILY_TIME_SAVINGS_JSON = f"{S3_DASHBOARD_PREFIX}daily_time_savings.json"
S3_DAILY_ERROR_STATS_JSON = f"{S3_DASHBOARD_PREFIX}daily_error_stats.json"

# Time saved mapping for genAIActivityName
TIME_SAVED_MAP = {
    "usefulness_judge": 3,
    "generate_eval": 0.5,
    "generate_search_results_eval": 0.5,
    "report_metrics_generation": 0,
    "report_analyze_comments": 0.5
}

# Optionally add:
# S3_AWS_ACCESS_KEY_ID = "your-access-key"
# S3_AWS_SECRET_ACCESS_KEY = "your-secret-key"
# S3_REGION_NAME = "your-region"

# AWS Secrets Manager configuration
AWS_SECRET_NAME = "2591-ilabs-monitoring-dashboard"
AWS_REGION_NAME = "us-east-1"
AWS_PROFILE = "product-lexisai-dev-lexisaideveloper"
