import sys
import os
import json
import logging
import datetime
import hashlib
import traceback
from typing import Any
import boto3
from datetime import datetime

from pydantic import BaseModel, Field

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DEBUG = False

REGION = os.environ.get("Region", "us-east-1")

IO_BUCKET = os.environ.get("IO_BUCKET", "2591-contract-analysis-us-east-1-688136498438")
IO_LOC = os.environ.get("IO_LOC", "io")
CLAUSE_REC_IO_BUCKET = os.environ.get("CLAUSE_REC_IO_BUCKET", "3111-contract-analysis-us-east-1-688136498438")


def download_file_s3(file_name, loc=IO_LOC, bucket=IO_BUCKET, is_binary=False):
    try:
        s3 = boto3.client("s3")
        key = f"{loc}/{file_name}"
        logger.info(f"Reading file: s3://{bucket}/{key}")
        s3_clientobj = s3.get_object(Bucket=bucket, Key=key)
        body = s3_clientobj["Body"].read()
        if not is_binary:
            body = body.decode("utf-8", "ignore")
        return body
    except Exception as e:
        logger.error(f"Unable to download file: s3://{bucket}/{loc}/{file_name}. Error: {repr(e)}")
    return None


def upload_file_s3(file_content, object_name, loc=IO_LOC, bucket=IO_BUCKET):
    try:

        s3 = boto3.client("s3")
        key = f"{loc}/{object_name}"
        logger.info(f"Uploading output to {key} in s3")
        # date_time = datetime.datetime.now() + datetime.timedelta(seconds=5)
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=file_content,
            ServerSideEncryption="AES256"
        )
        return key
    except Exception as e:
        logger.error(f"Unable to upload file")
        logger.error(e)
        return None


def delete_file_s3(object_name, loc=IO_LOC, bucket=IO_BUCKET):
    try:
        s3 = boto3.resource("s3")
        KEY = f"{loc}/{object_name}"
        logger.info(f"Deleting file:{object_name} from {KEY}")
        response = s3.Bucket(bucket).delete_objects(Delete={'Objects': [{'Key': KEY}]})   # type: ignore
        errors = response.get('Errors', [])
        if len(errors):
            message = errors[0].get('Message', 'Unable to delete file')
            logger.error(message)
            return 400, message
        else:
            return 200, f"successfully deleted {bucket}/{KEY}"
    except Exception as e:
        logger.error(f"Unable to delete file:{object_name}")
        logger.error(e)
    return 400, f"Unable to delete file:{object_name}"


def get_document_from_file(file_name, bucket=IO_BUCKET):
    try:
        content = download_file_s3(file_name, bucket=bucket)
        if content is None:
            logger.error(f"Unable to download file from S3: {file_name}")
            return None

    except Exception as e:
        logger.error(f"Unable to download file from S3: {file_name}")
        logger.error(e)
        return None

    return content


class ErrorResponse(BaseModel):
    error: str = Field(..., description="Error message")
    traceback: str = Field(..., description="Traceback of the error")
    statusCode: int = Field(500, description="HTTP status code")

    @classmethod
    def from_exception(cls, e: Exception) -> "ErrorResponse":
        tb = traceback.format_exception(type(e), e, e.__traceback__)
        return cls(error=str(e), traceback="".join(tb), statusCode=500)

    @classmethod
    def from_error_message(cls, error: str, statusCode: int = 500) -> "ErrorResponse":
        return cls(error=error, traceback="", statusCode=statusCode)


def create_response_body(output: BaseModel) -> dict[str, Any]:
    """
    Given a Lambda output pydantic model, create a response body that can be passed to a load balancer.

    [Rules of engagement for AppLoadBalancer & Lambda](
    https://docs.aws.amazon.com/elasticloadbalancing/latest/application/lambda-functions.html)

    - The Lambda function must be configured to handle the event JSON format sent by the load balancer.
    - The response from your Lambda function must be in JSON format and must include the following keys:
      isBase64Encoded, statusCode, statusDescription, headers, body
        - The statusCode must be a valid HTTP status code.
        - The statusDescription must be a string that includes the status code and a brief description (e.g., "200 OK").
        - The headers must be a dictionary of key-value pairs representing HTTP headers.
        - The body must be a string containing the response payload. The body is typically a JSON string.
        - The body can be base64-encoded if isBase64Encoded is set to true.
    - The total size of the response (including all keys) must not exceed 1 MB. If it does, upload
      the response to S3 and return a reference to the S3 object in the body.
    """
    failed = isinstance(output, ErrorResponse)
    assert isinstance(output, BaseModel), "output must be a Pydantic model"
    output_data = output.model_dump()
    json_output = json.dumps(output_data).encode("utf-8", "ignore")
    if DEBUG:
        date_time = datetime.now().strftime("%m-%d-%Y_%H-%M-%S")
        with open(f"contract-parser-output-{date_time}.json", encoding="utf-8", mode="w") as outf:
            json.dump(output_data, outf, indent=4)

    if sys.getsizeof(json_output) > 921600:
        msg = hashlib.sha256(json_output).hexdigest()
        object_name = f"{msg}.json"
        s3_key = upload_file_s3(json_output, object_name)
        payload = {"response_type": "s3"}
        if s3_key is None:
            payload['error'] = "Unable to upload file to S3"
            status_code = 403
        elif failed:
            payload['error'] = output.error
            status_code = output_data.get("statusCode", 500)
        else:
            payload['output_key'] = object_name  # s3_key
            status_code = 200
        return {"statusCode": status_code,
                "headers": {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST',
                    'Access-Control-Allow-Headers': '*'
                },
                "body": json.dumps(payload)}
    else:
        payload = {"response_type": 'inplace', "output": output_data}
        return {"statusCode": output_data.get("statusCode", 500) if failed else 200,
                "headers": {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST',
                    'Access-Control-Allow-Headers': '*'
                },
                "body": json.dumps(payload)}


STOPWORDS = frozenset([
    'a',
    'an',
    'and',
    'are',
    'as',
    'at',
    'be',
    'but',
    'by',
    'for',
    'if',
    'in',
    'into',
    'is',
    'it',
    'no',
    'not',
    'of',
    'on',
    'or',
    's',
    'such',
    't',
    'that',
    'the',
    'their',
    'then',
    'there',
    'these',
    'they',
    'this',
    'to',
    'was',
    'will',
    'with',
    'argument',
    'arguments'
])


def strip_puctuation(text):
    specials = '’‘´`“”§—…–•□▪○√¶'
    punctuation = '!"#%&\'*+/:;<=>?@\\^_`{|}~'  # unlike string.punctuation, omits $-.,[]()
    punctuation = punctuation + specials
    return text.translate(str.maketrans(punctuation, ' ' * len(punctuation), '[](),'))  # [](), to None


def count_stopwords(text):
    text = strip_puctuation(text.lower())
    is_stopword = [1 if w in STOPWORDS else 0 for w in text.split()]
    return sum(is_stopword)


def is_valid_clause(text):
    # if text.endswith(":"):
    #     return False
    # "exhibit" in text.lower() or \
    if "table of" in text.lower() or \
            "definitions" in text.lower() or \
            count_stopwords(text) < 10:
        return False
    return True
