import boto3
import pandas as pd
from io import StringIO
import json

class S3Manager:
    def __init__(self, bucket_name, profile=None):
        self.bucket_name = bucket_name
        session = boto3.Session(profile_name=profile) if profile else boto3.Session()
        self.s3 = session.client("s3")

    def write_df(self, df, s3_key):
        """Write a pandas DataFrame to S3 as a CSV."""
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_buffer.seek(0)
        self.s3.put_object(Bucket=self.bucket_name, Key=s3_key, Body=csv_buffer.getvalue())

    def read_df(self, s3_key):
        """Read a CSV from S3 into a pandas DataFrame."""
        obj = self.s3.get_object(Bucket=self.bucket_name, Key=s3_key)
        return pd.read_csv(obj['Body'])

    def read_json_df(self, s3_key):
        """Read a JSON object from S3 into a pandas DataFrame."""
        obj = self.s3.get_object(Bucket=self.bucket_name, Key=s3_key)
        json_bytes = obj['Body'].read()
        json_str = json_bytes.decode('utf-8')
        data = json.loads(json_str)
        return pd.DataFrame(data)
