# lambda.py
import os
os.environ["MODEL_NAME"] = "anthropic-claude-3-7-sonnet-20250219_Daylight_3363_nonprod"


from typing import List, Optional, Union


import sys
import logging
import json
from pydantic import BaseModel, Field
from common.cal_utils import create_response_body, ErrorResponse, download_file_s3


LOG_LEVEL = "INFO"
logging.basicConfig(
    level=LOG_LEVEL,
    format='%(asctime)s - %(name)s - %(filename)s:%(lineno)d - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger()


class InputModel(BaseModel):
    embeddings: Optional[List[float]] = Field(default=None, description="Precomputed embeddings for the document content.")
    texts: Optional[List[str]] = Field(default=None, description="List of text segments from the document.")
    output_format: Optional[str] = Field(default="compact", description="Desired output format for the predicted document categories")
    top_k: Optional[int] = Field(default=3, description="Number of top predictions to return.")


class CategoryPrediction(BaseModel):
    category: str = Field(..., description="Predicted category or label for the document.")
    probability: float = Field(..., description="Probability score for the predicted category.")
    broader_category: Optional[str] = Field(default=None, description="Broader category or label for the document, if applicable.")


class DocumentTypePrediction(BaseModel):
    doctype: str = Field(..., description="Predicted document type.")
    probability: float = Field(..., description="Probability score for the predicted document type.")


class BroaderCategoryPrediction(BaseModel):
    broader_category: str = Field(..., description="Broader category or label for the document.")
    probability: float = Field(..., description="Probability score for the broader category.")


class DetailedPredictionResults(BaseModel):
    doctype_confidence: float = Field(..., description="Confidence score for the predicted document type.")
    document_types: List[DocumentTypePrediction] = Field(..., description="List of predicted document types with their probabilities.")
    category_confidence: float = Field(..., description="Confidence score for the predicted category.")
    categories: List[CategoryPrediction] = Field(..., description="List of predicted categories with their probabilities.")
    broader_category_confidence: float = Field(..., description="Confidence score for the predicted broader category.")
    broader_categories: List[BroaderCategoryPrediction] = Field(..., description="List of predicted broader categories with their probabilities.")


# Service initialization
# Load model, tokenizer, and other necessary components here
MODEL_BUCKET = os.environ["MODEL_BUCKET"]
MODEL_LOC = os.environ["MODEL_LOC"]
with open("/tmp/model.tar.gz", "wb") as f:
    f.write(
        download_file_s3("level1-clf-nn.tar.gz", bucket=MODEL_BUCKET, loc=MODEL_LOC)
        )


class OutputModel(BaseModel):
    results: Union[List[CategoryPrediction], DetailedPredictionResults] = Field(..., description="Predicted document categories or labels.")



def lambda_handler(event: dict, context):
    logger.info(f"Received event: {event}")
    if 'body' not in event:
        return create_response_body(ErrorResponse.from_error_message(
            error='"body" is required field for input request.',
            statusCode=400
        ))
    try:
        body = json.loads(event['body'])
        assert isinstance(body, dict), "Event body is not a valid JSON object"
        data = InputModel(**body)

        return create_response_body(data)
    except Exception as e:
        logger.error(f"Lambda execution failed: {str(e)}")
        logger.exception(e)
        return create_response_body(ErrorResponse.from_exception(e))

