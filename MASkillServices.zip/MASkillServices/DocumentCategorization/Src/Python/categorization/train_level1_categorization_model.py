from pathlib import Path

import pandas as pd
from utils.log import logger
from data_processing.categories_loader import create_train_valid_test_data_loaders
from categorization.categorizer import CategoryTrainer
import torch

torch.multiprocessing.set_start_method('fork', force=True)
torch.set_num_threads(8)

def train_model():
    """Test the CategoryTrainer with DocumentDataset"""
    # Paths and parameters
    data_dir = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/edgar_train"  # Adjust this path as needed
    transformation_file = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/document_categorization/prob_category_given_doc_type.xlsx"
    taxonomy_file = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/document_categorization/taxonomy_matrix.xlsx"
    model_dir = "/Users/elayadim/projects/llm/due_diligence_ma/model/categorization/level1_clf/jina-v2"
    input_dim = 768
    resume = True
    calibrate_scores = True

    # Load transformation and taxonomy
    transformation_df = pd.read_excel(transformation_file, index_col=0)
    taxonomy_df = pd.read_excel(taxonomy_file, index_col=0)

    # Create data loaders
    train_loader, val_loader, test_loader, doc_type_count, dataset = create_train_valid_test_data_loaders(
        data_dir, doc_types=transformation_df.index, val_ratio=0.1, test_ratio=0.1, batch_size=32
    )

    # Print dataset info
    logger.info(f"Dataset has {len(dataset)} samples with {doc_type_count} document types")
    logger.info(f"Training set: {len(train_loader.dataset)} samples")
    logger.info(f"Validation set: {len(val_loader.dataset)} samples")

    # Create and train model
    trainer = CategoryTrainer(
        input_dim=input_dim,
        hidden_dim=256,
        doc_types=transformation_df.index,
        category_names=transformation_df.columns,
        broad_categories=taxonomy_df.index,
        transformation_matrix=transformation_df.values,
        taxonomy_matrix=taxonomy_df.values,
        constraint_weight=0.001,
        calibrate_scores=calibrate_scores,
    )

    # Train for a few epochs
    model_path = Path(model_dir) / "best_category_model.pt"
    if resume and model_path.exists():
        logger.info(f"Loading existing model from {model_dir}")
        trainer.load(model_dir)
    trainer.train(train_loader, val_loader, epochs=100, lr=0.001, save_dir=model_dir)
    trainer.evaluate(test_loader)


if __name__ == "__main__":
    train_model()