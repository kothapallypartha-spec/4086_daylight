import json
import pandas as pd
import numpy as np
from pathlib import Path

from categorization.categorizer import LabelTransformationMatrix

def get_taxonomy_matrix(categ_info):
    uniq_broad_categories = categ_info["broad_category"].unique()
    broad_categ2index = {broad_categ: i for i, broad_categ in enumerate(uniq_broad_categories)}
    taxonomy_matrix = np.zeros((len(uniq_broad_categories), len(categ_info)))
    for i, row in categ_info.iterrows():
        taxonomy_matrix[broad_categ2index[row["broad_category"]], i] = 1
    taxonomy_matrix = taxonomy_matrix.astype(np.float32)

    categ2index = {categ: i for i, categ in enumerate(categ_info["category_name"])}

    return taxonomy_matrix, uniq_broad_categories, categ2index

def estimate_transformation_matrix(categ_info, doc_type_info, taxonomy_matrix, min_probability=0.95, known_mappings=None):

    label_transformer = LabelTransformationMatrix(doc_type_info["document_type"], categ_info["category_name"])
    similarity_matrix = label_transformer.compute_similarity_from_definitions(doc_type_info["definition"], categ_info["category_definition"], initial_weight=100)
    similarity_matrix = similarity_matrix.cpu().numpy()

    if known_mappings is None:
        matches = {}
        m, n = similarity_matrix.shape
        for i in range(m):
            category = categ_info["category_name"][i]
            matches[category] = {
                (doc_type, prob) for doc_type, prob in zip(doc_type_info["document_type"], similarity_matrix[i]) if prob > min_probability
            }
        known_mappings = [(doc_type, categ, score) for categ, v in matches.items() for doc_type, score in v]
    label_transformer.learn_parameters(known_mappings, taxonomy_matrix,learning_rate=0.01, iterations=10000, entropy_weight=0.3)

    return label_transformer

def main():
    data_dir = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/document_categorization"
    min_probability = 0.95
    top_k = 3
    cumulative_probability = 0.9
    load_transformation_matrix = False

    with open(Path(data_dir) / "categories_with_defs_new.json", "r") as f:
        categories_with_defs = json.load(f)
    with open(Path(data_dir) / "doc_types_defs_new.json", "r") as f:
        doc_types_with_defs = json.load(f)

    categ_info = pd.json_normalize(categories_with_defs["categories"], record_path=["items"], meta=["name"])
    categ_info.columns = ["category_name", "category_definition", "broad_category"]
    doc_type_info = pd.DataFrame(doc_types_with_defs.items(), columns=["document_type", "definition"])
    taxonomy_matrix, uniq_broad_categories, categ2index  = get_taxonomy_matrix(categ_info)
    known_mappings = pd.read_excel(Path(data_dir) / "known_mappings.xlsx", sheet_name="known_mappings").values.tolist()

    if load_transformation_matrix:
        label_transformer = LabelTransformationMatrix(categ_info["category_name"], doc_type_info["document_type"]).load(Path(data_dir) / "transformation_matrix.npz")
    else:
        doc_type_info.columns = ["document_type", "definition"]
        label_transformer = estimate_transformation_matrix(categ_info, doc_type_info, taxonomy_matrix, min_probability=min_probability, known_mappings=known_mappings)
        label_transformer.save(Path(data_dir) / "transformation_matrix.npz")

    prob_category_given_doc_type = transformation_matrix = label_transformer.transformation_matrix.cpu().numpy()
    prob_doc_type_given_category = np.copy(prob_category_given_doc_type.T)
    prob_doc_type_given_category /= prob_doc_type_given_category.sum(axis=1)[:, np.newaxis]
    prob_broad_category_given_doc_type = prob_category_given_doc_type @ taxonomy_matrix.T
    new_taxonomy = {}
    n_doc_types, n_broad_categ = prob_broad_category_given_doc_type.shape
    sorted_inds = np.argsort(1 - prob_broad_category_given_doc_type, axis=1)[:, :top_k]
    sorted_probs = np.take_along_axis(prob_broad_category_given_doc_type, sorted_inds, axis=1)
    cum_probs = np.cumsum(sorted_probs, axis=1)
    for i in range(n_doc_types):
        doc_type = doc_type_info["document_type"][i]
        j = max(np.sum(cum_probs[i] < cumulative_probability), 1)
        broad_categs = uniq_broad_categories[sorted_inds[i, :j]]
        for prob, broad_categ in zip(sorted_probs[i, :j], broad_categs):
            new_taxonomy[broad_categ] = new_taxonomy.get(broad_categ, []) + [(doc_type, prob)]

    doc_types = list(doc_type_info["document_type"])
    category_names = list(categ_info["category_name"])
    broad_categories = list(uniq_broad_categories)
    estimated_known_mappings = [
        (doc_types[i], category_names[j], prob_category_given_doc_type[i, j])
        for i, j in zip(*np.where(prob_category_given_doc_type > 0.2))
    ]
    writer = pd.ExcelWriter(Path(data_dir) / "estimated_known_mappings.xlsx", engine='xlsxwriter')
    pd.DataFrame(estimated_known_mappings, columns=["document_type", "category_name", "probability"]).to_excel(
        writer, sheet_name="estimated_known_mappings", index=False
    )
    pd.DataFrame(category_names, columns=["category_name"]).to_excel(
        writer, sheet_name="category_names", index=False
    )
    writer.close()
    pd.DataFrame(
        prob_broad_category_given_doc_type,
        index=doc_types,
        columns=broad_categories,
        ).to_excel(Path(data_dir) / "prob_broad_category_given_doc_type.xlsx")
    pd.DataFrame(
        prob_category_given_doc_type,
        index=doc_types,
        columns=category_names,
        ).to_excel(Path(data_dir) / "prob_category_given_doc_type.xlsx")
    pd.DataFrame(
        prob_doc_type_given_category,
        index=category_names,
        columns=doc_types,
        ).to_excel(Path(data_dir) / "prob_doc_type_given_category.xlsx")
    pd.DataFrame(
        taxonomy_matrix,
        index=broad_categories,
        columns=category_names,
        ).to_excel(Path(data_dir) / "taxonomy_matrix.xlsx")



if __name__ == "__main__":
    main()