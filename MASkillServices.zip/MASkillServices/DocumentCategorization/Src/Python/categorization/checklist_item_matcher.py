import numpy as np
from scipy.sparse import coo_array
from scipy.special import logit
from tqdm import tqdm

from document_retrieval.retrievers_setup import setup_retriever_lance_db
from utils.log import logger


def clean_search_results(results):
    return [
        {
            "id":  item["id"],
            "text": item["_source"]["text"], #[:300] + "...",
            "distance": item["_source"].get("_distance") or -item["_source"]["_score"],
            "doctype_confidence": item["_source"]["doctype_confidence"],
            "doctype1": item["_source"]["doctype1"],
            "doctype2": item["_source"]["doctype2"],
            "doctype3": item["_source"]["doctype3"],
            "category_confidence": item["_source"]["category_confidence"],
            "category1": item["_source"]["category1"],
            "category2": item["_source"]["category2"],
            "category3": item["_source"]["category3"],
            }
        for item in results
        ]

def add_retrieved_docs(checklist_json, top_k=5, search_method="lexical"):
    retriever = setup_retriever_lance_db(top_k=top_k, search_method=search_method)
    for _, items in tqdm(checklist_json.items()):
        for item in tqdm(items):
            checklist_category = item["category"]
            item["checklist_item_assignments"] = {}
            for checklist_item in item["checklist_items"]:
                item["checklist_item_assignments"][checklist_item] = clean_search_results(
                    retriever.search(checklist_item, checklist_category)
                    )
            item.pop("checklist_items", None)

def calibrate_matching_scores(checklist):
    def enhanced_index(x, y):
        assert len(x) == len(set(x))
        if y in x:
            return x.index(y)
        x.append(y)
        return x.index(y)
    all_doc_ids = []
    all_checklist_items = []
    coo_inds = {}
    for _, category_items in checklist.items():
        for category_item in category_items:
            for checklist_item, matched_docs in category_item["checklist_item_assignments"].items():
                i = enhanced_index(all_checklist_items, checklist_item)
                for doc in matched_docs:
                    j = enhanced_index(all_doc_ids, doc["id"])
                    if (i, j) not in coo_inds:
                        coo_inds[(i, j)] = -doc["distance"]
                    else:
                        logger.info(f"Duplicate match for {checklist_item} and {doc['id']}")
                        coo_inds[(i, j)] = -min(doc["distance"], coo_inds[(i, j)])
    doc_id2ind = {doc_id: ind for ind, doc_id in enumerate(all_doc_ids)}
    ind2doc_id = {ind: doc_id for doc_id, ind in doc_id2ind.items()}
    item_id2ind = {item: ind for ind, item in enumerate(all_checklist_items)}
    ind2item_id = {ind: item for item, ind in item_id2ind.items()}

    ij, log_scores = zip(*list(coo_inds.items()))
    row, col = zip(*ij)
    log_scores = coo_array((log_scores, (row, col))).todense()
    log_scores[np.where(np.isclose(log_scores, 0))] = log_scores.min() - 1
    q = np.arange(0.05, 0.96, 0.05)
    quantiles = np.quantile(np.unique(log_scores), q)
    coefficients = np.polyfit(quantiles, logit(q) , 1)
    log_scores = coefficients[0] * log_scores + coefficients[1]

    scores = np.exp(log_scores)
    probs0 = scores / (1e-10 + scores.sum(axis=0)[np.newaxis, :])
    scores *= probs0 > 0.05
    probs = scores / (1 + scores)

    new_matches = {}
    mask = probs > 0.1
    for i in range(mask.shape[0]):
        if not mask[i].any():
            continue
        new_matches[ind2item_id[i]] = [ind2doc_id[j] for j in  mask[i].nonzero()[0]]

    for category_items in checklist.values():
        for category_item in category_items:
            category_item["checklist_item_assignments"] = {
                checklist_item: [
                    doc | {"estimated_relevance": probs[item_id2ind[checklist_item], doc_id2ind[doc["id"]]]}
                    for doc in matched_docs if doc["id"] in new_matches.get(checklist_item, [])
                    ]
                for checklist_item, matched_docs in category_item["checklist_item_assignments"].items()
                }
