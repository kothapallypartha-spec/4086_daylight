import pandas as pd
import torch
from torch.utils.data import DataLoader

from data_processing.categories_loader import DocumentDataset, create_data_loaders
from utils.log import logger

def test_document_dataset(data_dir, taxonomy_file):
    """
    Test the DocumentDataset by loading and examining samples

    Args:
        data_dir: Directory containing npz files
    """
    logger.info(f"Testing DocumentDataset from: {data_dir}")

    # Create dataset
    taxonomy = pd.read_excel(taxonomy_file, index_col=0)
    dataset = DocumentDataset(data_dir, taxonomy)

    # Print dataset info
    logger.info(f"Dataset size: {len(dataset)} samples")
    logger.info(f"Document types: {dataset.doc_type_count} types")

    # Print label mappings
    logger.info("\nDocument type mapping (first 10):")
    for label, idx in sorted(dataset.doc_type_map.items(), key=lambda x: x[1])[:10]:
        count = dataset.label_counts[label]
        logger.info(f"  {idx}: {label} ({count} samples)")

    # Examine a few samples
    logger.info("\nSample data:")
    for i in range(min(3, len(dataset))):
        features, doc_type_label = dataset[i]

        doc_type_idx = torch.argmax(doc_type_label).item()
        doc_type_name = [k for k, v in dataset.doc_type_map.items() if v == doc_type_idx][0]

        logger.info(f"Sample {i}:")
        logger.info(f"  Features shape: {features.shape}")
        logger.info(f"  Document type label shape: {doc_type_label.shape}")
        logger.info(f"  Document type: {doc_type_name} (index {doc_type_idx})")

    # Test class weights
    doc_type_weights = dataset.get_class_weights()
    logger.info("\nClass weights examples (first 5):")
    logger.info("  Document types:", list(doc_type_weights.items())[:5])

    return dataset

def test_data_loader(dataset, batch_size=4):
    """
    Test data loader functionality using the dataset

    Args:
        dataset: DocumentDataset instance to test
        batch_size: Batch size for testing
    """

    logger.info("\nTesting DataLoader:")

    # Create data loader
    data_loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=0  # Use 0 for easier debugging
    )

    # Examine a batch
    logger.info(f"Testing batch loading with batch_size={batch_size}:")
    for features, doc_type_labels in data_loader:
        logger.info(f"  Batch features shape: {features.shape}")
        logger.info(f"  Batch doc_type labels shape: {doc_type_labels.shape}")

        # Print a sample from the batch
        sample_idx = 0
        doc_type_idx = torch.argmax(doc_type_labels[sample_idx]).item()
        doc_type_name = [k for k, v in dataset.doc_type_map.items() if v == doc_type_idx][0]
        logger.info(f"\n  Sample from batch:")
        logger.info(f"    Document type: {doc_type_name} (index {doc_type_idx})")
        break

if __name__ == "__main__":
    # Specify your data directory - replace with your actual path
    data_dir = "/tmp/train"  # Adjust this path as needed
    taxonomy_file = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/document_categorization/prob_category_given_doc_type.xlsx"

    # Test the dataset
    dataset = test_document_dataset(data_dir, taxonomy_file)

    # Test data loader
    test_data_loader(dataset, batch_size=4)

    logger.info("\nTests completed successfully!")