import json

import numpy as np

from categorization.infer_level1_categorization import NumpyTypeEncoder
from clustering.viz import visualize_documents_topics
from document_retrieval.embeddings import JinaModelEmbeddingIpWrapper
from pathlib import Path
from tqdm import tqdm

def inject_embeddings(definitions, embedding_model):
    for broad_def, items in definitions.items():
        broad_def_embedding = embedding_model.encode([broad_def])[0]
        definitions[broad_def]["broad_definition_embedding"] = broad_def_embedding
        for item in tqdm(items["categories"]):
            item_def_embedding = embedding_model.encode([item["definition"]])[0]
            item["definition_embedding"] = item_def_embedding

def transform2viz_inputs(definitions):
    embeddings = []
    inds = []
    labels = []
    symbols = []
    for i, (broad_def, items) in enumerate(definitions.items()):
        inds.append(i)
        symbols.append("broad")
        embeddings.append(items["broad_definition_embedding"])
        labels.append(broad_def)
        for item in tqdm(items["categories"]):
            inds.append(i)
            embeddings.append(item["definition_embedding"])
            labels.append(item["category"])
            symbols.append("specific")
    embeddings = np.vstack(embeddings)

    return embeddings, inds, labels, symbols

def visualize_defs():
    base_dir = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/document_categorization/"
    definitions_fname = Path(base_dir) /  "parley_pro_checklist_with_definitions_jamie.json"
    output_html_fname = Path(base_dir) / "parley_pro_checklist_definitions_viz.html"

    with open(definitions_fname, "r") as f:
        definitions = json.load(f)

    embedding_model = JinaModelEmbeddingIpWrapper("http://localhost:5100/api/encode")
    inject_embeddings(definitions, embedding_model)
    with open(Path(base_dir) / "parley_pro_checklist_with_definitions_and_embeddings.json", "w") as f:
        json.dump(definitions, f, indent=2, cls=NumpyTypeEncoder)

    embeddings, inds, labels, symbol = transform2viz_inputs(definitions)
    visualize_documents_topics(embeddings, inds, labels, output_html_fname, perplexity_range=[3,5,7,10,15,20], n_jobs=8, symbol=symbol)


if __name__ == '__main__':
    visualize_defs()