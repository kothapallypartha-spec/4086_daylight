import json
from pathlib import Path

from categorization.checklist_item_matcher import add_retrieved_docs, calibrate_matching_scores
from utils.log import logger


def assign_docs_to_checklist_items():
    search_method = "semantic"  # or "semantic"
    base_dir = Path("/Users/elayadim/projects/llm/due_diligence_ma/data")
    checklist_file = base_dir / "processed/document_categorization/parley_pro_checklist.json"
    aug_checklist_file = base_dir / f"processed/document_categorization/parley_pro_checklist_augmented_{search_method}.json"

    with open(checklist_file, "r") as f:
        checklist = json.load(f)

    add_retrieved_docs(checklist, top_k=10, search_method=search_method)
    calibrate_matching_scores(checklist)
    with open(aug_checklist_file, "w") as f:
        json.dump(checklist, f, indent=2)


if __name__ == "__main__":
    assign_docs_to_checklist_items()
    logger.info("Documents assigned to checklist items successfully.")