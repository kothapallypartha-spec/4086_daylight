import tempfile
from pathlib import Path

import joblib
import numpy as np
import tarfile

import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import cosine_similarity
import torch.nn.functional as F
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer

from common.utils import logger
from common.cal_utils import download_file_s3

class LabelTransformationMatrix:
    def __init__(self, original_labels, transformed_labels):
        """
        Initialize a label transformation matrix learner

        Args:
            original_labels: List of original level_2 labels (target taxonomy)
            transformed_labels: List of transformed level_2 labels (source data)
        """
        self.similarity_matrix = None
        self.original_labels = original_labels
        self.transformed_labels = transformed_labels
        self.transformed_to_idx = {label: i for i, label in enumerate(transformed_labels)}
        self.original_to_idx = {label: i for i, label in enumerate(original_labels)}
        self.transformation_matrix = None
        self.weight = None
        self.bias = None

    def compute_similarity_from_definitions(self, original_definitions, transformed_definitions, model_name="jinaai/jina-embeddings-v2-base-en", initial_weight=10.0):
        """
        Compute transformation matrix based on semantic similarity of definitions
        """
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModel.from_pretrained(model_name, trust_remote_code=True)

        # Get embeddings for definitions
        def get_embeddings(texts):
            embeddings = []
            for text in texts:
                inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
                with torch.no_grad():
                    outputs = model(**inputs)
                embeddings.append(outputs.last_hidden_state.mean(dim=1).squeeze().numpy())
            return np.vstack(embeddings)

        orig_embeds = get_embeddings(original_definitions)
        trans_embeds = get_embeddings(transformed_definitions)

        # Calculate similarity matrix
        similarity = cosine_similarity(orig_embeds, trans_embeds)
        self.similarity_matrix = torch.tensor(similarity, dtype=torch.float32)

        # Initialize learnable parameters
        self.weight = initial_weight * torch.ones(self.similarity_matrix.shape[0], dtype=torch.float32)
        self.bias = torch.zeros(self.similarity_matrix.shape[0], dtype=torch.float32)

        # Compute initial transformation matrix
        self._update_transformation_matrix()

        return self.similarity_matrix

    def _update_transformation_matrix(self):
        """Apply current weights and bias to similarity matrix"""
        logits = self.weight[:, None] * self.similarity_matrix + self.bias[:, None]
        self.transformation_matrix = F.softmax(logits, dim=1)
        return self.transformation_matrix

    def learn_parameters(self, known_mappings, taxonomy_matrix, learning_rate=0.01, iterations=100, entropy_weight=0.5):
        """
        Learn weight and bias parameters based on known mappings

        Args:
            known_mappings: List of (transformed_label, original_label, confidence) triplets
            :param known_mappings:
            :param taxonomy_matrix:
            :param entropy_weight:
            :param iterations:
            :param learning_rate:
        """
        if self.similarity_matrix is None:
            raise ValueError("Compute similarity matrix first")

        # Process known mappings
        mapping_constraints = {}
        orig_idx_known_mappings = []
        for orig_label, trans_label, confidence in known_mappings:
            if orig_label in self.original_to_idx and trans_label in self.transformed_to_idx:
                orig_idx = self.original_to_idx[orig_label]
                trans_idx = self.transformed_to_idx[trans_label]
                mapping_constraints[(orig_idx, trans_idx)] = confidence
                orig_idx_known_mappings.append(orig_idx)
        orig_idx_known_mappings = sorted(orig_idx_known_mappings)
        orig_idx_unknown_mappings = sorted(set(range(len(self.original_labels))) - set(orig_idx_known_mappings))

        # Make weight and bias learnable parameters
        weight = torch.tensor(self.weight, requires_grad=True)
        bias = torch.tensor(self.bias, requires_grad=True)

        # Simple gradient descent to learn parameters
        optimizer = torch.optim.Adam([weight, bias], lr=learning_rate)
        for i in range(iterations):
            optimizer.zero_grad()

            # Forward pass
            logits = self.similarity_matrix * weight[:, None] + bias[:, None]
            probs = F.softmax(logits, dim=1)

            # Calculate entropy (we want to minimize this to get confident predictions)
            entropy1 = -torch.sum(probs[orig_idx_known_mappings] * torch.log(probs[orig_idx_known_mappings] + 1e-10))
            transformed_probs2 = torch.matmul(probs[orig_idx_unknown_mappings], torch.tensor(taxonomy_matrix).T)
            entropy2 = -torch.sum(transformed_probs2 * torch.log(transformed_probs2 + 1e-10))
            entropy = entropy1 + entropy2

            # Calculate constraint loss
            constraint_loss = 0
            for (orig_idx, trans_idx), target_conf in mapping_constraints.items():
                constraint_loss += (probs[orig_idx, trans_idx] - target_conf) ** 2

            # Combined loss: minimize entropy while satisfying constraints
            loss = entropy_weight * entropy + (1 - entropy_weight) * constraint_loss

            # Backward pass and optimize
            loss.backward()
            optimizer.step()

            if i % 50 == 0:
                logger.info(f"Iteration {i}, Loss: {loss.item():.4f}, "
                    f"Entropy (known mapping): {entropy1.item():.4f}, "
                    f"Entropy (unknown mapping): {entropy2.item():.4f}, "
                    f"Constraint: {constraint_loss.item():.4f}")


        # Update parameters and transformation matrix
        self.weight = weight.detach()
        self.bias = bias.detach()
        self._update_transformation_matrix()

        return self.transformation_matrix

    def add_known_mappings(self, mappings):
        """
        Add known mappings to the transformation matrix

        Args:
            mappings: List of (transformed_label, original_label, confidence) triplets
                     where confidence is a float between 0-1
        """
        if self.transformation_matrix is None:
            n_transformed = len(self.transformed_labels)
            n_original = len(self.original_labels)
            self.transformation_matrix = torch.zeros((n_transformed, n_original))

        for trans_label, orig_label, confidence in mappings:
            trans_idx = self.transformed_to_idx[trans_label]
            orig_idx = self.original_to_idx[orig_label]

            # Reset row and set the known mapping with the specified confidence
            self.transformation_matrix[trans_idx] = (1 - confidence) / (self.transformation_matrix.shape[1] - 1)
            self.transformation_matrix[trans_idx, orig_idx] = confidence

        return self.transformation_matrix

    def transform_labels(self, transformed_labels_tensor):
        """
        Transform labels from transformed space to original space

        Args:
            transformed_labels_tensor: One-hot or multi-hot tensor in transformed label space

        Returns:
            Tensor in original label space with soft assignments
        """
        if self.transformation_matrix is None:
            raise ValueError("Transformation matrix has not been computed yet")

        # Convert the transformation matrix to the same device as the input tensor
        matrix = self.transformation_matrix.to(transformed_labels_tensor.device)

        # Perform the transformation
        return torch.matmul(transformed_labels_tensor, matrix)

    def save(self, path):
        """Save transformation matrix and parameters"""
        np.savez_compressed(
            path,
            transformation_matrix=self.transformation_matrix.cpu().numpy(),
            similarity_matrix=self.similarity_matrix.cpu().numpy(),
            weight=self.weight.cpu().numpy(),
            bias=self.bias.cpu().numpy()
        )

    def load(self, path):
        """Load transformation matrix and parameters"""
        data = np.load(path)
        self.transformation_matrix = torch.tensor(data['transformation_matrix'])
        self.similarity_matrix = torch.tensor(data['similarity_matrix'])
        self.weight = torch.tensor(data['weight'])
        self.bias = torch.tensor(data['bias'])

        return self


class TaxonomyConstrainedClassifier(nn.Module):
    """Neural network model with taxonomy constraints for document classification"""
    def __init__(self, input_dim, hidden_dim, doc_type_count, transformation_matrix, taxonomy_matrix):
        super().__init__()
        self.logits = None
        self.feature_extractor = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, doc_type_count)
            )

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._dont_use_taxonomy = taxonomy_matrix is None or transformation_matrix is None
        if self._dont_use_taxonomy:
            logger.info("Not using taxonomy or transformation matrix for training")
            self.taxonomy_matrix = None
            self.log_transformation_matrix = None
        else:
            self.register_buffer('taxonomy_matrix', torch.tensor(taxonomy_matrix, dtype=torch.float32))

            # Make transformation matrix a trainable parameter
            self.log_transformation_matrix = nn.Parameter(
                torch.log(torch.tensor(transformation_matrix, dtype=torch.float32))
            )

    def forward(self, x):
        self.logits = self.feature_extractor(x)
        probs = torch.sigmoid(self.logits)
        return probs

    def compute_constraint_loss(self):
        """
        Compute taxonomy constraint loss based on predictions

        Returns a scalar loss value that can be weighted and added to the main loss
        """
        # Calculate expected probabilities according to taxonomy relationships
        if self._dont_use_taxonomy:
            return torch.tensor(0.0, device=self.device)
        pred_probs = torch.softmax(self.logits, dim=1)
        transformation_matrix = torch.softmax(self.log_transformation_matrix, dim=1)
        transformed_probs = torch.matmul(pred_probs, transformation_matrix)
        broad_categ_probs = torch.matmul(transformed_probs, self.taxonomy_matrix.T)

        constraint_loss = -torch.sum(broad_categ_probs * torch.log(broad_categ_probs + 1e-10), dim=1).mean()

        return constraint_loss


class ConfidenceCalibrator:
    """Calibrates confidence scores using Platt scaling"""
    def __init__(self):
        self.calibrators = None
    
    def fit(self, scores, labels):
        assert scores.shape == labels.shape, "Logits and labels must have the exact same shape"
        self.calibrators = []
        for j in tqdm(range(scores.shape[1]), desc="Fitting calibrators"):
            lr = LogisticRegression(solver='lbfgs', max_iter=1000)
            # Fit a logistic regression model for each class
            lr.fit(scores[:,j][:, np.newaxis], labels[:, j])
            self.calibrators.append(lr)

    def transform(self, scores):
        """Apply calibration to model outputs"""
        assert self.calibrators, "Calibrators have not been fitted yet"
        num_calibrators = len(self.calibrators)
        return np.array([
            self.calibrators[j].predict_proba(scores[:, j][:, np.newaxis])[:, 1]
            for j in range(num_calibrators)
        ]).T

    def fit_transform(self, scores, labels):
        self.fit(scores, labels)
        return self.transform(scores)

    def save(self, model_dir):
        assert self.calibrators, "Calibrators have not been fitted yet"
        if not Path(model_dir).exists():
            Path(model_dir).mkdir(parents=True, exist_ok=True)
        for j, calibrator in enumerate(self.calibrators):
            joblib.dump(calibrator, Path(model_dir) / f"calibrator_class_{j}.joblib")
    
    def load(self, model_dir):
        calibrators = []
        for file in Path(model_dir).glob("calibrator_class_*.joblib"):
            calibrators.append(joblib.load(file))
        self.calibrators = calibrators
        return self


class DocumentCategorizer:
    device = "cpu"
    model = None

    def __init__(
            self,
            input_dim,
            hidden_dim,
            doc_types,
            category_names,
            broad_categories,
            taxonomy_matrix,
            transformation_matrix,
            constraint_weight=0.1,
            calibrate_scores=False
            ):
        """
        Initialize trainer for document type classification

        Args:
            input_dim: Dimension of input features
            hidden_dim: Dimension of hidden layers
            category_count: Number of document type categories
        """
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        doc_type_count = len(doc_types)
        category_count = len(category_names)
        assert transformation_matrix.shape == (doc_type_count, category_count), \
            f"Transformation matrix shape {transformation_matrix.shape} does not match expected ({doc_type_count}, {category_count})"
        assert taxonomy_matrix.shape[1] == category_count, "Taxonomy matrix must have shape (broad_category_count, category_count)"

        self.document_types = doc_types
        self.category_names = category_names
        self.broad_categories = broad_categories
        self.calibrator = ConfidenceCalibrator() if calibrate_scores else None

        # Initialize model with a simpler architecture for document type classification
        self.model = TaxonomyConstrainedClassifier(
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            doc_type_count=doc_type_count,
            transformation_matrix=transformation_matrix,
            taxonomy_matrix=taxonomy_matrix,
            ).to(self.device)

        self.constraint_weight = constraint_weight

    def train(self, train_loader, val_loader, epochs=10, lr=0.001, decay=0.01, save_dir=None):
        """Train model with document type labels"""
        # Get class weights from training data
        doc_type_weights = train_loader.dataset.dataset.get_class_weights()

        # Convert weights to tensor
        doc_type_weight_tensor = torch.tensor(
            [doc_type_weights[i] for i in range(len(doc_type_weights))],
            device=self.device
        )

        optimizer = optim.Adam(self.model.parameters(), lr=lr)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=2)
        best_val_loss = float('inf')

        for epoch in range(epochs):
            # Training
            self.model.train()
            train_loss = 0
            train_samples = 0
            constraint_loss_total = 0
            lr *= 1 - decay * epoch / epochs
            # Decay learning rate
            self.constraint_weight *= 1 - decay * epoch/ epochs

            for X_batch, doc_type_batch, _ in tqdm(train_loader, total=len(train_loader), desc=f"Epoch {epoch+1}/{epochs}"):
                X_batch = X_batch.to(self.device)
                doc_type_batch = doc_type_batch.to(self.device)

                # Add artificial noise
                noise = torch.randn_like(X_batch) * 0.02
                X_batch = torch.stack([X_batch, X_batch + noise], dim=0).view(-1, X_batch.size(1))
                doc_type_batch = torch.stack([doc_type_batch, doc_type_batch], dim=0).view(-1, doc_type_batch.size(1))

                optimizer.zero_grad()
                doc_type_pred = self.model(X_batch)

                # Weighted BCE loss
                loss = nn.functional.binary_cross_entropy(
                    doc_type_pred, doc_type_batch,
                    reduction='none'
                )

                # Apply weights based on active classes
                sample_weights = torch.zeros_like(doc_type_batch[:, 0])
                for i in range(doc_type_batch.shape[1]):
                    sample_weights += doc_type_weight_tensor[i] * doc_type_batch[:, i]

                # Normalize weights
                sample_weights = sample_weights / (sample_weights.sum() + 1e-8)

                # Apply sample weights to loss
                loss = (loss.mean(dim=1) * sample_weights).sum()
                # Add taxonomy constraint loss if using constrained model
                constraint_loss = self.model.compute_constraint_loss()
                loss += self.constraint_weight * constraint_loss
                constraint_loss_total += constraint_loss.item() * X_batch.size(0)

                loss.backward()
                optimizer.step()

                train_loss += loss.item() * X_batch.size(0)
                train_samples += X_batch.size(0)

            # Validation
            val_loss, val_metrics = self._validate(val_loader)

            train_loss /= train_samples
            logger.info(f"Epoch {epoch+1}/{epochs} - Train Loss: {train_loss:.4f}, Constraint Loss: {constraint_loss_total:4f}, Val Loss: {val_loss:.4f}")
            logger.info(f"  Val Precision: {val_metrics['precision']:.4f}, Val Recall: {val_metrics['recall']:.4f}, Val F1: {val_metrics['f1']:.4f}")

            # Learning rate scheduling
            scheduler.step(val_loss)

            # Save best model
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                if save_dir:
                    self.save(save_dir)
                logger.info(f"  Saved new best model with val_loss: {val_loss:.4f}")

        # Load best model
        if save_dir:
            self.load(save_dir)

        logger.info("Training complete")
        return self

    def _validate(self, data_loader):
        """Evaluate model with document type labels"""
        self.model.eval()
        total_loss = 0
        all_logits = []
        all_probs = []
        all_targets = []
        samples = 0

        with torch.no_grad():
            for X_batch, doc_type_batch, _ in tqdm(data_loader, total=len(data_loader)):
                X_batch = X_batch.to(self.device)
                doc_type_batch = doc_type_batch.to(self.device)

                doc_type_pred = self.model(X_batch)

                # Standard BCE loss for evaluation
                loss = nn.functional.binary_cross_entropy(doc_type_pred, doc_type_batch)
                loss += self.model.compute_constraint_loss()
                total_loss += loss.item() * X_batch.size(0)

                # Calculate metrics
                all_probs.append(doc_type_pred.cpu().numpy())
                all_logits.append(self.model.logits.cpu().numpy())
                all_targets.append(doc_type_batch.cpu().numpy())
                samples += X_batch.size(0)

        # Compute metrics
        all_probs = np.vstack(all_probs)
        all_targets = np.vstack(all_targets)
        if self.calibrator:
            all_logits = np.vstack(all_logits)
            all_probs = self.calibrator.fit_transform(all_logits, all_targets)
        all_preds = (all_probs > 0.5).astype(int)

        tp = np.round((all_preds * all_targets).astype(float))
        fp = np.round((all_preds * (1 - all_targets)).astype(float))
        fn = np.round(((1 - all_preds) * all_targets).astype(float))
        n_ref = np.sum(all_targets, axis=0)
        weights = np.minimum(np.maximum(n_ref, 50), 2000)
        precision = np.sum(tp, axis=0) / (np.sum(tp, axis=0) + np.sum(fp, axis=0) + 1e-10)
        recall = np.sum(tp, axis=0) / (np.sum(tp, axis=0) + np.sum(fn, axis=0) + 1e-10)
        f1_score = 2 * precision * recall / (precision + recall + 1e-10)

        # Average metrics across all classes
        precision = np.sum(weights * precision) / (np.sum(weights) + 1e-10)
        recall = np.sum(weights * recall) / (np.sum(weights) + 1e-10)
        f1_score = np.sum(weights * f1_score) / (np.sum(weights) + 1e-10)

        metrics = {
            "precision": precision,
            "recall": recall,
            "f1": f1_score,
        }

        return total_loss / samples, metrics

    def evaluate(self, data_loader):
        self.model.eval()
        total_loss = 0
        all_probs = []
        all_logits = []
        all_targets = []
        samples = 0

        with torch.no_grad():
            for X_batch, doc_type_batch, _ in tqdm(data_loader, total=len(data_loader)):
                X_batch = X_batch.to(self.device)
                doc_type_batch = doc_type_batch.to(self.device)

                doc_type_pred = self.model(X_batch)

                # Standard BCE loss for evaluation
                loss = nn.functional.binary_cross_entropy(doc_type_pred, doc_type_batch)
                loss += self.model.compute_constraint_loss()
                total_loss += loss.item() * X_batch.size(0)

                # Calculate metrics
                all_probs.append(doc_type_pred.cpu().numpy())
                all_logits.append(self.model.logits.cpu().numpy())
                all_targets.append(doc_type_batch.cpu().numpy())
                samples += X_batch.size(0)

        # Compute metrics
        all_probs = np.vstack(all_probs)
        all_targets = np.vstack(all_targets)
        if self.calibrator:
            all_logits = np.vstack(all_logits)
            all_probs = self.calibrator.transform(all_logits)
        all_preds = (all_probs > 0.5).astype(int)

        tp = np.round((all_preds * all_targets).astype(float))
        fp = np.round((all_preds * (1 - all_targets)).astype(float))
        fn = np.round(((1 - all_preds) * all_targets).astype(float))
        n_ref = np.sum(all_targets, axis=0)
        weights = np.minimum(np.maximum(n_ref, 50), 2000)
        precision = np.sum(tp, axis=0) / (np.sum(tp, axis=0) + np.sum(fp, axis=0) + 1e-10)
        recall = np.sum(tp, axis=0) / (np.sum(tp, axis=0) + np.sum(fn, axis=0) + 1e-10)
        f1_score = 2 * precision * recall / (precision + recall + 1e-10)

        # Average metrics across all classes
        precision = np.sum(weights * precision) / (np.sum(weights) + 1e-10)
        recall = np.sum(weights * recall) / (np.sum(weights) + 1e-10)
        f1_score = np.sum(weights * f1_score) / (np.sum(weights) + 1e-10)

        metrics = {
            "precision": precision,
            "recall": recall,
            "f1": f1_score,
            }
        logger.info(f"Evaluation - Loss: {total_loss / samples:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1_score:.4f}")
        return total_loss / samples, metrics


    def predict_doctypes_multilabel(self, X, threshold=0.5, return_probs=False):
        """Make binary predictions with the trained model"""
        self.model.eval()
        if not isinstance(X, torch.Tensor):
            X = torch.tensor(X, dtype=torch.float32)
        X = X.to(self.device)

        with torch.no_grad():
            doc_type_probs = self.model(X)
            if self.calibrator:
                doc_type_probs = torch.tensor(
                    self.calibrator.transform(self.model.logits.cpu().numpy()),
                    device=self.device,
                    dtype=torch.float32
                    )
            if return_probs:
                return doc_type_probs.cpu().numpy()
            doc_type_binary = (doc_type_probs > threshold).float()

        return doc_type_binary

    def predict_doctypes_multiclass(self, X, return_probs=False):
        """
        Predict document types using the trained model

        Args:
            X: Input features
            return_probs: If True, return probabilities instead of class indices

        Returns:
            Predicted document types as class indices or probabilities
        """
        self.model.eval()
        if not isinstance(X, torch.Tensor):
            X = torch.tensor(X, dtype=torch.float32)
        X = X.to(self.device)

        with torch.no_grad():
            _ = self.model(X)
            if self.calibrator:
                calibrated_sigmoids = self.calibrator.transform(self.model.logits.cpu().numpy())
                self.model.logits = torch.logit(torch.tensor(calibrated_sigmoids, device=self.device, dtype=torch.float32))
            doc_type_probs = torch.softmax(self.model.logits, dim=1)
        if return_probs:
            return doc_type_probs.cpu().numpy()
        return torch.argmax(doc_type_probs, dim=1).cpu().numpy()

    def predict_categories(self, X, return_probs=False):
        assert self.model.log_transformation_matrix is not None, "This feature requires a trained transformation matrix"
        self.model.eval()
        if not isinstance(X, torch.Tensor):
            X = torch.tensor(X, dtype=torch.float32)
        X = X.to(self.device)

        with torch.no_grad():
            _ = self.model(X)
            if self.calibrator:
                calibrated_sigmoids = self.calibrator.transform(self.model.logits.cpu().numpy())
                self.model.logits = torch.logit(torch.tensor(calibrated_sigmoids, device=self.device, dtype=torch.float32))
            pred_probs = torch.softmax(self.model.logits, dim=1)
            transformation_matrix = torch.softmax(self.model.log_transformation_matrix.data, dim=1)
            transformed_probs = torch.matmul(pred_probs, transformation_matrix)

        if return_probs:
            return transformed_probs

        return torch.argmax(transformed_probs, dim=1).cpu().numpy()

    def save(self, model_dir):
        """Save the model to the specified path"""
        if not Path(model_dir).exists():
            Path(model_dir).mkdir(parents=True, exist_ok=True)
        model_path = Path(model_dir) / "best_category_model.pt"
        torch.save(self.model.state_dict(), model_path)
        with open(Path(model_dir) / "categories.txt", "w") as f:
            f.write("\n".join(self.category_names))
        with open(Path(model_dir) / "document_types.txt", "w") as f:
            f.write("\n".join(self.document_types))
        with open(Path(model_dir) / "broad_categories.txt", "w") as f:
            f.write("\n".join(self.broad_categories))

        if self.calibrator:
            calibrator_dir = Path(model_dir) / "calibrators"
            Path(calibrator_dir).mkdir(exist_ok=True)
            self.calibrator.save(calibrator_dir)
        logger.info(f"Model saved to {model_path}")

    @classmethod
    def load(cls, model_dir):
        """Load the model from the specified path"""
        model_path = Path(model_dir) / "best_category_model.pt"

        # Read category names, document types, and broad categories
        with open(Path(model_dir) / "categories.txt", "r") as f:
            category_names = [line.strip() for line in f.readlines()]
        with open(Path(model_dir) / "document_types.txt", "r") as f:
            document_types = [line.strip() for line in f.readlines()]
        with open(Path(model_dir) / "broad_categories.txt", "r") as f:
            broad_categories = [line.strip() for line in f.readlines()]

        # Create an instance of the CategoryTrainer
        instance = cls(
            input_dim=768,  # Default input dimension for embeddings
            hidden_dim=256,  # Default hidden dimension
            doc_types=document_types,
            category_names=category_names,
            broad_categories=broad_categories,
            # Use dummy matrices initially, will be replaced when loading model
            transformation_matrix=np.ones((len(document_types), len(category_names))),
            taxonomy_matrix=np.ones((len(broad_categories), len(category_names))),
            constraint_weight=0.1  # Default constraint weight
        )

        # Load the model state
        state_dict = torch.load(model_path, map_location=instance.device)
        instance.model.load_state_dict(state_dict)
        instance.model.to(instance.device)

        calibrator_path = Path(model_dir) / "calibrators"
        if calibrator_path.exists():
            instance.calibrator = ConfidenceCalibrator().load(calibrator_path)
        else:
            instance.calibrator = None

        logger.info(f"Model loaded from {model_dir}")
        return instance

    @classmethod
    def load_from_s3_tar(cls, s3_tar_filename, bucket, loc):
        """
        Load a DocumentCategorizer model from a tar.gz file stored on S3.

        Args:
            s3_tar_filename: Name of the tar.gz file on S3.
            bucket: S3 bucket name.
            loc: S3 location prefix.

        Returns:
            Loaded DocumentCategorizer instance.
        """
        # Download tar.gz file from S3
        tar_bytes = download_file_s3(s3_tar_filename, loc=loc, bucket=bucket)
        if tar_bytes is None:
            raise RuntimeError(f"Failed to download {s3_tar_filename} from S3.")

        # Write to a temporary file and extract
        with tempfile.TemporaryDirectory() as tmpdir:
            tar_path = Path(tmpdir) /  "model.tar.gz"
            with open(tar_path, "wb") as f:
                f.write(tar_bytes.encode("utf-8") if isinstance(tar_bytes, str) else tar_bytes)
            with tarfile.open(tar_path, "r:gz") as tar:
                tar.extractall(path=tmpdir)
            # Assume model files are extracted to tmpdir
            return cls.load(tmpdir)