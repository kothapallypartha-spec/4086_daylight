from pathlib import Path
import json
import numpy as np
import pandas as pd
from tqdm import tqdm

from utils.log import logger
from data_processing.categories_loader import create_data_loader
from categorization.categorizer import CategoryTrainer
import torch

torch.multiprocessing.set_start_method('fork', force=True)
torch.set_num_threads(8)

class NumpyTypeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.generic):
            return obj.item()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)

def get_specific_doc_id_filter(dataset):
    npz_file = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/document_categorization/train_valid_info.npz"
    valid_idx = np.load(npz_file, allow_pickle=True)["val_indices"]
    doc_ids = [dataset[idx][2] for idx in valid_idx]

    return doc_ids

def entropy_confidence(prediction_probs):
    """
    Calculate the entropy-based confidence for predictions.
    Higher entropy indicates more uncertainty.
    """
    prediction_probs = np.clip(prediction_probs, 1e-10, 1 - 1e-10)  # Avoid log(0)
    entropy = -np.sum(prediction_probs * np.log(prediction_probs))
    return 1 - (entropy / np.log(prediction_probs.shape[0]))  # Normalize to [0, 1]

def get_top_k(prediction_probs, top_k, labels, doc_ids, confidence_fn):
    inds = np.argsort(1 - prediction_probs, axis=1)[:, :top_k]
    top_k_labels = {
           doc_id: {
               "confidence": confidence_fn(sub_prediction_probs),
               "predictions": [
                   {
                   "index": i,
                    "label": labels[sub_inds[i]],
                    "probability": sub_prediction_probs[sub_inds[i]]
                    }
                    for i in range(top_k)
                ]
               }
        for doc_id, sub_prediction_probs, sub_inds in zip(doc_ids, prediction_probs, inds)
    }

    return top_k_labels

def eval_dataset(data_loader, model, doc_types, categories):
    doc_type_count = len(doc_types)
    all_predictions = []
    true_positive = np.zeros(doc_type_count)
    false_positive = np.zeros(doc_type_count)
    false_negative = np.zeros(doc_type_count)
    for X_batch, y_batch, doc_ids in tqdm(data_loader, total=len(data_loader), desc="Running inference"):
        binary = model.predict_doctypes_multilabel(X_batch)
        true_positive += (binary * y_batch).cpu().numpy().sum(axis=0)
        false_positive += (binary * (1 - y_batch)).cpu().numpy().sum(axis=0)
        false_negative += ((1 - binary) * y_batch).cpu().numpy().sum(axis=0)
        true_doc_types = [[doc_types[i] for i in x.nonzero()[0]]  for x in y_batch.cpu().numpy()]
        pred_doc_types = [[doc_types[i] for i in x.nonzero()[0]]  for x in binary.cpu().numpy()]
        pred_categories = [categories[i] for i in model.predict_categories_multiclass(X_batch)]
        pred_categories_multilabel = [
            [categories[i] for i in x.nonzero()[0]] for x in model.predict_categories_multilabel(X_batch, threshold=0.5).cpu().numpy()
            ]
        all_predictions += [
            [doc_id, true_labels, pred_labels, pred_categs, pred_categs_multilabel]
            for doc_id, true_labels, pred_labels, pred_categs, pred_categs_multilabel
            in zip(doc_ids, true_doc_types, pred_doc_types, pred_categories, pred_categories_multilabel)
            ]
    labels_df = pd.DataFrame(all_predictions, columns=["doc_id", "true_labels", "pred_labels", "pred_categories", "pred_categories_multilabel"])
    stats = {
        "true_positive": {doc_types[i]: int(tp) for i, tp in enumerate(true_positive)},
        "false_positive": {doc_types[i]: int(fp) for i, fp in enumerate(false_positive)},
        "false_negative": {doc_types[i]: int(fn) for i, fn in enumerate(false_negative)}
        }

    return labels_df, stats

def predict_dataset(data_loader, model: CategoryTrainer, doc_types, categories, taxonomy, broad_categories):
    all_predictions = []
    stats = {}
    category2broad = {categories[c]: broad_categories[b] for c, b in zip(*[x.tolist() for x in np.nonzero(taxonomy)])}
    for X_batch, _, doc_ids in tqdm(data_loader, total=len(data_loader), desc="Running inference"):
        prob_doc_types = model.predict_doctypes_multilabel(X_batch, threshold=0.5, return_probs=True)
        prob_categories = model.predict_categories(X_batch, return_probs=True).cpu().numpy()
        prob_broad_categories = prob_categories @ taxonomy
        doc_type_stats = get_top_k(prob_doc_types, 3, doc_types, doc_ids, max)
        category_stats = get_top_k(prob_categories, 3, categories, doc_ids, entropy_confidence)
        broad_category = get_top_k(prob_broad_categories, 3, broad_categories, doc_ids, entropy_confidence)
        for doc_id in doc_type_stats:
            stats[doc_id] = {
                "doc_types": doc_type_stats[doc_id],
                "categories": category_stats[doc_id],
                "broad_categories": broad_category[doc_id],
                }
        binary = prob_doc_types > 0.5
        pred_doc_types = [[doc_types[i] for i in x.nonzero()[0]] for x in binary]
        pred_categories = [categories[i] for i in prob_categories.argmax(axis=1)]
        pred_broad_categories = [broad_categories[i] for i in prob_broad_categories.argmax(axis=1)]
        all_predictions += [
            [doc_id, pred_labels, pred_categs, pred_broad_categs]
            for doc_id, pred_labels, pred_categs, pred_broad_categs
            in zip(doc_ids, pred_doc_types, pred_categories, pred_broad_categories)
            ]
    labels_df = pd.DataFrame(all_predictions, columns=["doc_id", "pred_labels", "pred_categories", "pred_broad_categories"])
    for doc_id in stats:
        for item in stats[doc_id]["categories"]["predictions"]:
            item["broad_category"] = category2broad[item["label"]]

    return labels_df, stats

def infer_level1_categorization():
    # Paths and parameters
    data_dir = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/converted/txt/redacted_parley_pro_data"  # Adjust this path as needed
    output_dir = "/Users/elayadim/projects/llm/due_diligence_ma/data/processed/document_categorization/"
    model_dir = "/Users/elayadim/projects/llm/due_diligence_ma/model/categorization/level1_clf/jina-v2-no-calib"
    prediction_file = Path(output_dir) / f"predictions_level1_categorization_{Path(data_dir).stem}.xlsx"
    input_dim = 768
    true_labels_available = False

    # Load model
    model = CategoryTrainer.load(model_dir)
    model.calibrator = None  # Disable calibrator for inference
    logger.info(f"Model loaded from {model_dir}")

    # Create data loaders
    doc_types = model.document_types
    categories = model.category_names
    broad_categories = model.broad_categories
    data_loader, doc_type_count, dataset = create_data_loader(
        data_dir, doc_types=doc_types, batch_size=32
    )
    logger.info(f"Dataset has {len(data_loader.dataset)} samples")
    filter_idx = None #get_specific_doc_id_filter(dataset)

    # Run inference
    labels_df, stats = predict_dataset(data_loader, model, doc_types, categories, model.model.taxonomy_matrix.cpu().numpy().T, broad_categories)

    if filter_idx:
        labels_df = labels_df[labels_df["doc_id"].isin(filter_idx)]

    labels_df.to_excel(prediction_file, index=False)
    with open(Path(output_dir) / f"stats_{Path(data_dir).stem}.json", "w") as f:
        json.dump(stats, f, indent=2, cls=NumpyTypeEncoder, sort_keys=True)

if __name__ == "__main__":
    infer_level1_categorization()
    logger.info("Level 1 categorization inference completed successfully!")