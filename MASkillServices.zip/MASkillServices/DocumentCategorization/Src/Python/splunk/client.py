import time
from loguru import logger
import splunklib.client as client
import splunklib.results as results

class SplunkClient:
    def __init__(self, host, port, username, password, scheme="https", num_retries=10):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.scheme = scheme
        self.num_retries = num_retries
        self.service = None

    def connect(self):
        for i in range(self.num_retries):
            try:
                logger.info(f"Attempting to connect to Splunk (Attempt {i + 1}/{self.num_retries})...")
                self.service = client.connect(
                    host=self.host,
                    port=self.port,
                    username=self.username,
                    password=self.password,
                    scheme=self.scheme,
                    autologin=True
                )
                logger.success("Successfully connected to Splunk.")
                return self.service
            except Exception as e:
                logger.error(f"Error occurred while connecting to Splunk: {e}")
                if i < self.num_retries - 1:
                    logger.info(f"Retrying in 15 seconds...")
                    time.sleep(15)
                else:
                    logger.critical("Failed to connect to Splunk after multiple attempts.")
                    raise e

    def create_job(self, search_query, **kwargs):
        for i in range(self.num_retries):
            try:
                logger.info(f"Creating Splunk job (Attempt {i + 1}/{self.num_retries})...")
                job = self.service.jobs.create(search_query, **kwargs)
                logger.success("Splunk job created successfully.")
                return job
            except Exception as e:
                logger.error(f"Error creating Splunk job: {e}")
                if i < self.num_retries - 1:
                    logger.info(f"Retrying in 10 seconds...")
                    time.sleep(10)
                else:
                    logger.critical("Failed to create Splunk job after multiple attempts.")
                    raise e

    def fetch_job_results(self, job):
        out = []
        offset = 0
        count = 10000
        while offset < int(job["resultCount"]):
            logger.info(f"Fetching results from offset {offset}...")
            kwargs_paginate = {"count": count, "offset": offset}
            try:
                chunk_results = job.results(output_mode='json', **kwargs_paginate)
                reader = results.JSONResultsReader(chunk_results)
                for result in reader:
                    if isinstance(result, dict):
                        out.append(result)
                    elif isinstance(result, results.Message):
                        logger.warning(f"{result.type}: {result.message}")
            except Exception as e:
                logger.error(f"Error fetching results at offset {offset}: {e}")
                break
            offset += count
        return out
