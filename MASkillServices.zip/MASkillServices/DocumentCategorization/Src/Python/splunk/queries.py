# Splunk queries code will be moved here

SPLUNK_DAILY_2K_SAMPLE_QUERY = """
    search actionName=SendChatMessage assetAreaName=fpuslexisplusai assetGroup=pdc1c earliest= "{earliest}" latest= "{latest}" 
    | lookup BIDataDefinition userPermID as userPermID OUTPUT customerClassName  
    | where customerClassName != "Internal" and customerClassName != "" 
    | sample 2000 
    | table _time userPermID status intent type chatSessionId userMessageId
"""
SPLUNK_DAILY_COMPLETE_QUERY = """
    search actionName=SendChatMessage assetAreaName=fpuslexisplusai assetGroup=pdc1c earliest= "{earliest}" latest= "{latest}" intent!= "ASK" intent!="SEARCH" intent!="Ask Docs"
    | lookup BIDataDefinition userPermID as userPermID OUTPUT customerClassName  
    | where customerClassName != "Internal" and customerClassName != "" 
    | table _time userPermID status intent type chatSessionId userMessageId
"""
SPLUNK_DAILY_ERRORS_QUERY = """
    search actionName=SendChatMessage assetAreaName=fpuslexisplusai assetGroup=pdc1c status=IF intent !="Ask*" intent!="Search" intent!="SUMMARIZE" earliest="{earliest}" latest= "{latest}"| table _time userMessageId chatSessionId exceptionDetail errorMessage response status intent
    | join type=inner userMessageId [
                    search index="sk8s_events" "k8s.container.name"="conversation-svc" url="*/messages?message_id=*" httpMethod="GET" earliest="{earliest}" latest= "{latest}"
                    | rex field=_raw "message_id=(?<userMessageId>[a-f0-9\-]+)"
                    | fillnull value="NULL" userMessageId
                    | table userMessageId  extra.otel_trace_id
                ]
    | join type=inner extra.otel_trace_id [
                search index="sk8s_events" "k8s.container.name"="draft-svc" "k8s.pod.labels.app"="draft-svc" message="Draft request intent*" earliest="{earliest}" latest= "{latest}"
                | table message extra.otel_trace_id
    ]"""
SPLUNK_Drafting_Evaluations_QUERY = """
    search assetGroup=pdc1c LoggingAssistant_Tracking
    AND genAIToolName="Lplus Drafting Evaluations"
    AND genAIActivityName!=""
    AND genAIDateStamp!=""
    earliest="{earliest}" latest="{latest}"
    | table genAIUserId, genAIToolName, genAIActivityName, genAIDateStamp
"""