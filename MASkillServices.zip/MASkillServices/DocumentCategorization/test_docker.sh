#!/bin/bash -xe

docker build -t vault-enricher-test .
docker run -it --env-file .env --entrypoint="" vault-enricher-test /bin/bash
